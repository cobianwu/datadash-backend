import { pgTable, text, serial, integer, boolean, timestamp, jsonb, decimal } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table for authentication
export const sessions = pgTable(
  "sessions",
  {
    sid: text("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  }
);

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  email: text("email").unique(),
  passwordHash: text("password_hash").notNull(),
  firstName: text("first_name"),
  lastName: text("last_name"),
  role: text("role").default("user"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const warehouses = pgTable("warehouses", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  size: text("size").notNull(),
  status: text("status").notNull().default("suspended"),
  creditsPerHour: decimal("credits_per_hour", { precision: 10, scale: 3 }).notNull(),
  nodes: integer("nodes").notNull(),
  autoSuspend: boolean("auto_suspend").notNull().default(true),
  userId: integer("user_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
});

export const dataSources = pgTable("data_sources", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull(), // csv, excel, json, parquet, database
  fileName: text("file_name"),
  filePath: text("file_path"),
  schema: jsonb("schema"), // Column definitions and types
  rowCount: integer("row_count").default(0),
  status: text("status").notNull().default("processing"), // processing, ready, error
  userId: integer("user_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
});

export const queryHistory = pgTable("query_history", {
  id: serial("id").primaryKey(),
  sqlQuery: text("sql_query").notNull(),
  status: text("status").notNull(), // running, completed, error
  duration: integer("duration"), // milliseconds
  rowsReturned: integer("rows_returned"),
  creditsUsed: decimal("credits_used", { precision: 10, scale: 6 }),
  warehouseId: integer("warehouse_id").references(() => warehouses.id),
  userId: integer("user_id").references(() => users.id),
  executedAt: timestamp("executed_at").defaultNow(),
});

export const charts = pgTable("charts", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull(), // bar, line, pie, scatter, heatmap, treemap
  configuration: jsonb("configuration").notNull(), // Chart config including axes, colors, etc.
  dataSourceId: integer("data_source_id").references(() => dataSources.id),
  userId: integer("user_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
});

export const dashboards = pgTable("dashboards", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  layout: jsonb("layout").notNull(), // Dashboard layout configuration
  userId: integer("user_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
});

export const aiConversations = pgTable("ai_conversations", {
  id: serial("id").primaryKey(),
  messages: jsonb("messages").notNull(), // Array of conversation messages
  context: jsonb("context"), // Current data context for AI
  userId: integer("user_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
});

// Private Equity Specific Tables
export const companies = pgTable("companies", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  sector: text("sector").notNull(),
  region: text("region").notNull(),
  foundedDate: timestamp("founded_date"),
  employees: integer("employees"),
  revenue: decimal("revenue", { precision: 15, scale: 2 }),
  ebitda: decimal("ebitda", { precision: 15, scale: 2 }),
  netIncome: decimal("net_income", { precision: 15, scale: 2 }),
  totalAssets: decimal("total_assets", { precision: 15, scale: 2 }),
  totalDebt: decimal("total_debt", { precision: 15, scale: 2 }),
  equity: decimal("equity", { precision: 15, scale: 2 }),
  marketCap: decimal("market_cap", { precision: 15, scale: 2 }),
  description: text("description"),
  stage: text("stage"), // seed, series_a, series_b, growth, mature
  userId: integer("user_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
});

export const investments = pgTable("investments", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").references(() => companies.id),
  investmentDate: timestamp("investment_date").notNull(),
  investmentAmount: decimal("investment_amount", { precision: 15, scale: 2 }).notNull(),
  ownershipPercentage: decimal("ownership_percentage", { precision: 5, scale: 2 }),
  valuationAtInvestment: decimal("valuation_at_investment", { precision: 15, scale: 2 }),
  currentValuation: decimal("current_valuation", { precision: 15, scale: 2 }),
  exitDate: timestamp("exit_date"),
  exitAmount: decimal("exit_amount", { precision: 15, scale: 2 }),
  status: text("status").notNull().default("active"), // active, exited, written_off
  notes: text("notes"),
  userId: integer("user_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
});

export const portfolioAnalysis = pgTable("portfolio_analysis", {
  id: serial("id").primaryKey(),
  analysisDate: timestamp("analysis_date").defaultNow(),
  totalPortfolioValue: decimal("total_portfolio_value", { precision: 15, scale: 2 }),
  totalReturn: decimal("total_return", { precision: 10, scale: 4 }),
  irr: decimal("irr", { precision: 10, scale: 4 }), // Internal Rate of Return
  moic: decimal("moic", { precision: 10, scale: 4 }), // Multiple on Invested Capital
  sharpeRatio: decimal("sharpe_ratio", { precision: 10, scale: 4 }),
  volatility: decimal("volatility", { precision: 10, scale: 4 }),
  beta: decimal("beta", { precision: 10, scale: 4 }),
  diversificationScore: decimal("diversification_score", { precision: 5, scale: 2 }),
  sectorAllocation: jsonb("sector_allocation"), // Sector breakdown
  riskMetrics: jsonb("risk_metrics"), // Various risk calculations
  recommendations: jsonb("recommendations"), // AI recommendations
  userId: integer("user_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
});

export const dueDiligenceReports = pgTable("due_diligence_reports", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").references(() => companies.id),
  reportDate: timestamp("report_date").defaultNow(),
  financialHealthScore: integer("financial_health_score"), // 0-100
  marketPositionScore: integer("market_position_score"), // 0-100
  operationalEfficiency: integer("operational_efficiency"), // 0-100
  managementQuality: integer("management_quality"), // 0-100
  esgScore: integer("esg_score"), // 0-100
  overallRiskScore: integer("overall_risk_score"), // 0-100
  recommendationScore: integer("recommendation_score"), // 0-100
  recommendation: text("recommendation"), // BUY, HOLD, SELL
  keyFindings: jsonb("key_findings"),
  riskFactors: jsonb("risk_factors"),
  opportunities: jsonb("opportunities"),
  competitiveAnalysis: jsonb("competitive_analysis"),
  userId: integer("user_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
});

export const marketIntelligence = pgTable("market_intelligence", {
  id: serial("id").primaryKey(),
  sector: text("sector").notNull(),
  region: text("region").notNull(),
  reportDate: timestamp("report_date").defaultNow(),
  marketSize: decimal("market_size", { precision: 15, scale: 2 }),
  growthRate: decimal("growth_rate", { precision: 5, scale: 2 }),
  keyTrends: jsonb("key_trends"),
  competitiveLandscape: jsonb("competitive_landscape"),
  valuationMultiples: jsonb("valuation_multiples"),
  investmentOpportunities: jsonb("investment_opportunities"),
  riskFactors: jsonb("risk_factors"),
  regulatoryEnvironment: text("regulatory_environment"),
  userId: integer("user_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertWarehouseSchema = createInsertSchema(warehouses).omit({
  id: true,
  createdAt: true,
});

export const insertDataSourceSchema = createInsertSchema(dataSources).omit({
  id: true,
  createdAt: true,
});

export const insertQueryHistorySchema = createInsertSchema(queryHistory).omit({
  id: true,
  executedAt: true,
});

export const insertChartSchema = createInsertSchema(charts).omit({
  id: true,
  createdAt: true,
});

export const insertDashboardSchema = createInsertSchema(dashboards).omit({
  id: true,
  createdAt: true,
});

export const insertAIConversationSchema = createInsertSchema(aiConversations).omit({
  id: true,
  createdAt: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Warehouse = typeof warehouses.$inferSelect;
export type InsertWarehouse = z.infer<typeof insertWarehouseSchema>;

export type DataSource = typeof dataSources.$inferSelect;
export type InsertDataSource = z.infer<typeof insertDataSourceSchema>;

export type QueryHistory = typeof queryHistory.$inferSelect;
export type InsertQueryHistory = z.infer<typeof insertQueryHistorySchema>;

export type Chart = typeof charts.$inferSelect;
export type InsertChart = z.infer<typeof insertChartSchema>;

export type Dashboard = typeof dashboards.$inferSelect;
export type InsertDashboard = z.infer<typeof insertDashboardSchema>;

export type AIConversation = typeof aiConversations.$inferSelect;
export type InsertAIConversation = z.infer<typeof insertAIConversationSchema>;
