import type { Express, Request } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { FileProcessor } from "./services/fileProcessor";
import { FileEncryption } from "./security";
import { setupAuth, requireAuth, hashPassword } from "./auth";
import passport from "passport";
import { SQLParser } from "./services/sqlParser";
import { processAIQuery, generateChartFromDescription, generateSQLFromNaturalLanguage } from "./services/ai";
import { insertDataSourceSchema, insertWarehouseSchema, insertChartSchema, insertQueryHistorySchema } from "@shared/schema";
import { z } from "zod";
import path from "path";
import fs from "fs";

interface MulterRequest extends Request {
  file?: Express.Multer.File;
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication
  await setupAuth(app);

  // Auth routes
  app.post('/api/auth/register', async (req, res) => {
    try {
      const { username, email, password } = req.body;
      
      if (!username || !password) {
        return res.status(400).json({ message: "Username and password required" });
      }

      // Check if user exists
      const existingUser = await storage.getUserByUsername(username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }

      // Create user
      const passwordHash = await hashPassword(password);
      const user = await storage.createUserWithPassword(username, email || "", passwordHash);
      
      // Auto-login
      req.login(user, (err) => {
        if (err) {
          return res.status(500).json({ message: "Registration successful but login failed" });
        }
        res.json({ user: { id: user.id, username: user.username, email: user.email } });
      });
    } catch (error) {
      console.error("Registration error:", error);
      res.status(500).json({ message: "Registration failed" });
    }
  });

  app.post('/api/auth/login', passport.authenticate('local'), (req, res) => {
    const user = req.user as any;
    res.json({ user: { id: user.id, username: user.username, email: user.email } });
  });

  app.post('/api/auth/logout', (req, res) => {
    req.logout(() => {
      res.json({ message: "Logged out" });
    });
  });

  app.get('/api/auth/user', (req, res) => {
    if (req.isAuthenticated()) {
      const user = req.user as any;
      res.json({ user: { id: user.id, username: user.username, email: user.email } });
    } else {
      res.status(401).json({ message: "Not authenticated" });
    }
  });
  const currentUserId = 1; // Simplified auth - using default user

  // Health check endpoint for Excel connectivity
  app.get("/api/health", async (req, res) => {
    res.json({ 
      status: "healthy", 
      timestamp: new Date().toISOString(),
      uptime: process.uptime(),
      version: "1.0.0"
    });
  });

  // Get current user
  app.get("/api/user", async (req, res) => {
    try {
      const user = await storage.getUser(currentUserId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: "Failed to get user" });
    }
  });

  // Warehouse management
  app.get("/api/warehouses", requireAuth, async (req, res) => {
    try {
      const user = req.user as any;
      const warehouses = await storage.getUserWarehouses(user.id);
      res.json(warehouses);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch warehouses" });
    }
  });

  app.post("/api/warehouses", requireAuth, async (req, res) => {
    try {
      const user = req.user as any;
      const validatedData = insertWarehouseSchema.parse({
        ...req.body,
        userId: user.id
      });
      const warehouse = await storage.createWarehouse(validatedData);
      res.json(warehouse);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid warehouse data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create warehouse" });
    }
  });

  app.put("/api/warehouses/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      const warehouse = await storage.updateWarehouse(id, updates);
      
      if (!warehouse) {
        return res.status(404).json({ message: "Warehouse not found" });
      }
      
      res.json(warehouse);
    } catch (error) {
      res.status(500).json({ message: "Failed to update warehouse" });
    }
  });

  // Data sources
  app.get("/api/data-sources", requireAuth, async (req, res) => {
    try {
      const user = req.user as any;
      const dataSources = await storage.getUserDataSources(user.id);
      res.json(dataSources);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch data sources" });
    }
  });

  app.post("/api/data-sources/upload", FileProcessor.upload.single('file'), async (req, res) => {
    try {
      const multerReq = req as MulterRequest;
      if (!multerReq.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      const processedFile = await FileProcessor.processFile(multerReq.file.path, multerReq.file.originalname);
      
      // Encrypt uploaded file for security
      FileEncryption.encryptFile(multerReq.file.path);
      
      const dataSource = await storage.createDataSource({
        name: processedFile.name,
        type: processedFile.type,
        fileName: multerReq.file.originalname,
        filePath: multerReq.file.path,
        schema: processedFile.schema,
        rowCount: processedFile.rowCount,
        status: "ready",
        userId: currentUserId
      });

      // Store processed data in memory (in real app, this would be in a database)
      (storage as any).processedData = (storage as any).processedData || new Map();
      (storage as any).processedData.set(dataSource.id, processedFile.data);

      res.json(dataSource);
    } catch (error) {
      console.error('Upload error:', error);
      res.status(500).json({ 
        message: "Failed to process file", 
        error: error instanceof Error ? error.message : "Unknown error" 
      });
    }
  });

  app.get("/api/data-sources/:id/data", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const limit = parseInt(req.query.limit as string) || 100;
      const offset = parseInt(req.query.offset as string) || 0;
      
      const dataSource = await storage.getDataSource(id);
      if (!dataSource) {
        return res.status(404).json({ message: "Data source not found" });
      }

      // Get processed data from memory
      const allData = (storage as any).processedData?.get(id) || [];
      const data = allData.slice(offset, offset + limit);
      
      res.json({
        data,
        totalRows: allData.length,
        columns: Object.keys(dataSource.schema || {}),
        schema: dataSource.schema
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch data" });
    }
  });

  // SQL query execution
  app.post("/api/sql/validate", async (req, res) => {
    try {
      const { query } = req.body;
      const result = SQLParser.validateSQL(query);
      res.json(result);
    } catch (error) {
      res.status(500).json({ message: "Failed to validate SQL" });
    }
  });

  app.post("/api/sql/execute", async (req, res) => {
    try {
      const { query, warehouseId, dataSourceId } = req.body;
      
      const warehouse = await storage.getWarehouse(warehouseId);
      if (!warehouse) {
        return res.status(404).json({ message: "Warehouse not found" });
      }

      const dataSource = await storage.getDataSource(dataSourceId);
      if (!dataSource) {
        return res.status(404).json({ message: "Data source not found" });
      }

      // Get data for query execution
      const data = (storage as any).processedData?.get(dataSourceId) || [];
      
      // Execute query
      const result = SQLParser.executeSQL(query, data, warehouse.size);
      
      // Save to query history
      await storage.createQueryHistory({
        sqlQuery: query,
        status: result.success ? "completed" : "error",
        duration: result.duration,
        rowsReturned: result.rowCount,
        creditsUsed: result.creditsUsed.toString(),
        warehouseId,
        userId: currentUserId
      });

      res.json(result);
    } catch (error) {
      res.status(500).json({ message: "Failed to execute query" });
    }
  });

  app.get("/api/sql/suggestions", async (req, res) => {
    try {
      const { query, dataSourceId } = req.query;
      
      if (!dataSourceId) {
        return res.status(400).json({ message: "Data source ID required" });
      }

      const dataSource = await storage.getDataSource(parseInt(dataSourceId as string));
      if (!dataSource) {
        return res.status(404).json({ message: "Data source not found" });
      }

      const suggestions = SQLParser.getSQLSuggestions(query as string, (dataSource.schema as Record<string, string>) || {});
      res.json({ suggestions });
    } catch (error) {
      res.status(500).json({ message: "Failed to get suggestions" });
    }
  });

  // Query history
  app.get("/api/query-history", async (req, res) => {
    try {
      const history = await storage.getUserQueryHistory(currentUserId);
      res.json(history);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch query history" });
    }
  });

  // AI Assistant
  app.post("/api/ai/chat", async (req, res) => {
    try {
      const { message, context } = req.body;
      
      const response = await processAIQuery(message, context || {});
      res.json(response);
    } catch (error) {
      console.error('AI chat error:', error);
      res.status(500).json({ message: "AI service temporarily unavailable" });
    }
  });

  app.post("/api/ai/generate-chart", async (req, res) => {
    try {
      const { description, dataSourceId } = req.body;
      
      const dataSource = await storage.getDataSource(dataSourceId);
      if (!dataSource) {
        return res.status(404).json({ message: "Data source not found" });
      }

      const sampleData = (storage as any).processedData?.get(dataSourceId)?.slice(0, 10) || [];
      
      const chartConfig = await generateChartFromDescription(description, {
        columns: Object.keys(dataSource.schema || {}),
        dataTypes: (dataSource.schema as Record<string, string>) || {},
        sampleData
      });

      res.json(chartConfig);
    } catch (error) {
      res.status(500).json({ message: "Failed to generate chart" });
    }
  });

  app.post("/api/ai/generate-sql", async (req, res) => {
    try {
      const { query, dataSourceId } = req.body;
      
      const dataSource = await storage.getDataSource(dataSourceId);
      if (!dataSource) {
        return res.status(404).json({ message: "Data source not found" });
      }

      const sqlQuery = await generateSQLFromNaturalLanguage(query, {
        tableName: dataSource.name.replace(/\s+/g, '_').toUpperCase(),
        columns: Object.keys(dataSource.schema || {}),
        dataTypes: (dataSource.schema as Record<string, string>) || {}
      });

      res.json({ sqlQuery });
    } catch (error) {
      res.status(500).json({ message: "Failed to generate SQL" });
    }
  });

  // Private Equity Analytics Routes
  app.post("/api/financial-analysis/valuation", async (req, res) => {
    try {
      const { FinancialAnalysisEngine } = await import('./services/financialAnalysis.js');
      const { financialMetrics, marketContext } = req.body;
      
      const valuation = await FinancialAnalysisEngine.generateInvestmentRecommendation(
        req.body.companyData,
        financialMetrics,
        marketContext
      );
      
      res.json(valuation);
    } catch (error) {
      console.error("Financial analysis error:", error);
      res.status(500).json({ message: "Failed to perform financial analysis" });
    }
  });

  app.post("/api/financial-analysis/due-diligence", async (req, res) => {
    try {
      const { FinancialAnalysisEngine } = await import('./services/financialAnalysis.js');
      const { companyData, financialData } = req.body;
      
      const dueDiligence = await FinancialAnalysisEngine.performDueDiligence(
        companyData,
        financialData
      );
      
      res.json(dueDiligence);
    } catch (error) {
      console.error("Due diligence error:", error);
      res.status(500).json({ message: "Failed to perform due diligence analysis" });
    }
  });

  app.post("/api/portfolio/analysis", async (req, res) => {
    try {
      const { PortfolioManagementEngine } = await import('./services/portfolioManagement.js');
      const { investments } = req.body;
      
      const metrics = await PortfolioManagementEngine.calculatePortfolioMetrics(investments);
      res.json(metrics);
    } catch (error) {
      console.error("Portfolio analysis error:", error);
      res.status(500).json({ message: "Failed to analyze portfolio" });
    }
  });

  app.post("/api/portfolio/opportunities", async (req, res) => {
    try {
      const { PortfolioManagementEngine } = await import('./services/portfolioManagement.js');
      const { sector, stage, targetReturn } = req.body;
      
      const opportunities = await PortfolioManagementEngine.identifyInvestmentOpportunities(
        sector, stage, targetReturn
      );
      
      res.json(opportunities);
    } catch (error) {
      console.error("Investment opportunities error:", error);
      res.status(500).json({ message: "Failed to identify opportunities" });
    }
  });

  app.post("/api/market-intelligence/sector-analysis", async (req, res) => {
    try {
      const { MarketIntelligenceEngine } = await import('./services/marketIntelligence.js');
      const { sector, region } = req.body;
      
      const analysis = await MarketIntelligenceEngine.analyzeSector(sector, region);
      res.json(analysis);
    } catch (error) {
      console.error("Sector analysis error:", error);
      res.status(500).json({ message: "Failed to analyze sector" });
    }
  });

  app.post("/api/risk-management/assess", async (req, res) => {
    try {
      const { RiskManagementEngine } = await import('./services/riskManagement.js');
      const { financialData, marketData } = req.body;
      
      const riskProfile = await RiskManagementEngine.assessRiskProfile(financialData, marketData);
      res.json(riskProfile);
    } catch (error) {
      console.error("Risk assessment error:", error);
      res.status(500).json({ message: "Failed to assess risk profile" });
    }
  });

  // Financial Document Processing
  app.post("/api/documents/upload", FileProcessor.upload.single('document'), async (req: MulterRequest, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      const { FinancialDocumentProcessor } = await import('./services/financialDocumentProcessor.js');
      const { documentType = 'other' } = req.body;
      
      const processedDocument = await FinancialDocumentProcessor.processFinancialDocument(
        req.file.path,
        req.file.originalname,
        documentType
      );
      
      res.json(processedDocument);
    } catch (error) {
      console.error("Document processing error:", error);
      res.status(500).json({ message: "Failed to process document" });
    }
  });

  app.post("/api/documents/analyze", async (req, res) => {
    try {
      const { FinancialDocumentProcessor } = await import('./services/financialDocumentProcessor.js');
      const { documents } = req.body;
      
      const analysis = await FinancialDocumentProcessor.performFinancialStatementAnalysis(documents);
      res.json(analysis);
    } catch (error) {
      console.error("Document analysis error:", error);
      res.status(500).json({ message: "Failed to analyze documents" });
    }
  });

  app.post("/api/predictive/analyze", async (req, res) => {
    try {
      const { FinancialDocumentProcessor } = await import('./services/financialDocumentProcessor.js');
      const { historicalData, marketContext } = req.body;
      
      const predictiveAnalysis = await FinancialDocumentProcessor.generatePredictiveAnalysis(historicalData, marketContext);
      res.json(predictiveAnalysis);
    } catch (error) {
      console.error("Predictive analysis error:", error);
      res.status(500).json({ message: "Failed to generate predictive analysis" });
    }
  });

  app.post("/api/insights/generate", async (req, res) => {
    try {
      const { FinancialDocumentProcessor } = await import('./services/financialDocumentProcessor.js');
      const { dataAnalysis, chartType } = req.body;
      
      const insights = await FinancialDocumentProcessor.generateDataInsights(dataAnalysis, chartType);
      res.json({ insights });
    } catch (error) {
      console.error("Insights generation error:", error);
      res.status(500).json({ message: "Failed to generate insights" });
    }
  });

  // Report Generation and Export
  app.post("/api/reports/export", async (req, res) => {
    try {
      const { ReportGenerator } = await import('./services/reportGenerator.js');
      const { reportData, format } = req.body;
      
      let buffer: Buffer;
      let contentType: string;
      let filename: string;
      
      switch (format) {
        case 'excel':
          buffer = await ReportGenerator.generateExcelReport(reportData);
          contentType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
          filename = `${reportData.title.replace(/\s+/g, '_')}_Report.xlsx`;
          break;
        case 'pdf':
          buffer = await ReportGenerator.generatePDFReport(reportData);
          contentType = 'text/html'; // Will be converted to PDF on client side
          filename = `${reportData.title.replace(/\s+/g, '_')}_Report.html`;
          break;
        case 'powerpoint':
          buffer = await ReportGenerator.generatePowerPointReport(reportData);
          contentType = 'application/json';
          filename = `${reportData.title.replace(/\s+/g, '_')}_Report.json`;
          break;
        case 'csv':
          buffer = await ReportGenerator.generateCSVReport(reportData);
          contentType = 'text/csv';
          filename = `${reportData.title.replace(/\s+/g, '_')}_Report.csv`;
          break;
        default:
          return res.status(400).json({ message: "Unsupported format" });
      }
      
      res.setHeader('Content-Type', contentType);
      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      res.send(buffer);
    } catch (error) {
      console.error("Report export error:", error);
      res.status(500).json({ message: "Failed to export report" });
    }
  });

  // Charts
  app.get("/api/charts", async (req, res) => {
    try {
      const charts = await storage.getUserCharts(currentUserId);
      res.json(charts);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch charts" });
    }
  });

  app.post("/api/charts", async (req, res) => {
    try {
      const validatedData = insertChartSchema.parse({
        ...req.body,
        userId: currentUserId
      });
      const chart = await storage.createChart(validatedData);
      res.json(chart);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid chart data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create chart" });
    }
  });

  // Dashboards
  app.get("/api/dashboards", async (req, res) => {
    try {
      const dashboards = await storage.getUserDashboards(currentUserId);
      res.json(dashboards);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch dashboards" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
