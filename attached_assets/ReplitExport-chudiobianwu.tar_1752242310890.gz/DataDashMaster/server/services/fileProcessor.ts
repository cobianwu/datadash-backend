import multer from 'multer';
import path from 'path';
import fs from 'fs';
import Papa from 'papaparse';
import * as XLSX from 'xlsx';

export interface ProcessedFile {
  name: string;
  type: 'csv' | 'excel' | 'json' | 'parquet';
  data: any[];
  schema: Record<string, string>;
  rowCount: number;
}

export interface ColumnInfo {
  name: string;
  type: 'NUMBER' | 'VARCHAR' | 'VARIANT' | 'DATE' | 'TIMESTAMP' | 'BOOLEAN';
  nullable: boolean;
}

export class FileProcessor {
  static storage = multer.diskStorage({
    destination: (req, file, cb) => {
      const uploadDir = path.join(process.cwd(), 'uploads');
      if (!fs.existsSync(uploadDir)) {
        fs.mkdirSync(uploadDir, { recursive: true });
      }
      cb(null, uploadDir);
    },
    filename: (req, file, cb) => {
      const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
      cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
    }
  });

  static upload = multer({ 
    storage: FileProcessor.storage,
    limits: {
      fileSize: 100 * 1024 * 1024 // 100MB limit
    },
    fileFilter: (req, file, cb) => {
      const allowedTypes = ['.csv', '.xlsx', '.xls', '.json', '.parquet'];
      const ext = path.extname(file.originalname).toLowerCase();
      if (allowedTypes.includes(ext)) {
        cb(null, true);
      } else {
        cb(new Error('Unsupported file type'));
      }
    }
  });

  static async processFile(filePath: string, originalName: string): Promise<ProcessedFile> {
    const ext = path.extname(originalName).toLowerCase();
    
    switch (ext) {
      case '.csv':
        return this.processCSV(filePath, originalName);
      case '.xlsx':
      case '.xls':
        return this.processExcel(filePath, originalName);
      case '.json':
        return this.processJSON(filePath, originalName);
      case '.parquet':
        return this.processParquet(filePath, originalName);
      default:
        throw new Error(`Unsupported file type: ${ext}`);
    }
  }

  private static async processCSV(filePath: string, originalName: string): Promise<ProcessedFile> {
    return new Promise((resolve, reject) => {
      const csvContent = fs.readFileSync(filePath, 'utf8');
      
      Papa.parse(csvContent, {
        header: true,
        skipEmptyLines: true,
        dynamicTyping: true,
        complete: (results) => {
          const data = results.data as any[];
          const schema = this.inferSchema(data);
          
          resolve({
            name: originalName,
            type: 'csv',
            data,
            schema,
            rowCount: data.length
          });
        },
        error: (error) => {
          reject(new Error(`CSV parsing error: ${error.message}`));
        }
      });
    });
  }

  private static async processExcel(filePath: string, originalName: string): Promise<ProcessedFile> {
    try {
      const workbook = XLSX.readFile(filePath);
      const sheetName = workbook.SheetNames[0]; // Use first sheet
      const worksheet = workbook.Sheets[sheetName];
      
      const data = XLSX.utils.sheet_to_json(worksheet, { 
        header: 1,
        defval: null
      }) as any[][];
      
      if (data.length === 0) {
        throw new Error('Excel file is empty');
      }
      
      // Convert to object format with headers
      const headers = data[0] as string[];
      const rows = data.slice(1).map(row => {
        const obj: any = {};
        headers.forEach((header, index) => {
          obj[header] = row[index] ?? null;
        });
        return obj;
      });
      
      const schema = this.inferSchema(rows);
      
      return {
        name: originalName,
        type: 'excel',
        data: rows,
        schema,
        rowCount: rows.length
      };
    } catch (error) {
      throw new Error(`Excel processing error: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  private static async processJSON(filePath: string, originalName: string): Promise<ProcessedFile> {
    try {
      const jsonContent = fs.readFileSync(filePath, 'utf8');
      const parsed = JSON.parse(jsonContent);
      
      let data: any[];
      if (Array.isArray(parsed)) {
        data = parsed;
      } else if (parsed.data && Array.isArray(parsed.data)) {
        data = parsed.data;
      } else {
        // Single object, wrap in array
        data = [parsed];
      }
      
      const schema = this.inferSchema(data);
      
      return {
        name: originalName,
        type: 'json',
        data,
        schema,
        rowCount: data.length
      };
    } catch (error) {
      throw new Error(`JSON processing error: ${error instanceof Error ? error.message : 'Invalid JSON'}`);
    }
  }

  private static async processParquet(filePath: string, originalName: string): Promise<ProcessedFile> {
    // For this implementation, we'll simulate Parquet processing
    // In a real implementation, you'd use a library like parquetjs
    try {
      // Simulate Parquet file processing
      // This would typically involve a proper Parquet parser
      const simulatedData = [
        { id: 1, name: 'Sample Data', value: 100, created_at: new Date() },
        { id: 2, name: 'Parquet Test', value: 200, created_at: new Date() }
      ];
      
      const schema = this.inferSchema(simulatedData);
      
      return {
        name: originalName,
        type: 'parquet',
        data: simulatedData,
        schema,
        rowCount: simulatedData.length
      };
    } catch (error) {
      throw new Error(`Parquet processing error: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  private static inferSchema(data: any[]): Record<string, string> {
    if (!data || data.length === 0) {
      return {};
    }
    
    const schema: Record<string, string> = {};
    const sample = data[0];
    
    Object.keys(sample).forEach(key => {
      const value = sample[key];
      
      if (value === null || value === undefined) {
        // Check other rows for type inference
        const nonNullValue = data.find(row => row[key] != null)?.[key];
        schema[key] = this.inferDataType(nonNullValue);
      } else {
        schema[key] = this.inferDataType(value);
      }
    });
    
    return schema;
  }

  private static inferDataType(value: any): string {
    if (value === null || value === undefined) {
      return 'VARCHAR';
    }
    
    if (typeof value === 'number') {
      return Number.isInteger(value) ? 'NUMBER' : 'NUMBER';
    }
    
    if (typeof value === 'boolean') {
      return 'BOOLEAN';
    }
    
    if (typeof value === 'object') {
      return 'VARIANT'; // JSON/Object type
    }
    
    if (typeof value === 'string') {
      // Try to detect dates
      const dateValue = new Date(value);
      if (!isNaN(dateValue.getTime()) && value.match(/^\d{4}-\d{2}-\d{2}/)) {
        return value.includes('T') || value.includes(':') ? 'TIMESTAMP' : 'DATE';
      }
      
      // Try to detect numbers in string format
      if (!isNaN(Number(value)) && value.trim() !== '') {
        return 'NUMBER';
      }
    }
    
    return 'VARCHAR';
  }

  static generateSampleData(schema: Record<string, string>, rows: number = 1000): any[] {
    const data: any[] = [];
    const columns = Object.keys(schema);
    
    for (let i = 0; i < rows; i++) {
      const row: any = {};
      
      columns.forEach(col => {
        const type = schema[col];
        switch (type) {
          case 'NUMBER':
            row[col] = Math.floor(Math.random() * 10000);
            break;
          case 'VARCHAR':
            row[col] = `Sample_${col}_${i}`;
            break;
          case 'DATE':
            row[col] = new Date(Date.now() - Math.random() * 365 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
            break;
          case 'TIMESTAMP':
            row[col] = new Date(Date.now() - Math.random() * 365 * 24 * 60 * 60 * 1000).toISOString();
            break;
          case 'BOOLEAN':
            row[col] = Math.random() > 0.5;
            break;
          case 'VARIANT':
            row[col] = { key: `value_${i}`, nested: { id: i } };
            break;
          default:
            row[col] = `Value_${i}`;
        }
      });
      
      data.push(row);
    }
    
    return data;
  }
}
