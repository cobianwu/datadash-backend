import OpenAI from "openai";

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export interface SectorAnalysis {
  sector: string;
  marketSize: number;
  growthRate: number;
  profitability: number;
  competitionLevel: number;
  barrierToEntry: number;
  cyclicality: number;
  regulatoryRisk: number;
  investmentAttractiveness: number; // 1-10 scale
  keyDrivers: string[];
  majorPlayers: string[];
  trends: string[];
  risks: string[];
}

export interface ValuationBenchmarks {
  sector: string;
  region: string;
  medianMultiples: {
    evRevenue: number;
    evEbitda: number;
    peRatio: number;
    pegRatio: number;
    priceToBook: number;
    evSales: number;
  };
  quartileData: {
    q1: Record<string, number>;
    q3: Record<string, number>;
  };
  recentTransactions: Array<{
    target: string;
    acquirer: string;
    value: number;
    evRevenue: number;
    evEbitda: number;
    date: Date;
  }>;
}

export interface MacroeconomicFactors {
  region: string;
  gdpGrowth: number;
  inflationRate: number;
  interestRates: number;
  unemploymentRate: number;
  consumerConfidence: number;
  businessConfidence: number;
  currencyStrength: number;
  marketVolatility: number;
  investmentClimate: string;
  keyRisks: string[];
  opportunities: string[];
}

export interface IndustryForecast {
  sector: string;
  timeHorizon: string; // '1Y', '3Y', '5Y'
  growthProjection: number;
  profitabilityTrend: 'IMPROVING' | 'STABLE' | 'DECLINING';
  consolidationActivity: 'HIGH' | 'MEDIUM' | 'LOW';
  disruptionRisk: number; // 1-10 scale
  technologyImpact: string;
  regulatoryChanges: string[];
  investmentThemes: string[];
  exitOpportunities: string[];
}

export class MarketIntelligenceEngine {
  
  static async analyzeSector(sector: string, region: string): Promise<SectorAnalysis> {
    try {
      const prompt = `
        Provide comprehensive sector analysis for ${sector} in ${region}:
        
        Analyze the following dimensions (scores 1-10, 10 being best for investment):
        - Market size and growth potential
        - Profitability and margins
        - Competition intensity (lower score = more competition)
        - Barriers to entry (higher score = stronger barriers)
        - Cyclicality (lower score = more cyclical)
        - Regulatory risk (lower score = higher risk)
        - Overall investment attractiveness
        
        Provide analysis in JSON format:
        {
          "sector": "${sector}",
          "marketSize": dollar_value,
          "growthRate": percentage,
          "profitability": 1-10,
          "competitionLevel": 1-10,
          "barrierToEntry": 1-10,
          "cyclicality": 1-10,
          "regulatoryRisk": 1-10,
          "investmentAttractiveness": 1-10,
          "keyDrivers": ["driver1", "driver2"],
          "majorPlayers": ["company1", "company2"],
          "trends": ["trend1", "trend2"],
          "risks": ["risk1", "risk2"],
          "opportunities": ["opportunity1", "opportunity2"]
        }
      `;

      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [{ role: "user", content: prompt }],
        response_format: { type: "json_object" },
      });

      const analysis = JSON.parse(response.choices[0].message.content);
      
      return {
        sector: analysis.sector,
        marketSize: analysis.marketSize,
        growthRate: analysis.growthRate,
        profitability: analysis.profitability,
        competitionLevel: analysis.competitionLevel,
        barrierToEntry: analysis.barrierToEntry,
        cyclicality: analysis.cyclicality,
        regulatoryRisk: analysis.regulatoryRisk,
        investmentAttractiveness: analysis.investmentAttractiveness,
        keyDrivers: analysis.keyDrivers,
        majorPlayers: analysis.majorPlayers,
        trends: analysis.trends,
        risks: analysis.risks
      };
    } catch (error) {
      throw new Error("Failed to analyze sector: " + error.message);
    }
  }

  static async getValuationBenchmarks(sector: string, region: string): Promise<ValuationBenchmarks> {
    try {
      const prompt = `
        Provide current valuation benchmarks for ${sector} companies in ${region}:
        
        Include:
        - Median trading multiples for public companies
        - Recent M&A transaction multiples
        - Quartile data (25th and 75th percentiles)
        - Notable recent transactions
        
        Provide data in JSON format:
        {
          "sector": "${sector}",
          "region": "${region}",
          "medianMultiples": {
            "evRevenue": multiple,
            "evEbitda": multiple,
            "peRatio": multiple,
            "pegRatio": multiple,
            "priceToBook": multiple,
            "evSales": multiple
          },
          "quartileData": {
            "q1": {
              "evRevenue": multiple,
              "evEbitda": multiple,
              "peRatio": multiple
            },
            "q3": {
              "evRevenue": multiple,
              "evEbitda": multiple,
              "peRatio": multiple
            }
          },
          "recentTransactions": [
            {
              "target": "Company Name",
              "acquirer": "Acquirer Name",
              "value": dollar_amount,
              "evRevenue": multiple,
              "evEbitda": multiple,
              "date": "YYYY-MM-DD"
            }
          ]
        }
      `;

      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [{ role: "user", content: prompt }],
        response_format: { type: "json_object" },
      });

      const data = JSON.parse(response.choices[0].message.content);
      
      return {
        sector: data.sector,
        region: data.region,
        medianMultiples: data.medianMultiples,
        quartileData: data.quartileData,
        recentTransactions: data.recentTransactions.map((tx: any) => ({
          ...tx,
          date: new Date(tx.date)
        }))
      };
    } catch (error) {
      throw new Error("Failed to get valuation benchmarks: " + error.message);
    }
  }

  static async analyzeMacroeconomicFactors(region: string): Promise<MacroeconomicFactors> {
    try {
      const prompt = `
        Analyze current macroeconomic conditions in ${region} for private equity investment:
        
        Provide comprehensive macroeconomic analysis in JSON format:
        {
          "region": "${region}",
          "gdpGrowth": percentage,
          "inflationRate": percentage,
          "interestRates": percentage,
          "unemploymentRate": percentage,
          "consumerConfidence": index_value,
          "businessConfidence": index_value,
          "currencyStrength": relative_strength,
          "marketVolatility": percentage,
          "investmentClimate": "FAVORABLE|NEUTRAL|CHALLENGING",
          "keyRisks": ["risk1", "risk2"],
          "opportunities": ["opportunity1", "opportunity2"],
          "centralBankPolicy": "analysis",
          "fiscalPolicy": "analysis",
          "tradePolicy": "analysis"
        }
      `;

      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [{ role: "user", content: prompt }],
        response_format: { type: "json_object" },
      });

      const analysis = JSON.parse(response.choices[0].message.content);
      
      return {
        region: analysis.region,
        gdpGrowth: analysis.gdpGrowth,
        inflationRate: analysis.inflationRate,
        interestRates: analysis.interestRates,
        unemploymentRate: analysis.unemploymentRate,
        consumerConfidence: analysis.consumerConfidence,
        businessConfidence: analysis.businessConfidence,
        currencyStrength: analysis.currencyStrength,
        marketVolatility: analysis.marketVolatility,
        investmentClimate: analysis.investmentClimate,
        keyRisks: analysis.keyRisks,
        opportunities: analysis.opportunities
      };
    } catch (error) {
      throw new Error("Failed to analyze macroeconomic factors: " + error.message);
    }
  }

  static async generateIndustryForecast(sector: string, timeHorizon: string): Promise<IndustryForecast> {
    try {
      const prompt = `
        Generate ${timeHorizon} industry forecast for ${sector}:
        
        Consider:
        - Technology disruption potential
        - Regulatory changes
        - Market consolidation trends
        - Investment themes
        - Exit opportunities
        
        Provide forecast in JSON format:
        {
          "sector": "${sector}",
          "timeHorizon": "${timeHorizon}",
          "growthProjection": percentage,
          "profitabilityTrend": "IMPROVING|STABLE|DECLINING",
          "consolidationActivity": "HIGH|MEDIUM|LOW",
          "disruptionRisk": 1-10,
          "technologyImpact": "detailed analysis",
          "regulatoryChanges": ["change1", "change2"],
          "investmentThemes": ["theme1", "theme2"],
          "exitOpportunities": ["opportunity1", "opportunity2"],
          "keyMetrics": {
            "expected_irr": percentage,
            "multiple_range": "low-high",
            "hold_period": years
          },
          "recommendations": ["rec1", "rec2"]
        }
      `;

      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [{ role: "user", content: prompt }],
        response_format: { type: "json_object" },
      });

      const forecast = JSON.parse(response.choices[0].message.content);
      
      return {
        sector: forecast.sector,
        timeHorizon: forecast.timeHorizon,
        growthProjection: forecast.growthProjection,
        profitabilityTrend: forecast.profitabilityTrend,
        consolidationActivity: forecast.consolidationActivity,
        disruptionRisk: forecast.disruptionRisk,
        technologyImpact: forecast.technologyImpact,
        regulatoryChanges: forecast.regulatoryChanges,
        investmentThemes: forecast.investmentThemes,
        exitOpportunities: forecast.exitOpportunities
      };
    } catch (error) {
      throw new Error("Failed to generate industry forecast: " + error.message);
    }
  }

  static async identifyMarketOpportunities(
    investmentCriteria: any,
    riskTolerance: number
  ): Promise<any[]> {
    try {
      const prompt = `
        Identify market opportunities based on these investment criteria:
        ${JSON.stringify(investmentCriteria)}
        Risk Tolerance: ${riskTolerance}/10
        
        Provide 10 high-quality opportunities in JSON format:
        {
          "opportunities": [
            {
              "sector": "sector name",
              "subsector": "specific area",
              "investmentThesis": "why this is attractive",
              "marketSize": dollar_value,
              "growthRate": percentage,
              "competitionLevel": 1-10,
              "entryBarriers": 1-10,
              "expectedReturns": percentage,
              "riskFactors": ["risk1", "risk2"],
              "keySuccess": ["factor1", "factor2"],
              "timeToExit": years,
              "capitalRequired": dollar_amount
            }
          ]
        }
      `;

      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [{ role: "user", content: prompt }],
        response_format: { type: "json_object" },
      });

      const data = JSON.parse(response.choices[0].message.content);
      return data.opportunities;
    } catch (error) {
      throw new Error("Failed to identify market opportunities: " + error.message);
    }
  }

  static async trackCompetitorActivity(sector: string): Promise<any> {
    try {
      const prompt = `
        Track recent competitor activity in ${sector}:
        
        Provide competitor intelligence in JSON format:
        {
          "sector": "${sector}",
          "recentDeals": [
            {
              "acquirer": "company name",
              "target": "target company",
              "value": dollar_amount,
              "rationale": "strategic reasoning",
              "date": "YYYY-MM-DD"
            }
          ],
          "fundingRounds": [
            {
              "company": "company name",
              "stage": "series_x",
              "amount": dollar_amount,
              "valuation": dollar_amount,
              "investors": ["investor1", "investor2"]
            }
          ],
          "marketMovements": [
            {
              "company": "company name",
              "movement": "description",
              "impact": "analysis"
            }
          ],
          "emergingPlayers": ["company1", "company2"],
          "consolidationTrends": "analysis"
        }
      `;

      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [{ role: "user", content: prompt }],
        response_format: { type: "json_object" },
      });

      return JSON.parse(response.choices[0].message.content);
    } catch (error) {
      throw new Error("Failed to track competitor activity: " + error.message);
    }
  }
}