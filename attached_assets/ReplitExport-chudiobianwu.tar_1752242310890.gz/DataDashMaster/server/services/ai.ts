import OpenAI from "openai";
import { CONFIG } from "../config";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});

const SECURITY_MODE = CONFIG.SECURITY_MODE;

export interface AIResponse {
  message: string;
  suggestions?: string[];
  chartConfig?: any;
  sqlQuery?: string;
  type: 'text' | 'chart' | 'sql' | 'dashboard';
}

export async function processAIQuery(
  userMessage: string,
  context: {
    currentData?: any;
    availableColumns?: string[];
    dataTypes?: Record<string, string>;
  }
): Promise<AIResponse> {
  if (SECURITY_MODE || !CONFIG.OPENAI_ENABLED) {
    // Local analysis without external data sharing
    return generateLocalAnalysis(userMessage, context);
  }
  
  // Full OpenAI analysis
  try {
    const systemPrompt = `You are an AI assistant for a data analytics platform similar to Snowflake Sigma. 
    You help users analyze data, create visualizations, and write SQL queries.
    
    Available data context:
    ${context.availableColumns ? `Columns: ${context.availableColumns.join(', ')}` : ''}
    ${context.dataTypes ? `Data types: ${JSON.stringify(context.dataTypes)}` : ''}
    
    Based on the user's request, respond with:
    1. A helpful message
    2. If they want a chart, provide chart configuration
    3. If they want SQL, provide a query
    4. If they want a dashboard, provide layout suggestions
    
    Response format should be JSON with fields: message, type, chartConfig (if chart), sqlQuery (if SQL), suggestions (array of follow-up suggestions).`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userMessage }
      ],
      response_format: { type: "json_object" },
      temperature: 0.7,
      max_tokens: 1000
    });

    const result = JSON.parse(response.choices[0].message.content || '{}');
    
    return {
      message: result.message || "I can help you analyze your data.",
      type: result.type || 'text',
      chartConfig: result.chartConfig,
      sqlQuery: result.sqlQuery,
      suggestions: result.suggestions || [
        "Show me sales trends",
        "Create a dashboard", 
        "Analyze top performers"
      ]
    };
  } catch (error) {
    console.error('AI processing error:', error);
    return generateLocalAnalysis(userMessage, context);
  }
}

function generateLocalAnalysis(userMessage: string, context: any): AIResponse {
  const message = userMessage.toLowerCase();
  
  // Pattern matching for common analytics requests
  if (message.includes('chart') || message.includes('visualiz') || message.includes('graph')) {
    return {
      message: "Based on your data structure, I recommend creating a visualization. Here's a suggested chart configuration:",
      type: 'chart',
      chartConfig: {
        type: message.includes('pie') ? 'pie' : 
              message.includes('line') ? 'line' : 
              message.includes('scatter') ? 'scatter' : 'bar',
        xField: context.availableColumns?.[0] || 'category',
        yField: context.availableColumns?.[1] || 'value'
      },
      suggestions: [
        "Try different chart types for your data",
        "Add filters to focus on specific data ranges",
        "Export this chart to Excel or PDF"
      ]
    };
  }
  
  if (message.includes('sql') || message.includes('query') || message.includes('select')) {
    const columns = context.availableColumns || ['column1', 'column2'];
    return {
      message: "Here's a SQL query based on your request:",
      type: 'sql',
      sqlQuery: `SELECT ${columns.slice(0, 3).join(', ')} FROM your_table LIMIT 100;`,
      suggestions: [
        "Add WHERE clause to filter results",
        "Use GROUP BY for aggregations",
        "Join with other tables for comprehensive analysis"
      ]
    };
  }
  
  return {
    message: "I can help you analyze your data using local processing. Your data stays secure and private. What would you like to explore?",
    type: 'text',
    suggestions: [
      "Create a chart from your data",
      "Generate SQL queries for analysis",
      "Export results to Excel or PDF"
    ]
  };
}

export async function generateChartFromDescription(
  description: string,
  dataContext: {
    columns: string[];
    dataTypes: Record<string, string>;
    sampleData?: any[];
  }
): Promise<any> {
  if (SECURITY_MODE || !CONFIG.FEATURES.AI_CHART_GENERATION) {
    return generateLocalChartConfig(description, dataContext);
  }
  
  // Full OpenAI chart generation
  try {
    const systemPrompt = `You are a chart configuration generator. Based on the user's description and available data, 
    create a chart configuration object for a data visualization library.
    
    Available columns: ${dataContext.columns.join(', ')}
    Data types: ${JSON.stringify(dataContext.dataTypes)}
    
    Return a JSON configuration object with:
    - type: chart type (bar, line, pie, scatter, heatmap, treemap)
    - xAxis: column for x-axis
    - yAxis: column for y-axis (with aggregation if needed)
    - groupBy: optional grouping column
    - title: chart title
    - colors: array of color values
    
    Choose appropriate chart types based on data types and user intent.`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: description }
      ],
      response_format: { type: "json_object" },
      temperature: 0.3
    });

    return JSON.parse(response.choices[0].message.content || '{}');
  } catch (error) {
    console.error('Chart generation error:', error);
    return generateLocalChartConfig(description, dataContext);
  }
}

function generateLocalChartConfig(description: string, dataContext: any) {
  const desc = description.toLowerCase();
  const { columns, dataTypes } = dataContext;
  
  // Smart chart type selection based on keywords and data types
  let chartType = 'bar'; // default
  
  if (desc.includes('pie') || desc.includes('proportion') || desc.includes('percentage')) {
    chartType = 'pie';
  } else if (desc.includes('line') || desc.includes('trend') || desc.includes('time')) {
    chartType = 'line';
  } else if (desc.includes('scatter') || desc.includes('correlation')) {
    chartType = 'scatter';
  }
  
  // Select appropriate columns
  const numericColumns = columns.filter(col => 
    dataTypes[col] === 'number' || dataTypes[col] === 'NUMBER'
  );
  const categoryColumns = columns.filter(col => 
    dataTypes[col] === 'string' || dataTypes[col] === 'VARCHAR'
  );
  
  return {
    type: chartType,
    title: `Chart: ${description}`,
    xAxis: categoryColumns[0] || columns[0] || 'category',
    yAxis: numericColumns[0] || columns[1] || 'value',
    colors: ['#1e3a8a', '#3b82f6', '#60a5fa', '#93c5fd']
  };
}

export async function generateSQLFromNaturalLanguage(
  query: string,
  context: {
    tableName: string;
    columns: string[];
    dataTypes: Record<string, string>;
  }
): Promise<string> {
  if (SECURITY_MODE || !CONFIG.FEATURES.AI_SQL_GENERATION) {
    return generateLocalSQL(query, context);
  }
  
  // Full OpenAI SQL generation
  try {
    const systemPrompt = `You are a SQL query generator for Snowflake. Convert natural language questions into valid SQL queries.
    
    Table: ${context.tableName}
    Columns: ${context.columns.join(', ')}
    Data types: ${JSON.stringify(context.dataTypes)}
    
    Generate valid Snowflake SQL with proper syntax. Use appropriate aggregation functions (SUM, AVG, COUNT, etc.) and window functions when needed.
    Support semi-structured data with PARSE_JSON() and TYPEOF() functions for VARIANT columns.
    
    Return only the SQL query, properly formatted.`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: query }
      ],
      temperature: 0.1,
      max_tokens: 500
    });

    return response.choices[0].message.content?.trim() || 
           generateLocalSQL(query, context);
  } catch (error) {
    console.error('SQL generation error:', error);
    return generateLocalSQL(query, context);
  }
}

function generateLocalSQL(query: string, context: any): string {
  const q = query.toLowerCase();
  const { tableName, columns } = context;
  
  // Pattern matching for common SQL operations
  if (q.includes('count') || q.includes('how many')) {
    return `SELECT COUNT(*) as total_count FROM ${tableName};`;
  }
  
  if (q.includes('average') || q.includes('avg')) {
    const numericCol = columns.find(col => 
      context.dataTypes[col] === 'number' || context.dataTypes[col] === 'NUMBER'
    ) || columns[1];
    return `SELECT AVG(${numericCol}) as average FROM ${tableName};`;
  }
  
  if (q.includes('sum') || q.includes('total')) {
    const numericCol = columns.find(col => 
      context.dataTypes[col] === 'number' || context.dataTypes[col] === 'NUMBER'
    ) || columns[1];
    return `SELECT SUM(${numericCol}) as total FROM ${tableName};`;
  }
  
  if (q.includes('group by') || q.includes('by category')) {
    const categoryCol = columns.find(col => 
      context.dataTypes[col] === 'string' || context.dataTypes[col] === 'VARCHAR'
    ) || columns[0];
    return `SELECT ${categoryCol}, COUNT(*) as count FROM ${tableName} GROUP BY ${categoryCol};`;
  }
  
  // Default: select top records
  const topColumns = columns.slice(0, 5).join(', ');
  return `SELECT ${topColumns} FROM ${tableName} LIMIT 100;`;
}
