import OpenAI from "openai";

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export interface PortfolioMetrics {
  totalValue: number;
  totalInvested: number;
  unrealizedGains: number;
  realizedGains: number;
  irr: number; // Internal Rate of Return
  moic: number; // Multiple on Invested Capital
  dpi: number; // Distributions to Paid-In
  rvpi: number; // Residual Value to Paid-In
  tvpi: number; // Total Value to Paid-In
}

export interface InvestmentOpportunity {
  companyName: string;
  sector: string;
  stage: string;
  valuation: number;
  fundingRound: number;
  projectedIRR: number;
  riskScore: number;
  recommendation: 'STRONG_BUY' | 'BUY' | 'HOLD' | 'PASS';
  rationale: string;
  keyMetrics: Record<string, number>;
}

export interface ExitStrategy {
  investmentId: number;
  exitType: 'IPO' | 'STRATEGIC_SALE' | 'SECONDARY_SALE' | 'MANAGEMENT_BUYOUT';
  estimatedValuation: number;
  projectedMultiple: number;
  timeToExit: number; // months
  exitProbability: number;
  keyFactors: string[];
  recommendedActions: string[];
}

export interface CompetitiveAnalysis {
  sector: string;
  marketPosition: number; // 1-10 scale
  competitiveAdvantages: string[];
  threats: string[];
  marketShare: number;
  moatStrength: number; // 1-10 scale
  competitorAnalysis: Array<{
    name: string;
    marketShare: number;
    valuation: number;
    strengths: string[];
    weaknesses: string[];
  }>;
}

export class PortfolioManagementEngine {
  
  static async calculatePortfolioMetrics(investments: any[]): Promise<PortfolioMetrics> {
    let totalInvested = 0;
    let currentValue = 0;
    let realizedGains = 0;
    let cashFlows: Array<{ date: Date; amount: number }> = [];

    investments.forEach(inv => {
      totalInvested += inv.investmentAmount;
      
      if (inv.status === 'exited') {
        realizedGains += (inv.exitAmount - inv.investmentAmount);
        cashFlows.push({ date: new Date(inv.exitDate), amount: inv.exitAmount });
      } else {
        currentValue += inv.currentValuation * (inv.ownershipPercentage / 100);
      }
      
      // Add investment cash flow
      cashFlows.push({ date: new Date(inv.investmentDate), amount: -inv.investmentAmount });
    });

    const unrealizedGains = currentValue - (totalInvested - this.getInvestedInExited(investments));
    const totalValue = currentValue + realizedGains;
    
    // Calculate IRR using cash flows
    const irr = this.calculateIRR(cashFlows);
    
    // Calculate private equity metrics
    const moic = totalValue / totalInvested;
    const dpi = realizedGains / totalInvested;
    const rvpi = currentValue / totalInvested;
    const tvpi = dpi + rvpi;

    return {
      totalValue,
      totalInvested,
      unrealizedGains,
      realizedGains,
      irr,
      moic,
      dpi,
      rvpi,
      tvpi
    };
  }

  static async identifyInvestmentOpportunities(
    sector: string,
    stage: string,
    targetReturn: number
  ): Promise<InvestmentOpportunity[]> {
    try {
      const prompt = `
        Identify high-quality investment opportunities for a private equity fund:
        
        Criteria:
        - Sector: ${sector}
        - Stage: ${stage}
        - Target IRR: ${targetReturn}%
        
        Provide 5 investment opportunities in JSON format:
        [
          {
            "companyName": "Company Name",
            "sector": "${sector}",
            "stage": "${stage}",
            "valuation": market_value,
            "fundingRound": amount_seeking,
            "projectedIRR": percentage,
            "riskScore": 1-100,
            "recommendation": "STRONG_BUY|BUY|HOLD|PASS",
            "rationale": "detailed explanation",
            "keyMetrics": {
              "revenue": value,
              "growth_rate": percentage,
              "market_size": value,
              "ebitda_margin": percentage
            }
          }
        ]
      `;

      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [{ role: "user", content: prompt }],
        response_format: { type: "json_object" },
      });

      const data = JSON.parse(response.choices[0].message.content);
      return data.opportunities || data;
    } catch (error) {
      throw new Error("Failed to identify investment opportunities: " + error.message);
    }
  }

  static async developExitStrategy(investment: any, marketConditions: any): Promise<ExitStrategy> {
    try {
      const prompt = `
        Develop optimal exit strategy for this investment:
        
        Investment Details:
        - Company: ${investment.company?.name}
        - Sector: ${investment.company?.sector}
        - Investment Amount: $${investment.investmentAmount}
        - Current Valuation: $${investment.currentValuation}
        - Ownership: ${investment.ownershipPercentage}%
        - Hold Period: ${this.calculateHoldPeriod(investment)} months
        
        Market Conditions: ${JSON.stringify(marketConditions)}
        
        Provide exit strategy in JSON format:
        {
          "exitType": "IPO|STRATEGIC_SALE|SECONDARY_SALE|MANAGEMENT_BUYOUT",
          "estimatedValuation": value,
          "projectedMultiple": multiple,
          "timeToExit": months,
          "exitProbability": percentage,
          "keyFactors": ["factor1", "factor2"],
          "recommendedActions": ["action1", "action2"],
          "riskFactors": ["risk1", "risk2"],
          "marketTiming": "analysis of market conditions"
        }
      `;

      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [{ role: "user", content: prompt }],
        response_format: { type: "json_object" },
      });

      const strategy = JSON.parse(response.choices[0].message.content);
      
      return {
        investmentId: investment.id,
        exitType: strategy.exitType,
        estimatedValuation: strategy.estimatedValuation,
        projectedMultiple: strategy.projectedMultiple,
        timeToExit: strategy.timeToExit,
        exitProbability: strategy.exitProbability,
        keyFactors: strategy.keyFactors,
        recommendedActions: strategy.recommendedActions
      };
    } catch (error) {
      throw new Error("Failed to develop exit strategy: " + error.message);
    }
  }

  static async performCompetitiveAnalysis(company: any): Promise<CompetitiveAnalysis> {
    try {
      const prompt = `
        Perform comprehensive competitive analysis for this company:
        
        Company: ${company.name}
        Sector: ${company.sector}
        Revenue: $${company.revenue}
        Region: ${company.region}
        
        Provide competitive analysis in JSON format:
        {
          "sector": "${company.sector}",
          "marketPosition": 1-10,
          "competitiveAdvantages": ["advantage1", "advantage2"],
          "threats": ["threat1", "threat2"],
          "marketShare": percentage,
          "moatStrength": 1-10,
          "competitorAnalysis": [
            {
              "name": "Competitor Name",
              "marketShare": percentage,
              "valuation": value,
              "strengths": ["strength1", "strength2"],
              "weaknesses": ["weakness1", "weakness2"]
            }
          ],
          "industryTrends": ["trend1", "trend2"],
          "barriers_to_entry": ["barrier1", "barrier2"]
        }
      `;

      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [{ role: "user", content: prompt }],
        response_format: { type: "json_object" },
      });

      const analysis = JSON.parse(response.choices[0].message.content);
      
      return {
        sector: analysis.sector,
        marketPosition: analysis.marketPosition,
        competitiveAdvantages: analysis.competitiveAdvantages,
        threats: analysis.threats,
        marketShare: analysis.marketShare,
        moatStrength: analysis.moatStrength,
        competitorAnalysis: analysis.competitorAnalysis
      };
    } catch (error) {
      throw new Error("Failed to perform competitive analysis: " + error.message);
    }
  }

  static async optimizePortfolioAllocation(currentPortfolio: any[], riskTolerance: number): Promise<any> {
    try {
      const prompt = `
        Optimize portfolio allocation for this private equity portfolio:
        
        Current Portfolio: ${JSON.stringify(currentPortfolio)}
        Risk Tolerance: ${riskTolerance} (1-10 scale)
        
        Provide optimization recommendations in JSON format:
        {
          "recommendedAllocation": {
            "growth_stage": percentage,
            "mature": percentage,
            "distressed": percentage,
            "venture": percentage
          },
          "sectorAllocation": {
            "technology": percentage,
            "healthcare": percentage,
            "financial_services": percentage,
            "consumer": percentage,
            "industrial": percentage
          },
          "geographicAllocation": {
            "north_america": percentage,
            "europe": percentage,
            "asia_pacific": percentage,
            "emerging_markets": percentage
          },
          "riskMitigationStrategies": ["strategy1", "strategy2"],
          "expectedReturn": percentage,
          "expectedVolatility": percentage,
          "rebalancingActions": ["action1", "action2"]
        }
      `;

      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [{ role: "user", content: prompt }],
        response_format: { type: "json_object" },
      });

      return JSON.parse(response.choices[0].message.content);
    } catch (error) {
      throw new Error("Failed to optimize portfolio allocation: " + error.message);
    }
  }

  // Helper functions
  private static getInvestedInExited(investments: any[]): number {
    return investments
      .filter(inv => inv.status === 'exited')
      .reduce((sum, inv) => sum + inv.investmentAmount, 0);
  }

  private static calculateHoldPeriod(investment: any): number {
    const startDate = new Date(investment.investmentDate);
    const endDate = investment.exitDate ? new Date(investment.exitDate) : new Date();
    return Math.floor((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24 * 30));
  }

  private static calculateIRR(cashFlows: Array<{ date: Date; amount: number }>): number {
    // Simplified IRR calculation using Newton-Raphson method
    // In production, use a financial library for accurate IRR calculation
    let rate = 0.1; // Initial guess
    const tolerance = 0.0001;
    const maxIterations = 100;
    
    for (let i = 0; i < maxIterations; i++) {
      const npv = this.calculateNPV(cashFlows, rate);
      const npvDerivative = this.calculateNPVDerivative(cashFlows, rate);
      
      if (Math.abs(npv) < tolerance) break;
      
      rate = rate - npv / npvDerivative;
    }
    
    return rate;
  }

  private static calculateNPV(cashFlows: Array<{ date: Date; amount: number }>, rate: number): number {
    const startDate = cashFlows[0].date;
    return cashFlows.reduce((npv, cf) => {
      const years = (cf.date.getTime() - startDate.getTime()) / (365.25 * 24 * 60 * 60 * 1000);
      return npv + cf.amount / Math.pow(1 + rate, years);
    }, 0);
  }

  private static calculateNPVDerivative(cashFlows: Array<{ date: Date; amount: number }>, rate: number): number {
    const startDate = cashFlows[0].date;
    return cashFlows.reduce((derivative, cf) => {
      const years = (cf.date.getTime() - startDate.getTime()) / (365.25 * 24 * 60 * 60 * 1000);
      return derivative - (years * cf.amount) / Math.pow(1 + rate, years + 1);
    }, 0);
  }
}