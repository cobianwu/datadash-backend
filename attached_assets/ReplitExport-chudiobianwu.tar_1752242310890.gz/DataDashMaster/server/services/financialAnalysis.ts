import OpenAI from "openai";

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export interface FinancialMetrics {
  revenue: number;
  ebitda: number;
  netIncome: number;
  totalAssets: number;
  totalDebt: number;
  equity: number;
  cashFlow: number;
  marketCap?: number;
}

export interface ValuationResult {
  dcfValue: number;
  multiples: {
    evRevenue: number;
    evEbitda: number;
    peRatio: number;
    priceToBook: number;
  };
  recommendation: 'BUY' | 'HOLD' | 'SELL';
  confidenceScore: number;
  keyRisks: string[];
  upside: number;
  downside: number;
}

export interface DueDiligenceReport {
  financialHealth: {
    score: number;
    strengths: string[];
    weaknesses: string[];
    redFlags: string[];
  };
  marketPosition: {
    competitiveAdvantage: string[];
    marketShare: number;
    growthProspects: string[];
  };
  operationalMetrics: {
    efficiency: number;
    scalability: string[];
    keyPerformanceIndicators: Record<string, number>;
  };
  riskAssessment: {
    financialRisk: number;
    operationalRisk: number;
    marketRisk: number;
    regulatoryRisk: number;
  };
}

export interface PortfolioAnalysis {
  portfolioValue: number;
  totalReturn: number;
  sharpeRatio: number;
  volatility: number;
  beta: number;
  diversificationScore: number;
  sectorAllocation: Record<string, number>;
  recommendations: string[];
}

export class FinancialAnalysisEngine {
  
  static async performDCFAnalysis(metrics: FinancialMetrics, growthRate: number, discountRate: number): Promise<number> {
    // Discounted Cash Flow calculation
    const projectedCashFlows = [];
    let currentCashFlow = metrics.cashFlow;
    
    // Project 10 years of cash flows
    for (let year = 1; year <= 10; year++) {
      currentCashFlow *= (1 + growthRate);
      const discountedCashFlow = currentCashFlow / Math.pow(1 + discountRate, year);
      projectedCashFlows.push(discountedCashFlow);
    }
    
    // Terminal value (assuming 2% perpetual growth)
    const terminalValue = (currentCashFlow * 1.02) / (discountRate - 0.02);
    const discountedTerminalValue = terminalValue / Math.pow(1 + discountRate, 10);
    
    return projectedCashFlows.reduce((sum, cf) => sum + cf, 0) + discountedTerminalValue;
  }

  static async calculateValuationMultiples(metrics: FinancialMetrics, marketData: any): Promise<ValuationResult['multiples']> {
    const enterpriseValue = (metrics.marketCap || 0) + metrics.totalDebt - (metrics.cashFlow * 0.1); // Approximate cash
    
    return {
      evRevenue: enterpriseValue / metrics.revenue,
      evEbitda: enterpriseValue / metrics.ebitda,
      peRatio: (metrics.marketCap || 0) / metrics.netIncome,
      priceToBook: (metrics.marketCap || 0) / metrics.equity
    };
  }

  static async generateInvestmentRecommendation(
    companyData: any, 
    financialMetrics: FinancialMetrics,
    marketContext: string
  ): Promise<ValuationResult> {
    try {
      const dcfValue = await this.performDCFAnalysis(financialMetrics, 0.05, 0.10);
      const multiples = await this.calculateValuationMultiples(financialMetrics, {});

      const prompt = `
        As a senior private equity analyst, provide investment recommendation for this company:
        
        Financial Metrics:
        - Revenue: $${financialMetrics.revenue.toLocaleString()}
        - EBITDA: $${financialMetrics.ebitda.toLocaleString()}
        - Net Income: $${financialMetrics.netIncome.toLocaleString()}
        - Total Assets: $${financialMetrics.totalAssets.toLocaleString()}
        - Total Debt: $${financialMetrics.totalDebt.toLocaleString()}
        - Cash Flow: $${financialMetrics.cashFlow.toLocaleString()}
        
        Valuation:
        - DCF Value: $${dcfValue.toLocaleString()}
        - EV/Revenue: ${multiples.evRevenue.toFixed(2)}x
        - EV/EBITDA: ${multiples.evEbitda.toFixed(2)}x
        - P/E Ratio: ${multiples.peRatio.toFixed(2)}x
        
        Market Context: ${marketContext}
        
        Provide analysis in JSON format:
        {
          "recommendation": "BUY|HOLD|SELL",
          "confidenceScore": 0-100,
          "keyRisks": ["risk1", "risk2"],
          "upside": percentage,
          "downside": percentage,
          "rationale": "detailed explanation"
        }
      `;

      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [{ role: "user", content: prompt }],
        response_format: { type: "json_object" },
      });

      const analysis = JSON.parse(response.choices[0].message.content);

      return {
        dcfValue,
        multiples,
        recommendation: analysis.recommendation,
        confidenceScore: analysis.confidenceScore,
        keyRisks: analysis.keyRisks,
        upside: analysis.upside,
        downside: analysis.downside
      };
    } catch (error) {
      throw new Error("Failed to generate investment recommendation: " + error.message);
    }
  }

  static async performDueDiligence(companyData: any, financialData: any[]): Promise<DueDiligenceReport> {
    try {
      const prompt = `
        Perform comprehensive due diligence analysis on this company data:
        ${JSON.stringify(companyData)}
        
        Financial History: ${JSON.stringify(financialData.slice(-5))} // Last 5 years
        
        Provide detailed due diligence report in JSON format:
        {
          "financialHealth": {
            "score": 0-100,
            "strengths": ["strength1", "strength2"],
            "weaknesses": ["weakness1", "weakness2"],
            "redFlags": ["flag1", "flag2"]
          },
          "marketPosition": {
            "competitiveAdvantage": ["advantage1", "advantage2"],
            "marketShare": percentage,
            "growthProspects": ["prospect1", "prospect2"]
          },
          "operationalMetrics": {
            "efficiency": 0-100,
            "scalability": ["factor1", "factor2"],
            "keyPerformanceIndicators": {"metric1": value, "metric2": value}
          },
          "riskAssessment": {
            "financialRisk": 0-100,
            "operationalRisk": 0-100,
            "marketRisk": 0-100,
            "regulatoryRisk": 0-100
          }
        }
      `;

      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [{ role: "user", content: prompt }],
        response_format: { type: "json_object" },
      });

      return JSON.parse(response.choices[0].message.content);
    } catch (error) {
      throw new Error("Failed to perform due diligence: " + error.message);
    }
  }

  static async analyzePortfolio(portfolioData: any[]): Promise<PortfolioAnalysis> {
    try {
      const prompt = `
        Analyze this investment portfolio for a private equity firm:
        ${JSON.stringify(portfolioData)}
        
        Provide comprehensive portfolio analysis in JSON format:
        {
          "portfolioValue": total_value,
          "totalReturn": percentage,
          "sharpeRatio": ratio,
          "volatility": percentage,
          "beta": value,
          "diversificationScore": 0-100,
          "sectorAllocation": {"sector1": percentage, "sector2": percentage},
          "recommendations": ["recommendation1", "recommendation2"]
        }
      `;

      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [{ role: "user", content: prompt }],
        response_format: { type: "json_object" },
      });

      return JSON.parse(response.choices[0].message.content);
    } catch (error) {
      throw new Error("Failed to analyze portfolio: " + error.message);
    }
  }

  static async generateMarketIntelligence(sector: string, region: string): Promise<any> {
    try {
      const prompt = `
        Generate market intelligence report for ${sector} sector in ${region}:
        
        Provide analysis in JSON format:
        {
          "marketSize": value,
          "growthRate": percentage,
          "keyTrends": ["trend1", "trend2"],
          "competitiveLandscape": ["player1", "player2"],
          "investmentOpportunities": ["opportunity1", "opportunity2"],
          "riskFactors": ["risk1", "risk2"],
          "valuationMultiples": {"ev_revenue": range, "ev_ebitda": range}
        }
      `;

      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [{ role: "user", content: prompt }],
        response_format: { type: "json_object" },
      });

      return JSON.parse(response.choices[0].message.content);
    } catch (error) {
      throw new Error("Failed to generate market intelligence: " + error.message);
    }
  }
}