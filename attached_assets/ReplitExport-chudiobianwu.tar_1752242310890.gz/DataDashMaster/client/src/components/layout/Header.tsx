import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import type { Warehouse } from "@/types";

interface HeaderProps {
  selectedWarehouse: number | null;
  warehouses: Warehouse[];
  onWarehouseChange: (warehouseId: number) => void;
  onToggleAI: () => void;
  onManageWarehouse: () => void;
}

export default function Header({
  selectedWarehouse,
  warehouses,
  onWarehouseChange,
  onToggleAI,
  onManageWarehouse
}: HeaderProps) {
  const currentWarehouse = warehouses.find(w => w.id === selectedWarehouse);

  return (
    <header className="bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between">
      <div className="flex items-center space-x-4">
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
            <i className="fas fa-snowflake text-white text-sm"></i>
          </div>
          <h1 className="text-xl font-semibold text-gray-900">DataFlow Analytics</h1>
        </div>
        
        {/* Warehouse Selector */}
        <div className="flex items-center space-x-2 bg-gray-50 px-3 py-2 rounded-lg">
          <i className="fas fa-server text-gray-500 text-sm"></i>
          <Select 
            value={selectedWarehouse?.toString()} 
            onValueChange={(value) => onWarehouseChange(parseInt(value))}
          >
            <SelectTrigger className="border-none bg-transparent shadow-none p-0 h-auto font-medium">
              <SelectValue placeholder="Select warehouse" />
            </SelectTrigger>
            <SelectContent>
              {warehouses.map((warehouse) => (
                <SelectItem key={warehouse.id} value={warehouse.id.toString()}>
                  {warehouse.name} ({warehouse.size})
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          {currentWarehouse && (
            <span 
              className={`text-xs px-2 py-1 rounded ${
                currentWarehouse.status === 'running' 
                  ? 'text-green-700 bg-green-100' 
                  : 'text-gray-700 bg-gray-100'
              }`}
            >
              {currentWarehouse.status}
            </span>
          )}
          <Button
            variant="ghost"
            size="sm"
            onClick={onManageWarehouse}
            className="h-auto p-1 text-xs"
          >
            Manage
          </Button>
        </div>
      </div>

      <div className="flex items-center space-x-4">
        {/* AI Assistant Toggle */}
        <Button
          onClick={onToggleAI}
          className="bg-secondary text-white hover:bg-primary"
        >
          <i className="fas fa-robot text-sm mr-2"></i>
          Ask Sigma
        </Button>
        
        {/* User Profile */}
        <div className="flex items-center space-x-2">
          <Avatar className="h-8 w-8">
            <AvatarFallback>JA</AvatarFallback>
          </Avatar>
          <span className="text-sm font-medium">John Analyst</span>
        </div>
      </div>
    </header>
  );
}
