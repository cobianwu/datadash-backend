import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useWarehouses, useWarehouseActions } from "@/hooks/use-warehouse";
import { useToast } from "@/hooks/use-toast";
import type { Warehouse } from "@/types";

interface WarehouseManagerProps {
  isOpen: boolean;
  onClose: () => void;
}

interface WarehouseSize {
  size: string;
  nodes: number;
  creditsPerHour: string;
  description: string;
  recommended: string;
}

const warehouseSizes: WarehouseSize[] = [
  { size: "X-Small", nodes: 1, creditsPerHour: "1.000", description: "Development & testing", recommended: "Small datasets, simple queries" },
  { size: "Small", nodes: 2, creditsPerHour: "2.000", description: "Light workloads", recommended: "Basic analytics workloads" },
  { size: "Medium", nodes: 4, creditsPerHour: "4.000", description: "Standard production", recommended: "Standard reporting" },
  { size: "Large", nodes: 8, creditsPerHour: "8.000", description: "Heavy analytics", recommended: "Complex queries" },
  { size: "X-Large", nodes: 16, creditsPerHour: "16.000", description: "Data-intensive operations", recommended: "Heavy ETL processes" },
  { size: "2X-Large", nodes: 32, creditsPerHour: "32.000", description: "Very large datasets", recommended: "Massive data processing" },
  { size: "3X-Large", nodes: 64, creditsPerHour: "64.000", description: "Enterprise scale", recommended: "Enterprise workloads" },
  { size: "4X-Large", nodes: 128, creditsPerHour: "128.000", description: "Maximum performance", recommended: "Maximum single-cluster power" }
];

export default function WarehouseManager({ isOpen, onClose }: WarehouseManagerProps) {
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [newWarehouse, setNewWarehouse] = useState({
    name: '',
    size: 'X-Small',
    autoSuspend: true
  });

  const { data: warehouses, isLoading } = useWarehouses();
  const { createWarehouse, updateWarehouse } = useWarehouseActions();
  const { toast } = useToast();

  const handleCreateWarehouse = async () => {
    if (!newWarehouse.name.trim()) {
      toast({
        title: "Warehouse name required",
        description: "Please enter a name for the warehouse.",
        variant: "destructive",
      });
      return;
    }

    const selectedSize = warehouseSizes.find(s => s.size === newWarehouse.size);
    if (!selectedSize) return;

    try {
      await createWarehouse.mutateAsync({
        name: newWarehouse.name.trim(),
        size: selectedSize.size,
        creditsPerHour: selectedSize.creditsPerHour,
        nodes: selectedSize.nodes,
        autoSuspend: newWarehouse.autoSuspend,
        status: "suspended",
        userId: 1 // Current user ID
      });

      toast({
        title: "Warehouse created",
        description: `${newWarehouse.name} warehouse has been created successfully.`,
      });

      setNewWarehouse({ name: '', size: 'X-Small', autoSuspend: true });
      setShowCreateForm(false);
    } catch (error) {
      toast({
        title: "Creation failed",
        description: "Failed to create warehouse. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleWarehouseAction = async (warehouse: Warehouse, action: 'start' | 'stop' | 'suspend') => {
    const statusMap = {
      start: 'running',
      stop: 'suspended',
      suspend: 'suspended'
    };

    try {
      await updateWarehouse.mutateAsync({
        id: warehouse.id,
        updates: { status: statusMap[action] }
      });

      toast({
        title: `Warehouse ${action}ed`,
        description: `${warehouse.name} has been ${action}ed successfully.`,
      });
    } catch (error) {
      toast({
        title: "Action failed",
        description: `Failed to ${action} warehouse. Please try again.`,
        variant: "destructive",
      });
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'running': return 'bg-green-100 text-green-800';
      case 'starting': return 'bg-yellow-100 text-yellow-800';
      case 'stopping': return 'bg-orange-100 text-orange-800';
      case 'suspended': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const calculateMonthlyCost = (creditsPerHour: string, assumedHours: number = 8) => {
    const credits = parseFloat(creditsPerHour);
    const dailyCost = credits * assumedHours;
    const monthlyCost = dailyCost * 30;
    return monthlyCost.toFixed(2);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-auto">
        <DialogHeader>
          <DialogTitle>Warehouse Management</DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Create New Warehouse */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">Create New Warehouse</CardTitle>
                <Button
                  onClick={() => setShowCreateForm(!showCreateForm)}
                  variant={showCreateForm ? "outline" : "default"}
                >
                  {showCreateForm ? 'Cancel' : 'New Warehouse'}
                </Button>
              </div>
            </CardHeader>
            {showCreateForm && (
              <CardContent className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Warehouse Name
                  </label>
                  <Input
                    value={newWarehouse.name}
                    onChange={(e) => setNewWarehouse(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="Enter warehouse name (e.g., ANALYTICS_WH)"
                    className="font-mono"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Warehouse Size
                  </label>
                  <Select
                    value={newWarehouse.size}
                    onValueChange={(value) => setNewWarehouse(prev => ({ ...prev, size: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {warehouseSizes.map((size) => (
                        <SelectItem key={size.size} value={size.size}>
                          <div className="flex justify-between items-center w-full">
                            <span>{size.size} ({size.nodes} nodes)</span>
                            <span className="text-xs text-gray-500 ml-4">
                              {size.creditsPerHour} credits/hr
                            </span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-gray-500 mt-1">
                    {warehouseSizes.find(s => s.size === newWarehouse.size)?.description}
                  </p>
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <label className="text-sm font-medium text-gray-700">Auto-Suspend</label>
                    <p className="text-xs text-gray-500">Automatically suspend when idle</p>
                  </div>
                  <Switch
                    checked={newWarehouse.autoSuspend}
                    onCheckedChange={(checked) => setNewWarehouse(prev => ({ ...prev, autoSuspend: checked }))}
                  />
                </div>

                <div className="bg-blue-50 p-3 rounded-lg">
                  <h4 className="font-medium text-blue-900 mb-1">Estimated Cost</h4>
                  <div className="text-sm text-blue-800">
                    <div>Per hour: {warehouseSizes.find(s => s.size === newWarehouse.size)?.creditsPerHour} credits</div>
                    <div>Monthly (8hrs/day): ~{calculateMonthlyCost(
                      warehouseSizes.find(s => s.size === newWarehouse.size)?.creditsPerHour || "1"
                    )} credits</div>
                  </div>
                </div>

                <Button
                  onClick={handleCreateWarehouse}
                  disabled={createWarehouse.isPending || !newWarehouse.name.trim()}
                  className="w-full"
                >
                  {createWarehouse.isPending ? 'Creating...' : 'Create Warehouse'}
                </Button>
              </CardContent>
            )}
          </Card>

          {/* Existing Warehouses */}
          <Card>
            <CardHeader>
              <CardTitle>Active Warehouses</CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="text-center py-8">
                  <i className="fas fa-spinner fa-spin text-2xl text-gray-400 mb-2"></i>
                  <p className="text-gray-500">Loading warehouses...</p>
                </div>
              ) : warehouses && warehouses.length > 0 ? (
                <div className="space-y-4">
                  {warehouses.map((warehouse) => (
                    <div key={warehouse.id} className="border border-gray-200 rounded-lg p-4">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center space-x-3">
                          <h3 className="font-medium text-gray-900">{warehouse.name}</h3>
                          <Badge className={getStatusColor(warehouse.status)}>
                            {warehouse.status}
                          </Badge>
                        </div>
                        <div className="flex items-center space-x-2">
                          {warehouse.status === 'suspended' && (
                            <Button
                              size="sm"
                              onClick={() => handleWarehouseAction(warehouse, 'start')}
                              disabled={updateWarehouse.isPending}
                              className="bg-green-600 hover:bg-green-700 text-white"
                            >
                              <i className="fas fa-play mr-1"></i>
                              Start
                            </Button>
                          )}
                          {warehouse.status === 'running' && (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleWarehouseAction(warehouse, 'stop')}
                              disabled={updateWarehouse.isPending}
                            >
                              <i className="fas fa-stop mr-1"></i>
                              Stop
                            </Button>
                          )}
                        </div>
                      </div>

                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                        <div>
                          <span className="text-gray-500">Size</span>
                          <div className="font-medium">{warehouse.size}</div>
                        </div>
                        <div>
                          <span className="text-gray-500">Nodes</span>
                          <div className="font-medium">{warehouse.nodes}</div>
                        </div>
                        <div>
                          <span className="text-gray-500">Credits/Hour</span>
                          <div className="font-medium">{warehouse.creditsPerHour}</div>
                        </div>
                        <div>
                          <span className="text-gray-500">Auto-Suspend</span>
                          <div className="font-medium">
                            {warehouse.autoSuspend ? 'Enabled' : 'Disabled'}
                          </div>
                        </div>
                      </div>

                      {warehouse.status === 'running' && (
                        <div className="mt-3 p-3 bg-green-50 rounded border border-green-200">
                          <div className="flex items-center justify-between text-sm">
                            <span className="text-green-700">
                              <i className="fas fa-clock mr-1"></i>
                              Currently consuming {warehouse.creditsPerHour} credits/hour
                            </span>
                            <span className="text-green-600 font-medium">
                              ~${(parseFloat(warehouse.creditsPerHour) * 0.1).toFixed(2)}/hour
                            </span>
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <i className="fas fa-server text-3xl text-gray-300 mb-3"></i>
                  <p className="text-gray-500">No warehouses found</p>
                  <p className="text-sm text-gray-400">Create your first warehouse to get started</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Warehouse Sizing Guide */}
          <Card>
            <CardHeader>
              <CardTitle>Warehouse Sizing Guide</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {warehouseSizes.slice(0, 4).map((size) => (
                  <div key={size.size} className="border border-gray-200 rounded-lg p-3">
                    <div className="flex justify-between items-start mb-2">
                      <h4 className="font-medium">{size.size}</h4>
                      <span className="text-sm text-gray-500">{size.creditsPerHour}/hr</span>
                    </div>
                    <div className="text-sm text-gray-600">
                      <div>{size.nodes} nodes</div>
                      <div className="mt-1">{size.recommended}</div>
                    </div>
                  </div>
                ))}
              </div>
              
              <div className="mt-4 p-3 bg-blue-50 rounded-lg">
                <h4 className="font-medium text-blue-900 mb-2">Best Practices</h4>
                <ul className="text-sm text-blue-800 space-y-1">
                  <li>• Start with X-Small for development and testing</li>
                  <li>• Use Medium or Large for production analytics</li>
                  <li>• Enable auto-suspend to reduce costs during idle periods</li>
                  <li>• Scale up for complex queries with spillage to remote storage</li>
                  <li>• Separate ETL, reporting, and ad-hoc workloads into different warehouses</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </div>
      </DialogContent>
    </Dialog>
  );
}
