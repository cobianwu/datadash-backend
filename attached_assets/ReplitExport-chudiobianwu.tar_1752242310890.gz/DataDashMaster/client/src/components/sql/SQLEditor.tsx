import { useState, useRef, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useDataActions } from "@/hooks/use-data";
import { useWarehouses } from "@/hooks/use-warehouse";
import { useDataSources } from "@/hooks/use-data";
import { useToast } from "@/hooks/use-toast";
import type { QueryExecutionResult } from "@/types";

interface SQLEditorProps {
  isOpen: boolean;
  onClose: () => void;
  dataSourceId: number | null;
  warehouseId: number | null;
}

export default function SQLEditor({ 
  isOpen, 
  onClose, 
  dataSourceId, 
  warehouseId 
}: SQLEditorProps) {
  const [sqlQuery, setSqlQuery] = useState("-- Write your SQL query here\nSELECT *\nFROM your_table\nLIMIT 100;");
  const [queryResult, setQueryResult] = useState<QueryExecutionResult | null>(null);
  const [isExecuting, setIsExecuting] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  
  const { executeSQL } = useDataActions();
  const { data: warehouses } = useWarehouses();
  const { data: dataSources } = useDataSources();
  const { toast } = useToast();

  const currentWarehouse = warehouses?.find(w => w.id === warehouseId);
  const currentDataSource = dataSources?.find(ds => ds.id === dataSourceId);

  const sqlFunctions = [
    { category: "Aggregate Functions", functions: ["SUM()", "AVG()", "COUNT()", "MAX()", "MIN()"] },
    { category: "Window Functions", functions: ["ROW_NUMBER()", "RANK()", "LAG()", "LEAD()"] },
    { category: "Semi-structured", functions: ["PARSE_JSON()", "TYPEOF()", "OBJECT_CONSTRUCT()"] }
  ];

  const dataTypes = [
    "NUMBER(38,0) - Integer",
    "VARCHAR - String",
    "VARIANT - JSON/Semi-structured",
    "DATE - Date values",
    "TIMESTAMP - Date/time"
  ];

  const handleRunQuery = async () => {
    if (!warehouseId || !dataSourceId) {
      toast({
        title: "Missing requirements",
        description: "Please select both a warehouse and data source.",
        variant: "destructive",
      });
      return;
    }

    if (!sqlQuery.trim()) {
      toast({
        title: "Empty query",
        description: "Please enter a SQL query to execute.",
        variant: "destructive",
      });
      return;
    }

    setIsExecuting(true);
    
    try {
      const result = await executeSQL.mutateAsync({
        query: sqlQuery,
        warehouseId,
        dataSourceId
      });
      
      setQueryResult(result);
      
      if (result.success) {
        toast({
          title: "Query executed successfully",
          description: `Returned ${result.rowCount} rows in ${result.duration}ms`,
        });
      } else {
        toast({
          title: "Query failed",
          description: result.error || "Unknown error occurred",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Execution error",
        description: error instanceof Error ? error.message : "Failed to execute query",
        variant: "destructive",
      });
    } finally {
      setIsExecuting(false);
    }
  };

  const insertFunction = (func: string) => {
    if (textareaRef.current) {
      const textarea = textareaRef.current;
      const start = textarea.selectionStart;
      const end = textarea.selectionEnd;
      const text = sqlQuery;
      const newText = text.substring(0, start) + func + text.substring(end);
      setSqlQuery(newText);
      
      // Set cursor after inserted function
      setTimeout(() => {
        textarea.focus();
        textarea.setSelectionRange(start + func.length, start + func.length);
      }, 0);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl max-h-[90vh] p-0">
        {/* SQL Editor Header */}
        <DialogHeader className="p-4 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <DialogTitle>SQL Editor</DialogTitle>
              {currentWarehouse && (
                <div className="flex items-center space-x-2 text-sm text-gray-500">
                  <i className="fas fa-server"></i>
                  <span>{currentWarehouse.name}</span>
                </div>
              )}
            </div>
            <Button
              onClick={handleRunQuery}
              disabled={isExecuting || !warehouseId || !dataSourceId}
              className="bg-green-600 hover:bg-green-700 text-white"
            >
              <i className="fas fa-play mr-2"></i>
              {isExecuting ? 'Running...' : 'Run Query'}
            </Button>
          </div>
        </DialogHeader>

        {/* SQL Editor Content */}
        <div className="flex h-[70vh]">
          {/* Editor Pane */}
          <div className="flex-1 flex flex-col">
            <div className="flex-1 p-4">
              <Textarea
                ref={textareaRef}
                value={sqlQuery}
                onChange={(e) => setSqlQuery(e.target.value)}
                className="sql-editor h-full min-h-[300px]"
                placeholder="-- Write your SQL query here"
              />
            </div>
            
            {/* Query Status */}
            <div className="p-4 border-t border-gray-200 bg-gray-50">
              <div className="flex items-center justify-between text-sm">
                <div className="flex items-center space-x-4">
                  <span className="text-gray-600">
                    Status: <span className={`font-medium ${
                      queryResult?.success ? 'text-green-600' : 
                      queryResult?.success === false ? 'text-red-600' : 
                      'text-gray-600'
                    }`}>
                      {isExecuting ? 'Running' : queryResult ? 
                        (queryResult.success ? 'Success' : 'Error') : 'Ready'}
                    </span>
                  </span>
                  <span className="text-gray-600">
                    Rows: <span className="font-medium">{queryResult?.rowCount || 0}</span>
                  </span>
                  <span className="text-gray-600">
                    Duration: <span className="font-medium">{queryResult?.duration || 0}ms</span>
                  </span>
                </div>
                <div className="flex items-center space-x-2 text-gray-600">
                  <i className="fas fa-coins"></i>
                  <span>Credits: <span className="font-medium">
                    {queryResult?.creditsUsed?.toFixed(6) || '0.000000'}
                  </span></span>
                </div>
              </div>
            </div>

            {/* Query Results */}
            {queryResult && (
              <div className="border-t border-gray-200 max-h-64 overflow-auto">
                {queryResult.success && queryResult.data ? (
                  <div className="p-4">
                    <h3 className="font-medium mb-2">Query Results ({queryResult.rowCount} rows)</h3>
                    <div className="overflow-x-auto">
                      <table className="min-w-full text-sm border border-gray-200">
                        <thead className="bg-gray-50">
                          <tr>
                            {queryResult.columns?.map((col) => (
                              <th key={col} className="px-3 py-2 text-left border-b border-gray-200">
                                {col}
                              </th>
                            ))}
                          </tr>
                        </thead>
                        <tbody>
                          {queryResult.data.slice(0, 10).map((row, index) => (
                            <tr key={index} className="border-b border-gray-100">
                              {queryResult.columns?.map((col) => (
                                <td key={col} className="px-3 py-2">
                                  {typeof row[col] === 'object' ? 
                                    JSON.stringify(row[col]) : 
                                    String(row[col] ?? '')
                                  }
                                </td>
                              ))}
                            </tr>
                          ))}
                        </tbody>
                      </table>
                      {queryResult.data.length > 10 && (
                        <p className="text-xs text-gray-500 mt-2">
                          Showing first 10 rows of {queryResult.rowCount} total
                        </p>
                      )}
                    </div>
                  </div>
                ) : (
                  <div className="p-4 text-red-600">
                    <h3 className="font-medium mb-2">Query Error</h3>
                    <p className="text-sm">{queryResult.error}</p>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Function Reference Sidebar */}
          <div className="w-80 border-l border-gray-200 bg-gray-50 flex flex-col">
            <div className="p-4 border-b border-gray-200 bg-white">
              <h3 className="font-medium text-gray-900 mb-3">Functions & References</h3>
              <input
                type="text"
                placeholder="Search functions..."
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
              />
            </div>
            
            <div className="flex-1 p-4 overflow-auto space-y-4">
              {/* SQL Functions */}
              {sqlFunctions.map((category) => (
                <div key={category.category}>
                  <h4 className="text-sm font-medium text-gray-700 mb-2">{category.category}</h4>
                  <div className="space-y-1">
                    {category.functions.map((func) => (
                      <button
                        key={func}
                        onClick={() => insertFunction(func)}
                        className="block w-full text-left px-2 py-1 hover:bg-gray-100 rounded font-mono text-sm text-primary"
                      >
                        {func}
                      </button>
                    ))}
                  </div>
                </div>
              ))}

              {/* Data Types */}
              <div>
                <h4 className="text-sm font-medium text-gray-700 mb-2">Data Types</h4>
                <div className="space-y-1">
                  {dataTypes.map((type) => (
                    <div key={type} className="px-2 py-1 text-xs text-gray-600">
                      {type}
                    </div>
                  ))}
                </div>
              </div>

              {/* Current Data Source Info */}
              {currentDataSource && (
                <div>
                  <h4 className="text-sm font-medium text-gray-700 mb-2">Current Data Source</h4>
                  <div className="text-xs text-gray-600 space-y-1">
                    <div>Name: {currentDataSource.name}</div>
                    <div>Rows: {currentDataSource.rowCount.toLocaleString()}</div>
                    <div>Type: {currentDataSource.type.toUpperCase()}</div>
                    {currentDataSource.schema && (
                      <div className="mt-2">
                        <div className="font-medium">Columns:</div>
                        {Object.entries(currentDataSource.schema).map(([col, type]) => (
                          <div key={col} className="ml-2">
                            {col}: {type}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
