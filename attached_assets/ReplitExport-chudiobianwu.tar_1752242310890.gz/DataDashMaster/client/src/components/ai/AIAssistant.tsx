import { useState, useRef, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useDataActions } from "@/hooks/use-data";
import { useDataSources } from "@/hooks/use-data";
import { useToast } from "@/hooks/use-toast";
import type { AIResponse } from "@/types";

interface Message {
  id: string;
  type: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  chartConfig?: any;
  sqlQuery?: string;
}

interface AIAssistantProps {
  isOpen: boolean;
  onClose: () => void;
  dataSourceId: number | null;
}

export default function AIAssistant({ isOpen, onClose, dataSourceId }: AIAssistantProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputMessage, setInputMessage] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const { chatWithAI, generateSQL } = useDataActions();
  const { data: dataSources } = useDataSources();
  const { toast } = useToast();

  const currentDataSource = dataSources?.find(ds => ds.id === dataSourceId);

  const suggestionPrompts = [
    "Show me sales by region",
    "Create a dashboard for KPIs", 
    "Find top performing products",
    "Analyze customer segments",
    "Generate a trend analysis",
    "Compare performance metrics"
  ];

  useEffect(() => {
    if (isOpen && messages.length === 0) {
      // Add welcome message when opened
      const welcomeMessage: Message = {
        id: 'welcome',
        type: 'assistant',
        content: "Hi! I'm your AI assistant. I can help you create charts, write SQL queries, analyze your data, and build dashboards. What would you like to explore?",
        timestamp: new Date()
      };
      setMessages([welcomeMessage]);
    }
  }, [isOpen, messages.length]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    if (isOpen && inputRef.current) {
      inputRef.current.focus();
    }
  }, [isOpen]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleSendMessage = async () => {
    if (!inputMessage.trim() || isProcessing) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content: inputMessage.trim(),
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputMessage('');
    setIsProcessing(true);

    try {
      const context = currentDataSource ? {
        availableColumns: Object.keys(currentDataSource.schema || {}),
        dataTypes: currentDataSource.schema,
        currentData: {
          name: currentDataSource.name,
          rowCount: currentDataSource.rowCount,
          type: currentDataSource.type
        }
      } : {};

      const response = await chatWithAI.mutateAsync({
        message: userMessage.content,
        context
      });

      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        type: 'assistant',
        content: response.message,
        timestamp: new Date(),
        chartConfig: response.chartConfig,
        sqlQuery: response.sqlQuery
      };

      setMessages(prev => [...prev, assistantMessage]);

      // If AI provided suggestions, show them
      if (response.suggestions && response.suggestions.length > 0) {
        // Could add suggestion pills here
      }

    } catch (error) {
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        type: 'assistant',
        content: "I'm having trouble processing your request right now. Please try again or rephrase your question.",
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleSuggestionClick = (suggestion: string) => {
    setInputMessage(suggestion);
    inputRef.current?.focus();
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied to clipboard",
      description: "The content has been copied to your clipboard.",
    });
  };

  const renderMessage = (message: Message) => {
    const isUser = message.type === 'user';
    
    return (
      <div key={message.id} className={`flex ${isUser ? 'justify-end' : 'justify-start'} mb-4`}>
        <div className={`flex items-start space-x-2 max-w-[80%] ${isUser ? 'flex-row-reverse space-x-reverse' : ''}`}>
          <div className={`w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 ${
            isUser ? 'bg-primary' : 'bg-secondary'
          }`}>
            <i className={`${isUser ? 'fas fa-user' : 'fas fa-robot'} text-white text-xs`}></i>
          </div>
          
          <div className={`rounded-lg p-3 ${
            isUser 
              ? 'bg-primary text-white' 
              : 'bg-gray-50 text-gray-900 border border-gray-200'
          }`}>
            <p className="text-sm whitespace-pre-wrap">{message.content}</p>
            
            {/* Render SQL query if provided */}
            {message.sqlQuery && (
              <div className="mt-3 p-3 bg-gray-100 rounded border">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-medium text-gray-600">Generated SQL:</span>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => copyToClipboard(message.sqlQuery!)}
                    className="h-6 w-6 p-0"
                  >
                    <i className="fas fa-copy text-xs"></i>
                  </Button>
                </div>
                <pre className="text-xs font-mono text-gray-800 whitespace-pre-wrap bg-white p-2 rounded border">
                  {message.sqlQuery}
                </pre>
              </div>
            )}

            {/* Render chart config if provided */}
            {message.chartConfig && (
              <div className="mt-3 p-3 bg-blue-50 rounded border border-blue-200">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-medium text-blue-700">Chart Configuration:</span>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-6 text-blue-600 hover:text-blue-800"
                  >
                    <i className="fas fa-chart-bar text-xs mr-1"></i>
                    <span className="text-xs">Apply</span>
                  </Button>
                </div>
                <div className="text-xs text-blue-800">
                  <div>Type: {message.chartConfig.type}</div>
                  {message.chartConfig.title && <div>Title: {message.chartConfig.title}</div>}
                  {message.chartConfig.xAxis && <div>X-Axis: {message.chartConfig.xAxis}</div>}
                  {message.chartConfig.yAxis && <div>Y-Axis: {message.chartConfig.yAxis}</div>}
                </div>
              </div>
            )}
            
            <div className="text-xs opacity-70 mt-2">
              {message.timestamp.toLocaleTimeString()}
            </div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md h-[80vh] p-0 flex flex-col">
        {/* Header */}
        <DialogHeader className="bg-secondary text-white p-4 flex-shrink-0">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <i className="fas fa-robot text-lg"></i>
              <DialogTitle className="text-white">Ask Sigma</DialogTitle>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={onClose}
              className="text-white hover:text-gray-200 h-6 w-6 p-0"
            >
              <i className="fas fa-times"></i>
            </Button>
          </div>
          {currentDataSource && (
            <p className="text-xs text-blue-100 mt-1">
              Working with: {currentDataSource.name} ({currentDataSource.rowCount.toLocaleString()} rows)
            </p>
          )}
        </DialogHeader>

        {/* Messages */}
        <ScrollArea className="flex-1 p-4">
          <div className="space-y-1">
            {messages.map(renderMessage)}
            
            {/* Suggestion prompts (only show if no recent messages) */}
            {messages.length <= 1 && (
              <div className="space-y-2 mt-4">
                <p className="text-xs text-gray-500 mb-2">Try asking:</p>
                {suggestionPrompts.map((prompt, index) => (
                  <button
                    key={index}
                    onClick={() => handleSuggestionClick(prompt)}
                    className="w-full text-left p-3 bg-blue-50 border border-blue-200 rounded-lg hover:bg-blue-100 transition-colors text-sm"
                  >
                    "{prompt}"
                  </button>
                ))}
              </div>
            )}
            
            {/* Processing indicator */}
            {isProcessing && (
              <div className="flex justify-start mb-4">
                <div className="flex items-start space-x-2">
                  <div className="w-6 h-6 bg-secondary rounded-full flex items-center justify-center flex-shrink-0">
                    <i className="fas fa-robot text-white text-xs"></i>
                  </div>
                  <div className="bg-gray-50 rounded-lg p-3 border border-gray-200">
                    <div className="flex items-center space-x-2">
                      <div className="flex space-x-1">
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                      </div>
                      <span className="text-xs text-gray-500">AI is thinking...</span>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
          <div ref={messagesEndRef} />
        </ScrollArea>

        {/* Input */}
        <div className="p-4 border-t border-gray-200 flex-shrink-0">
          <div className="flex space-x-2">
            <Input
              ref={inputRef}
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Ask me anything about your data..."
              className="flex-1"
              disabled={isProcessing}
            />
            <Button
              onClick={handleSendMessage}
              disabled={!inputMessage.trim() || isProcessing}
              className="bg-secondary hover:bg-primary text-white"
            >
              <i className="fas fa-paper-plane text-sm"></i>
            </Button>
          </div>
          
          {!currentDataSource && (
            <p className="text-xs text-orange-600 mt-2">
              <i className="fas fa-exclamation-triangle mr-1"></i>
              Select a data source for more accurate AI assistance
            </p>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
