import { useState } from "react";
import { useDataSourceData } from "@/hooks/use-data";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";

interface DataGridProps {
  dataSourceId: number | null;
  selectedWarehouse: number | null;
}

export default function DataGrid({ dataSourceId, selectedWarehouse }: DataGridProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [currentPage, setCurrentPage] = useState(0);
  const pageSize = 100;

  const { data, isLoading, error } = useDataSourceData(
    dataSourceId, 
    pageSize, 
    currentPage * pageSize
  );

  if (!dataSourceId) {
    return (
      <div className="flex-1 bg-white flex items-center justify-center">
        <div className="text-center">
          <i className="fas fa-table text-4xl text-gray-300 mb-4"></i>
          <h3 className="text-lg font-medium text-gray-900 mb-2">No Data Source Selected</h3>
          <p className="text-gray-500">Import data or select a data source to begin analyzing</p>
        </div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="flex-1 bg-white">
        <div className="bg-gray-50 border-b border-gray-200 px-4 py-2">
          <Skeleton className="h-6 w-48" />
        </div>
        <div className="p-4 space-y-4">
          {Array.from({ length: 10 }).map((_, i) => (
            <Skeleton key={i} className="h-8 w-full" />
          ))}
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex-1 bg-white flex items-center justify-center">
        <div className="text-center">
          <i className="fas fa-exclamation-triangle text-4xl text-red-500 mb-4"></i>
          <h3 className="text-lg font-medium text-gray-900 mb-2">Error Loading Data</h3>
          <p className="text-gray-500">Failed to load data source</p>
        </div>
      </div>
    );
  }

  if (!data || data.data.length === 0) {
    return (
      <div className="flex-1 bg-white flex items-center justify-center">
        <div className="text-center">
          <i className="fas fa-table text-4xl text-gray-300 mb-4"></i>
          <h3 className="text-lg font-medium text-gray-900 mb-2">No Data Available</h3>
          <p className="text-gray-500">This data source appears to be empty</p>
        </div>
      </div>
    );
  }

  const filteredColumns = data.columns.filter(col =>
    col.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const visibleColumns = searchTerm ? filteredColumns : data.columns;

  return (
    <div className="flex-1 bg-white">
      {/* Grid Header */}
      <div className="bg-gray-50 border-b border-gray-200 px-4 py-2 flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <h2 className="font-medium text-gray-900">
            {dataSourceId ? `DATA_SOURCE_${dataSourceId}` : 'UNNAMED_TABLE'}
          </h2>
          <span className="text-sm text-gray-500">{data.totalRows.toLocaleString()} rows</span>
          <span className="text-sm text-gray-500">•</span>
          <span className="text-sm text-gray-500">{data.columns.length} columns</span>
        </div>
        
        <div className="flex items-center space-x-2">
          <Input
            type="text"
            placeholder="Search columns..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-48 h-8"
          />
          <Button variant="ghost" size="sm">
            <i className="fas fa-filter text-sm"></i>
          </Button>
        </div>
      </div>

      {/* Spreadsheet Grid */}
      <div className="overflow-auto h-full">
        <table className="data-grid">
          <thead>
            <tr>
              <th className="row-number">#</th>
              {visibleColumns.map((column) => (
                <th key={column} className="min-w-32">
                  <div className="flex items-center justify-between">
                    <span>{column}</span>
                    <div className="flex items-center space-x-1">
                      <span className="text-xs text-gray-400">
                        {data.schema[column] || 'VARCHAR'}
                      </span>
                      <Button variant="ghost" size="sm" className="h-4 w-4 p-0">
                        <i className="fas fa-sort text-xs text-gray-400"></i>
                      </Button>
                    </div>
                  </div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {data.data.map((row, index) => (
              <tr key={index}>
                <td className="row-number">
                  {currentPage * pageSize + index + 1}
                </td>
                {visibleColumns.map((column) => (
                  <td key={column} className={`${
                    data.schema[column] === 'NUMBER' ? 'text-right font-mono' : ''
                  }`}>
                    {formatCellValue(row[column], data.schema[column])}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      {data.totalRows > pageSize && (
        <div className="border-t border-gray-200 px-4 py-2 flex items-center justify-between">
          <div className="text-sm text-gray-500">
            Showing {currentPage * pageSize + 1} to {Math.min((currentPage + 1) * pageSize, data.totalRows)} of {data.totalRows} rows
          </div>
          <div className="flex items-center space-x-2">
            <Button
              variant="outline"
              size="sm"
              disabled={currentPage === 0}
              onClick={() => setCurrentPage(currentPage - 1)}
            >
              Previous
            </Button>
            <span className="text-sm text-gray-500">
              Page {currentPage + 1} of {Math.ceil(data.totalRows / pageSize)}
            </span>
            <Button
              variant="outline"
              size="sm"
              disabled={(currentPage + 1) * pageSize >= data.totalRows}
              onClick={() => setCurrentPage(currentPage + 1)}
            >
              Next
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}

function formatCellValue(value: any, dataType: string): string {
  if (value === null || value === undefined) {
    return '';
  }

  switch (dataType) {
    case 'NUMBER':
      if (typeof value === 'number') {
        return value % 1 === 0 ? value.toString() : value.toFixed(2);
      }
      return value.toString();
    
    case 'VARIANT':
      return typeof value === 'object' ? JSON.stringify(value) : value.toString();
    
    case 'DATE':
    case 'TIMESTAMP':
      if (value instanceof Date) {
        return dataType === 'DATE' 
          ? value.toISOString().split('T')[0]
          : value.toISOString();
      }
      return value.toString();
    
    default:
      return value.toString();
  }
}
