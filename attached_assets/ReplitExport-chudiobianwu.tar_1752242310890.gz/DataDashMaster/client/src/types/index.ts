export interface User {
  id: number;
  username: string;
}

export interface Warehouse {
  id: number;
  name: string;
  size: string;
  status: 'running' | 'suspended' | 'starting' | 'stopping';
  creditsPerHour: string;
  nodes: number;
  autoSuspend: boolean;
  userId: number;
  createdAt: Date;
}

export interface DataSource {
  id: number;
  name: string;
  type: 'csv' | 'excel' | 'json' | 'parquet' | 'database';
  fileName?: string;
  filePath?: string;
  schema?: Record<string, string>;
  rowCount: number;
  status: 'processing' | 'ready' | 'error';
  userId: number;
  createdAt: Date;
}

export interface DataResponse {
  data: any[];
  totalRows: number;
  columns: string[];
  schema: Record<string, string>;
}

export interface QueryHistory {
  id: number;
  sqlQuery: string;
  status: 'running' | 'completed' | 'error';
  duration?: number;
  rowsReturned?: number;
  creditsUsed?: string;
  warehouseId: number;
  userId: number;
  executedAt: Date;
}

export interface Chart {
  id: number;
  name: string;
  type: 'bar' | 'line' | 'pie' | 'scatter' | 'heatmap' | 'treemap';
  configuration: any;
  dataSourceId: number;
  userId: number;
  createdAt: Date;
}

export interface Dashboard {
  id: number;
  name: string;
  layout: any;
  userId: number;
  createdAt: Date;
}

export interface AIResponse {
  message: string;
  suggestions?: string[];
  chartConfig?: any;
  sqlQuery?: string;
  type: 'text' | 'chart' | 'sql' | 'dashboard';
}

export interface SQLValidationResult {
  isValid: boolean;
  errors: string[];
  estimatedCost: number;
  affectedRows?: number;
  queryType: string;
}

export interface QueryExecutionResult {
  success: boolean;
  data?: any[];
  columns?: string[];
  rowCount: number;
  duration: number;
  creditsUsed: number;
  error?: string;
}

export interface ChartConfig {
  type: 'bar' | 'line' | 'pie' | 'scatter' | 'heatmap' | 'treemap';
  title: string;
  xAxis: string;
  yAxis: string;
  groupBy?: string;
  colors: string[];
  aggregation?: 'SUM' | 'AVG' | 'COUNT' | 'MAX' | 'MIN';
}
