import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Play, Pause, SkipForward, RotateCcw, CheckCircle, 
  Upload, BarChart3, Target, DollarSign, TrendingUp,
  FileText, Download, Brain, AlertTriangle
} from "lucide-react";

export default function DemoWalkthrough() {
  const [currentStep, setCurrentStep] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [completedSteps, setCompletedSteps] = useState<number[]>([]);

  const demoSteps = [
    {
      title: "Welcome to DataFlow Analytics",
      description: "Advanced Private Equity Investment Platform",
      content: (
        <div className="space-y-4">
          <div className="text-center p-8 bg-gradient-to-br from-primary/10 to-secondary/10 rounded-lg">
            <h2 className="text-2xl font-bold text-primary mb-4">DataFlow Analytics</h2>
            <p className="text-lg text-muted-foreground mb-6">
              The most advanced private equity analytics platform that surpasses traditional tools like Snowflake Sigma
            </p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-primary">$284M</div>
                <div className="text-sm text-muted-foreground">DCF Valuations</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-success">25%</div>
                <div className="text-sm text-muted-foreground">Target IRR</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-primary">$5T</div>
                <div className="text-sm text-muted-foreground">Market Coverage</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-warning">85%</div>
                <div className="text-sm text-muted-foreground">AI Confidence</div>
              </div>
            </div>
          </div>
        </div>
      )
    },
    {
      title: "Document Upload & Processing",
      description: "Upload financial statements, 10-Ks, and audits for AI analysis",
      content: (
        <div className="space-y-4">
          <div className="border-2 border-dashed border-primary/25 rounded-lg p-6 text-center">
            <Upload className="h-12 w-12 mx-auto text-primary mb-4" />
            <h3 className="text-lg font-semibold mb-2">Upload Financial Documents</h3>
            <p className="text-muted-foreground mb-4">
              Support for PDF, Excel, CSV files up to 100MB
            </p>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div className="bg-primary/5 p-3 rounded">
                <FileText className="h-5 w-5 text-primary mb-2" />
                <div className="font-medium">Financial Statements</div>
                <div className="text-muted-foreground">Automated data extraction</div>
              </div>
              <div className="bg-primary/5 p-3 rounded">
                <BarChart3 className="h-5 w-5 text-primary mb-2" />
                <div className="font-medium">10-K Filings</div>
                <div className="text-muted-foreground">AI-powered insights</div>
              </div>
            </div>
          </div>
          <div className="bg-success/10 border border-success/20 rounded-lg p-4">
            <div className="flex items-center gap-2 mb-2">
              <CheckCircle className="h-5 w-5 text-success" />
              <span className="font-semibold">Key Capabilities</span>
            </div>
            <ul className="space-y-1 text-sm">
              <li>• Automatic schema detection and data extraction</li>
              <li>• Financial metric calculation and trend analysis</li>
              <li>• Risk flag identification and opportunity mapping</li>
              <li>• Management question generation for due diligence</li>
            </ul>
          </div>
        </div>
      )
    },
    {
      title: "AI-Powered Financial Analysis",
      description: "Generate DCF valuations and investment recommendations",
      content: (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Target className="h-5 w-5" />
                  DCF Valuation
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center p-4 bg-primary/5 rounded-lg mb-3">
                  <div className="text-2xl font-bold text-primary">$284.7M</div>
                  <div className="text-sm text-muted-foreground">Enterprise Value</div>
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm">Recommendation</span>
                    <Badge className="bg-success/20 text-success">BUY</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Confidence</span>
                    <span className="text-sm font-semibold">85%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Upside</span>
                    <span className="text-sm font-semibold text-success">+30%</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Brain className="h-5 w-5" />
                  AI Insights
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-start gap-2">
                    <CheckCircle className="h-4 w-4 text-success mt-0.5 flex-shrink-0" />
                    <span className="text-sm">Strong revenue growth trajectory</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <CheckCircle className="h-4 w-4 text-success mt-0.5 flex-shrink-0" />
                    <span className="text-sm">Expanding market opportunity</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 text-warning mt-0.5 flex-shrink-0" />
                    <span className="text-sm">Monitor customer concentration</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <TrendingUp className="h-4 w-4 text-primary mt-0.5 flex-shrink-0" />
                    <span className="text-sm">Operational efficiency gains</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="bg-primary/5 border border-primary/20 rounded-lg p-4">
            <h4 className="font-semibold mb-2">Advanced Analytics Features</h4>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <div className="font-medium">• Scenario Analysis</div>
                <div className="text-muted-foreground">Bull, base, and bear case modeling</div>
              </div>
              <div>
                <div className="font-medium">• Risk Assessment</div>
                <div className="text-muted-foreground">VaR calculation and stress testing</div>
              </div>
              <div>
                <div className="font-medium">• Market Intelligence</div>
                <div className="text-muted-foreground">Sector analysis and benchmarking</div>
              </div>
              <div>
                <div className="font-medium">• Predictive Modeling</div>
                <div className="text-muted-foreground">Future performance projections</div>
              </div>
            </div>
          </div>
        </div>
      )
    },
    {
      title: "Portfolio Management",
      description: "Track performance and identify investment opportunities",
      content: (
        <div className="space-y-4">
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center p-4 bg-primary/5 rounded-lg">
              <DollarSign className="h-8 w-8 mx-auto text-primary mb-2" />
              <div className="text-lg font-bold">25.2%</div>
              <div className="text-sm text-muted-foreground">Portfolio IRR</div>
            </div>
            <div className="text-center p-4 bg-success/10 rounded-lg">
              <TrendingUp className="h-8 w-8 mx-auto text-success mb-2" />
              <div className="text-lg font-bold">2.8x</div>
              <div className="text-sm text-muted-foreground">Average MOIC</div>
            </div>
            <div className="text-center p-4 bg-warning/10 rounded-lg">
              <Target className="h-8 w-8 mx-auto text-warning mb-2" />
              <div className="text-lg font-bold">12</div>
              <div className="text-sm text-muted-foreground">Active Investments</div>
            </div>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Investment Opportunity: MedTech Innovators</CardTitle>
              <CardDescription>AI-identified high-potential investment</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div>
                  <div className="text-sm text-muted-foreground">Valuation</div>
                  <div className="text-lg font-bold">$500M</div>
                </div>
                <div>
                  <div className="text-sm text-muted-foreground">Projected IRR</div>
                  <div className="text-lg font-bold text-success">25%</div>
                </div>
                <div>
                  <div className="text-sm text-muted-foreground">Risk Score</div>
                  <div className="text-lg font-bold text-warning">65/100</div>
                </div>
                <div>
                  <div className="text-sm text-muted-foreground">Recommendation</div>
                  <Badge className="bg-success/20 text-success">STRONG BUY</Badge>
                </div>
              </div>
              <p className="text-sm text-muted-foreground">
                Revolutionary medical device technology with proprietary solutions addressing critical healthcare needs. 
                Strong IP portfolio and partnerships with leading providers.
              </p>
            </CardContent>
          </Card>
        </div>
      )
    },
    {
      title: "Market Intelligence",
      description: "Sector analysis and competitive benchmarking",
      content: (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle>Technology Sector</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-sm">Market Size</span>
                    <span className="font-semibold">$1.7T</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Growth Rate</span>
                    <span className="font-semibold text-success">8.5%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Investment Score</span>
                    <Badge className="bg-primary/20 text-primary">9/10</Badge>
                  </div>
                  <div className="mt-3">
                    <div className="text-sm font-medium mb-1">Key Trends</div>
                    <div className="flex flex-wrap gap-1">
                      <Badge variant="outline" className="text-xs">AI Innovation</Badge>
                      <Badge variant="outline" className="text-xs">Cloud Growth</Badge>
                      <Badge variant="outline" className="text-xs">Cybersecurity</Badge>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle>Healthcare Sector</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-sm">Market Size</span>
                    <span className="font-semibold">$3.2T</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Growth Rate</span>
                    <span className="font-semibold text-success">5.5%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Investment Score</span>
                    <Badge className="bg-secondary/20 text-secondary">8/10</Badge>
                  </div>
                  <div className="mt-3">
                    <div className="text-sm font-medium mb-1">Key Drivers</div>
                    <div className="flex flex-wrap gap-1">
                      <Badge variant="outline" className="text-xs">Aging Population</Badge>
                      <Badge variant="outline" className="text-xs">MedTech Advances</Badge>
                      <Badge variant="outline" className="text-xs">Telemedicine</Badge>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="bg-secondary/5 border border-secondary/20 rounded-lg p-4">
            <h4 className="font-semibold mb-2">Competitive Intelligence</h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
              <div>
                <div className="font-medium">Valuation Benchmarks</div>
                <div className="text-muted-foreground">Real-time multiple analysis</div>
              </div>
              <div>
                <div className="font-medium">Transaction Activity</div>
                <div className="text-muted-foreground">M&A and private equity deals</div>
              </div>
              <div>
                <div className="font-medium">Market Positioning</div>
                <div className="text-muted-foreground">Competitive landscape mapping</div>
              </div>
            </div>
          </div>
        </div>
      )
    },
    {
      title: "Export & Reporting",
      description: "Download comprehensive reports in multiple formats",
      content: (
        <div className="space-y-4">
          <div className="text-center mb-6">
            <Download className="h-12 w-12 mx-auto text-primary mb-4" />
            <h3 className="text-lg font-semibold mb-2">Professional Report Generation</h3>
            <p className="text-muted-foreground">
              Export analysis results in Excel, PDF, PowerPoint, or CSV formats
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center p-4 border rounded-lg">
              <FileText className="h-8 w-8 mx-auto text-primary mb-2" />
              <div className="font-medium">Excel</div>
              <div className="text-xs text-muted-foreground">Detailed data tables</div>
            </div>
            <div className="text-center p-4 border rounded-lg">
              <FileText className="h-8 w-8 mx-auto text-destructive mb-2" />
              <div className="font-medium">PDF</div>
              <div className="text-xs text-muted-foreground">Formatted reports</div>
            </div>
            <div className="text-center p-4 border rounded-lg">
              <BarChart3 className="h-8 w-8 mx-auto text-warning mb-2" />
              <div className="font-medium">PowerPoint</div>
              <div className="text-xs text-muted-foreground">Presentation data</div>
            </div>
            <div className="text-center p-4 border rounded-lg">
              <BarChart3 className="h-8 w-8 mx-auto text-success mb-2" />
              <div className="font-medium">CSV</div>
              <div className="text-xs text-muted-foreground">Raw data export</div>
            </div>
          </div>

          <div className="bg-primary/5 border border-primary/20 rounded-lg p-4">
            <h4 className="font-semibold mb-2">Report Contents Include:</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
              <div className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-success" />
                <span>Executive summary with key findings</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-success" />
                <span>Detailed financial metrics and ratios</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-success" />
                <span>Investment recommendations and rationale</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-success" />
                <span>Risk assessment and mitigation strategies</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-success" />
                <span>Market intelligence and benchmarking</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-success" />
                <span>Due diligence questions for management</span>
              </div>
            </div>
          </div>
        </div>
      )
    }
  ];

  const nextStep = () => {
    if (currentStep < demoSteps.length - 1) {
      setCompletedSteps(prev => [...prev, currentStep]);
      setCurrentStep(prev => prev + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(prev => prev - 1);
    }
  };

  const resetDemo = () => {
    setCurrentStep(0);
    setCompletedSteps([]);
    setIsPlaying(false);
  };

  const togglePlay = () => {
    setIsPlaying(!isPlaying);
    if (!isPlaying) {
      // Auto-advance every 5 seconds when playing
      const interval = setInterval(() => {
        setCurrentStep(prev => {
          if (prev < demoSteps.length - 1) {
            setCompletedSteps(prevCompleted => [...prevCompleted, prev]);
            return prev + 1;
          } else {
            setIsPlaying(false);
            clearInterval(interval);
            return prev;
          }
        });
      }, 5000);
    }
  };

  return (
    <div className="space-y-6 p-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-primary">Platform Demo Walkthrough</h1>
          <p className="text-muted-foreground">
            Interactive demonstration of DataFlow Analytics capabilities
          </p>
        </div>
        <Badge variant="secondary" className="bg-primary/10 text-primary">
          Step {currentStep + 1} of {demoSteps.length}
        </Badge>
      </div>

      {/* Progress Indicator */}
      <div className="space-y-2">
        <div className="flex justify-between text-sm text-muted-foreground">
          <span>Demo Progress</span>
          <span>{Math.round(((currentStep + 1) / demoSteps.length) * 100)}%</span>
        </div>
        <Progress value={((currentStep + 1) / demoSteps.length) * 100} className="h-2" />
      </div>

      {/* Demo Controls */}
      <div className="flex items-center gap-2 p-4 bg-secondary/5 rounded-lg">
        <Button variant="outline" size="sm" onClick={resetDemo}>
          <RotateCcw className="h-4 w-4 mr-2" />
          Reset
        </Button>
        <Button variant="outline" size="sm" onClick={togglePlay}>
          {isPlaying ? <Pause className="h-4 w-4 mr-2" /> : <Play className="h-4 w-4 mr-2" />}
          {isPlaying ? "Pause" : "Auto Play"}
        </Button>
        <Button variant="outline" size="sm" onClick={prevStep} disabled={currentStep === 0}>
          Previous
        </Button>
        <Button variant="outline" size="sm" onClick={nextStep} disabled={currentStep === demoSteps.length - 1}>
          <SkipForward className="h-4 w-4 mr-2" />
          Next
        </Button>
      </div>

      {/* Step Navigator */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-2">
        {demoSteps.map((step, index) => (
          <Button
            key={index}
            variant={index === currentStep ? "default" : "outline"}
            size="sm"
            onClick={() => setCurrentStep(index)}
            className="text-xs h-12 flex flex-col items-center justify-center"
          >
            {completedSteps.includes(index) && (
              <CheckCircle className="h-3 w-3 text-success mb-1" />
            )}
            <span className="truncate">{step.title}</span>
          </Button>
        ))}
      </div>

      {/* Current Step Content */}
      <Card className="min-h-[500px]">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <span className="flex items-center justify-center w-8 h-8 rounded-full bg-primary text-primary-foreground text-sm font-bold">
              {currentStep + 1}
            </span>
            {demoSteps[currentStep].title}
          </CardTitle>
          <CardDescription>
            {demoSteps[currentStep].description}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {demoSteps[currentStep].content}
        </CardContent>
      </Card>

      {/* Navigation Footer */}
      <div className="flex justify-between items-center">
        <Button variant="outline" onClick={prevStep} disabled={currentStep === 0}>
          Previous Step
        </Button>
        <div className="text-sm text-muted-foreground">
          {currentStep + 1} of {demoSteps.length}
        </div>
        <Button onClick={nextStep} disabled={currentStep === demoSteps.length - 1}>
          {currentStep === demoSteps.length - 1 ? "Demo Complete" : "Next Step"}
        </Button>
      </div>
    </div>
  );
}