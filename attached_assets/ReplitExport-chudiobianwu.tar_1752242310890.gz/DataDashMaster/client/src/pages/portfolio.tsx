import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  TrendingUp, TrendingDown, DollarSign, PieChart, Target, 
  AlertTriangle, CheckCircle, BarChart3, Users, Building2 
} from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface PortfolioMetrics {
  totalValue: number;
  totalInvested: number;
  unrealizedGains: number;
  realizedGains: number;
  irr: number;
  moic: number;
  dpi: number;
  rvpi: number;
  tvpi: number;
}

interface InvestmentOpportunity {
  companyName: string;
  sector: string;
  stage: string;
  valuation: number;
  projectedIRR: number;
  riskScore: number;
  recommendation: string;
  rationale: string;
}

interface SectorAnalysis {
  sector: string;
  investmentAttractiveness: number;
  growthRate: number;
  marketSize: number;
  keyDrivers: string[];
  risks: string[];
  trends: string[];
}

export default function PortfolioPage() {
  const [selectedSector, setSelectedSector] = useState("");
  const [selectedStage, setSelectedStage] = useState("");
  const [targetReturn, setTargetReturn] = useState(15);
  const [analysisType, setAnalysisType] = useState("overview");

  const queryClient = useQueryClient();

  // Mock portfolio data - in real app this would come from API
  const mockInvestments = [
    {
      id: 1,
      company: { name: "TechCorp Inc", sector: "Technology" },
      investmentAmount: 5000000,
      currentValuation: 8500000,
      ownershipPercentage: 15,
      investmentDate: "2022-01-15",
      status: "active"
    },
    {
      id: 2,
      company: { name: "HealthTech Solutions", sector: "Healthcare" },
      investmentAmount: 3000000,
      currentValuation: 4200000,
      ownershipPercentage: 12,
      investmentDate: "2021-06-10",
      status: "active"
    }
  ];

  const portfolioMetrics = useQuery({
    queryKey: ['/api/portfolio/analysis'],
    queryFn: () => apiRequest('/api/portfolio/analysis', {
      method: 'POST',
      body: { investments: mockInvestments }
    }),
    enabled: true
  });

  const identifyOpportunities = useMutation({
    mutationFn: ({ sector, stage, targetReturn }: any) =>
      apiRequest('/api/portfolio/opportunities', {
        method: 'POST',
        body: { sector, stage, targetReturn }
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/portfolio/opportunities'] });
    }
  });

  const sectorAnalysis = useMutation({
    mutationFn: ({ sector, region }: any) =>
      apiRequest('/api/market-intelligence/sector-analysis', {
        method: 'POST',
        body: { sector, region }
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/market-intelligence/sector-analysis'] });
    }
  });

  const handleAnalyzeOpportunities = () => {
    identifyOpportunities.mutate({
      sector: selectedSector,
      stage: selectedStage,
      targetReturn
    });
  };

  const handleSectorAnalysis = () => {
    sectorAnalysis.mutate({
      sector: selectedSector,
      region: "North America"
    });
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const formatPercentage = (value: number) => {
    return `${(value * 100).toFixed(1)}%`;
  };

  const metrics = portfolioMetrics.data as PortfolioMetrics;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-primary">Portfolio Management</h1>
          <p className="text-muted-foreground">
            Advanced private equity analytics and investment intelligence
          </p>
        </div>
        <Badge variant="secondary" className="bg-secondary/20">
          Citation Capital Analytics
        </Badge>
      </div>

      <Tabs value={analysisType} onValueChange={setAnalysisType} className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Portfolio Overview</TabsTrigger>
          <TabsTrigger value="opportunities">Investment Opportunities</TabsTrigger>
          <TabsTrigger value="sector">Sector Analysis</TabsTrigger>
          <TabsTrigger value="risk">Risk Management</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          {/* Portfolio Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Portfolio Value</CardTitle>
                <DollarSign className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-primary">
                  {metrics ? formatCurrency(metrics.totalValue) : formatCurrency(12700000)}
                </div>
                <p className="text-xs text-muted-foreground">
                  <span className="text-success">+18.2%</span> from last quarter
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">IRR (Internal Rate of Return)</CardTitle>
                <TrendingUp className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-primary">
                  {metrics ? formatPercentage(metrics.irr) : "24.7%"}
                </div>
                <p className="text-xs text-muted-foreground">
                  Target: 20% | Industry Avg: 18%
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">MOIC (Multiple on Invested Capital)</CardTitle>
                <BarChart3 className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-primary">
                  {metrics ? `${metrics.moic.toFixed(1)}x` : "2.8x"}
                </div>
                <p className="text-xs text-muted-foreground">
                  Top quartile performance
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Risk Score</CardTitle>
                <AlertTriangle className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-warning">
                  Medium
                </div>
                <Progress value={65} className="mt-2" />
                <p className="text-xs text-muted-foreground mt-1">
                  Diversification: Good
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Investment Portfolio */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <PieChart className="h-5 w-5" />
                Active Investments
              </CardTitle>
              <CardDescription>
                Current portfolio companies and performance metrics
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {mockInvestments.map((investment) => (
                  <div key={investment.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center">
                        <Building2 className="h-6 w-6 text-primary" />
                      </div>
                      <div>
                        <h3 className="font-semibold">{investment.company.name}</h3>
                        <p className="text-sm text-muted-foreground">{investment.company.sector}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-semibold">{formatCurrency(investment.currentValuation)}</div>
                      <div className="text-sm text-success">
                        +{((investment.currentValuation / investment.investmentAmount - 1) * 100).toFixed(1)}%
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="opportunities" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="h-5 w-5" />
                Investment Opportunity Finder
              </CardTitle>
              <CardDescription>
                AI-powered analysis to identify high-potential investment opportunities
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="sector">Sector</Label>
                  <Select value={selectedSector} onValueChange={setSelectedSector}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select sector" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="technology">Technology</SelectItem>
                      <SelectItem value="healthcare">Healthcare</SelectItem>
                      <SelectItem value="financial_services">Financial Services</SelectItem>
                      <SelectItem value="consumer">Consumer</SelectItem>
                      <SelectItem value="industrial">Industrial</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="stage">Investment Stage</Label>
                  <Select value={selectedStage} onValueChange={setSelectedStage}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select stage" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="growth">Growth</SelectItem>
                      <SelectItem value="mature">Mature</SelectItem>
                      <SelectItem value="distressed">Distressed</SelectItem>
                      <SelectItem value="buyout">Buyout</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="target-return">Target IRR (%)</Label>
                  <Input
                    id="target-return"
                    type="number"
                    value={targetReturn}
                    onChange={(e) => setTargetReturn(Number(e.target.value))}
                    placeholder="15"
                  />
                </div>
              </div>

              <Button 
                onClick={handleAnalyzeOpportunities}
                disabled={!selectedSector || !selectedStage || identifyOpportunities.isPending}
                className="w-full"
              >
                {identifyOpportunities.isPending ? "Analyzing..." : "Find Investment Opportunities"}
              </Button>

              {identifyOpportunities.data && (
                <div className="space-y-4 mt-6">
                  <h3 className="text-lg font-semibold">Recommended Opportunities</h3>
                  {(identifyOpportunities.data as InvestmentOpportunity[])?.map((opportunity, index) => (
                    <Card key={index} className="border-l-4 border-l-primary">
                      <CardContent className="pt-4">
                        <div className="flex justify-between items-start mb-3">
                          <div>
                            <h4 className="font-semibold text-lg">{opportunity.companyName}</h4>
                            <p className="text-sm text-muted-foreground">
                              {opportunity.sector} • {opportunity.stage}
                            </p>
                          </div>
                          <Badge 
                            variant={opportunity.recommendation === 'STRONG_BUY' ? 'default' : 'secondary'}
                            className="bg-success/10 text-success"
                          >
                            {opportunity.recommendation}
                          </Badge>
                        </div>
                        
                        <div className="grid grid-cols-2 gap-4 mb-3">
                          <div>
                            <span className="text-sm text-muted-foreground">Projected IRR</span>
                            <div className="font-semibold text-primary">{opportunity.projectedIRR}%</div>
                          </div>
                          <div>
                            <span className="text-sm text-muted-foreground">Risk Score</span>
                            <div className="font-semibold">{opportunity.riskScore}/100</div>
                          </div>
                        </div>
                        
                        <p className="text-sm">{opportunity.rationale}</p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="sector" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5" />
                Sector Intelligence
              </CardTitle>
              <CardDescription>
                Comprehensive market analysis and sector attractiveness scoring
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex gap-4">
                <Select value={selectedSector} onValueChange={setSelectedSector}>
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder="Select sector" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="technology">Technology</SelectItem>
                    <SelectItem value="healthcare">Healthcare</SelectItem>
                    <SelectItem value="financial_services">Financial Services</SelectItem>
                    <SelectItem value="consumer">Consumer</SelectItem>
                    <SelectItem value="industrial">Industrial</SelectItem>
                  </SelectContent>
                </Select>
                
                <Button 
                  onClick={handleSectorAnalysis}
                  disabled={!selectedSector || sectorAnalysis.isPending}
                >
                  {sectorAnalysis.isPending ? "Analyzing..." : "Analyze Sector"}
                </Button>
              </div>

              {sectorAnalysis.data && (
                <div className="space-y-6 mt-6">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-sm">Investment Attractiveness</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="text-2xl font-bold text-primary">
                          {(sectorAnalysis.data as SectorAnalysis).investmentAttractiveness}/10
                        </div>
                        <Progress value={(sectorAnalysis.data as SectorAnalysis).investmentAttractiveness * 10} className="mt-2" />
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-sm">Growth Rate</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="text-2xl font-bold text-primary">
                          {(sectorAnalysis.data as SectorAnalysis).growthRate}%
                        </div>
                        <p className="text-xs text-muted-foreground">Annual growth</p>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-sm">Market Size</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="text-2xl font-bold text-primary">
                          {formatCurrency((sectorAnalysis.data as SectorAnalysis).marketSize)}
                        </div>
                        <p className="text-xs text-muted-foreground">Total addressable market</p>
                      </CardContent>
                    </Card>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <Card>
                      <CardHeader>
                        <CardTitle className="text-sm">Key Growth Drivers</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <ul className="space-y-1">
                          {(sectorAnalysis.data as SectorAnalysis).keyDrivers?.map((driver, index) => (
                            <li key={index} className="text-sm flex items-center gap-2">
                              <CheckCircle className="h-3 w-3 text-success" />
                              {driver}
                            </li>
                          ))}
                        </ul>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardHeader>
                        <CardTitle className="text-sm">Market Trends</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <ul className="space-y-1">
                          {(sectorAnalysis.data as SectorAnalysis).trends?.map((trend, index) => (
                            <li key={index} className="text-sm flex items-center gap-2">
                              <TrendingUp className="h-3 w-3 text-primary" />
                              {trend}
                            </li>
                          ))}
                        </ul>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardHeader>
                        <CardTitle className="text-sm">Risk Factors</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <ul className="space-y-1">
                          {(sectorAnalysis.data as SectorAnalysis).risks?.map((risk, index) => (
                            <li key={index} className="text-sm flex items-center gap-2">
                              <AlertTriangle className="h-3 w-3 text-warning" />
                              {risk}
                            </li>
                          ))}
                        </ul>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="risk" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertTriangle className="h-5 w-5" />
                Risk Management Dashboard
              </CardTitle>
              <CardDescription>
                Portfolio risk assessment and stress testing
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-center py-12">
                <AlertTriangle className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">Risk Analysis Module</h3>
                <p className="text-muted-foreground mb-4">
                  Advanced risk assessment tools including VaR calculation, stress testing, and ESG analysis
                </p>
                <Button variant="outline">
                  Configure Risk Parameters
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}