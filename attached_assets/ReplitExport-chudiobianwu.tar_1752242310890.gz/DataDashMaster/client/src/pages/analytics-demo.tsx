import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  TrendingUp, DollarSign, Target, AlertTriangle, CheckCircle, 
  BarChart3, PieChart, Building2, Lightbulb 
} from "lucide-react";
import { ExportOptions } from "@/components/ExportOptions";

export default function AnalyticsDemo() {
  const [analysisResults, setAnalysisResults] = useState({
    valuation: {
      dcfValue: 158189225,
      recommendation: "BUY",
      confidenceScore: 85,
      upside: 60,
      downside: 20,
      keyRisks: ["Market volatility in AI and cloud computing sectors", "Potential overvaluation compared to peers"]
    },
    sectorAnalysis: {
      healthcare: {
        marketSize: 3200000000000,
        growthRate: 5.5,
        investmentAttractiveness: 8,
        keyDrivers: ["Aging population", "Advancements in medical technology"],
        trends: ["Telemedicine expansion", "Personalized medicine"]
      },
      technology: {
        marketSize: 1700000000000,
        growthRate: 8.5,
        investmentAttractiveness: 9,
        keyDrivers: ["Innovation in AI", "Cloud computing expansion"],
        trends: ["Increased focus on cybersecurity", "Rise of remote work technologies"]
      }
    }
  });

  const formatCurrency = (amount: number) => {
    if (amount >= 1e12) return `$${(amount / 1e12).toFixed(1)}T`;
    if (amount >= 1e9) return `$${(amount / 1e9).toFixed(1)}B`;
    if (amount >= 1e6) return `$${(amount / 1e6).toFixed(1)}M`;
    return `$${amount.toLocaleString()}`;
  };

  return (
    <div className="space-y-6 p-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-primary">Private Equity Analytics Demo</h1>
          <p className="text-muted-foreground">
            Advanced AI-powered investment analysis surpassing traditional analyst capabilities
          </p>
        </div>
        <div className="flex gap-2">
          <ExportOptions 
            data={analysisResults} 
            title="Private Equity Analytics Report" 
            type="valuation" 
          />
          <Badge variant="secondary" className="bg-primary/10 text-primary">
            Citation Capital Analytics
          </Badge>
        </div>
      </div>

      {/* Live Analysis Results */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Investment Valuation Results */}
        <Card className="border-l-4 border-l-primary">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Target className="h-5 w-5 text-primary" />
              Live Investment Valuation: TechCorp Inc
            </CardTitle>
            <CardDescription>
              AI-powered DCF analysis with investment recommendation
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center p-4 bg-primary/5 rounded-lg">
                <div className="text-2xl font-bold text-primary">
                  {formatCurrency(analysisResults.valuation.dcfValue)}
                </div>
                <p className="text-sm text-muted-foreground">DCF Valuation</p>
              </div>
              <div className="text-center p-4 bg-success/10 rounded-lg">
                <div className="text-2xl font-bold text-success">
                  {analysisResults.valuation.recommendation}
                </div>
                <p className="text-sm text-muted-foreground">
                  {analysisResults.valuation.confidenceScore}% Confidence
                </p>
              </div>
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-sm">Upside Potential</span>
                <span className="text-sm font-semibold text-success">+{analysisResults.valuation.upside}%</span>
              </div>
              <Progress value={analysisResults.valuation.upside} className="h-2" />
              
              <div className="flex justify-between">
                <span className="text-sm">Downside Risk</span>
                <span className="text-sm font-semibold text-destructive">-{analysisResults.valuation.downside}%</span>
              </div>
              <Progress value={analysisResults.valuation.downside} className="h-2" />
            </div>

            <div className="space-y-2">
              <h4 className="font-semibold text-sm">Key Risk Factors:</h4>
              {analysisResults.valuation.keyRisks.map((risk, index) => (
                <div key={index} className="flex items-start gap-2 text-sm">
                  <AlertTriangle className="h-3 w-3 text-warning mt-1 flex-shrink-0" />
                  <span>{risk}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Sector Intelligence Dashboard */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="h-5 w-5 text-primary" />
              Sector Intelligence Dashboard
            </CardTitle>
            <CardDescription>
              Real-time market analysis across multiple sectors
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            
            {/* Technology Sector */}
            <div className="p-4 border rounded-lg bg-primary/5">
              <div className="flex items-center justify-between mb-3">
                <h4 className="font-semibold">Technology Sector</h4>
                <Badge className="bg-primary/20 text-primary">
                  Score: {analysisResults.sectorAnalysis.technology.investmentAttractiveness}/10
                </Badge>
              </div>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-muted-foreground">Market Size</span>
                  <div className="font-semibold">
                    {formatCurrency(analysisResults.sectorAnalysis.technology.marketSize)}
                  </div>
                </div>
                <div>
                  <span className="text-muted-foreground">Growth Rate</span>
                  <div className="font-semibold text-success">
                    {analysisResults.sectorAnalysis.technology.growthRate}%
                  </div>
                </div>
              </div>
              <div className="mt-2">
                <span className="text-xs text-muted-foreground">Key Trends:</span>
                <div className="flex flex-wrap gap-1 mt-1">
                  {analysisResults.sectorAnalysis.technology.trends.map((trend, index) => (
                    <Badge key={index} variant="outline" className="text-xs">
                      {trend}
                    </Badge>
                  ))}
                </div>
              </div>
            </div>

            {/* Healthcare Sector */}
            <div className="p-4 border rounded-lg bg-secondary/5">
              <div className="flex items-center justify-between mb-3">
                <h4 className="font-semibold">Healthcare Sector</h4>
                <Badge className="bg-secondary/20 text-secondary">
                  Score: {analysisResults.sectorAnalysis.healthcare.investmentAttractiveness}/10
                </Badge>
              </div>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-muted-foreground">Market Size</span>
                  <div className="font-semibold">
                    {formatCurrency(analysisResults.sectorAnalysis.healthcare.marketSize)}
                  </div>
                </div>
                <div>
                  <span className="text-muted-foreground">Growth Rate</span>
                  <div className="font-semibold text-success">
                    {analysisResults.sectorAnalysis.healthcare.growthRate}%
                  </div>
                </div>
              </div>
              <div className="mt-2">
                <span className="text-xs text-muted-foreground">Key Drivers:</span>
                <div className="flex flex-wrap gap-1 mt-1">
                  {analysisResults.sectorAnalysis.healthcare.keyDrivers.map((driver, index) => (
                    <Badge key={index} variant="outline" className="text-xs">
                      {driver}
                    </Badge>
                  ))}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Platform Capabilities Overview */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Lightbulb className="h-5 w-5 text-warning" />
            Advanced Analytics Capabilities
          </CardTitle>
          <CardDescription>
            Features that surpass traditional Snowflake/Sigma platforms for private equity
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            
            <div className="p-4 border rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <DollarSign className="h-4 w-4 text-primary" />
                <h4 className="font-semibold">Financial Modeling</h4>
              </div>
              <ul className="text-sm space-y-1">
                <li className="flex items-center gap-2">
                  <CheckCircle className="h-3 w-3 text-success" />
                  DCF Valuation Models
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="h-3 w-3 text-success" />
                  IRR & MOIC Calculations
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="h-3 w-3 text-success" />
                  Investment Recommendations
                </li>
              </ul>
            </div>

            <div className="p-4 border rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <BarChart3 className="h-4 w-4 text-primary" />
                <h4 className="font-semibold">Market Intelligence</h4>
              </div>
              <ul className="text-sm space-y-1">
                <li className="flex items-center gap-2">
                  <CheckCircle className="h-3 w-3 text-success" />
                  Sector Analysis & Scoring
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="h-3 w-3 text-success" />
                  Competitive Benchmarking
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="h-3 w-3 text-success" />
                  Macroeconomic Factors
                </li>
              </ul>
            </div>

            <div className="p-4 border rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <AlertTriangle className="h-4 w-4 text-primary" />
                <h4 className="font-semibold">Risk Management</h4>
              </div>
              <ul className="text-sm space-y-1">
                <li className="flex items-center gap-2">
                  <CheckCircle className="h-3 w-3 text-success" />
                  VaR & Stress Testing
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="h-3 w-3 text-success" />
                  ESG Analysis
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="h-3 w-3 text-success" />
                  Portfolio Optimization
                </li>
              </ul>
            </div>

            <div className="p-4 border rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <Target className="h-4 w-4 text-primary" />
                <h4 className="font-semibold">Deal Sourcing</h4>
              </div>
              <ul className="text-sm space-y-1">
                <li className="flex items-center gap-2">
                  <CheckCircle className="h-3 w-3 text-success" />
                  AI Opportunity Identification
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="h-3 w-3 text-success" />
                  Due Diligence Automation
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="h-3 w-3 text-success" />
                  Exit Strategy Planning
                </li>
              </ul>
            </div>

            <div className="p-4 border rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <PieChart className="h-4 w-4 text-primary" />
                <h4 className="font-semibold">Portfolio Analytics</h4>
              </div>
              <ul className="text-sm space-y-1">
                <li className="flex items-center gap-2">
                  <CheckCircle className="h-3 w-3 text-success" />
                  Real-time Performance
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="h-3 w-3 text-success" />
                  Allocation Optimization
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="h-3 w-3 text-success" />
                  Comparative Analysis
                </li>
              </ul>
            </div>

            <div className="p-4 border rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <Building2 className="h-4 w-4 text-primary" />
                <h4 className="font-semibold">AI Integration</h4>
              </div>
              <ul className="text-sm space-y-1">
                <li className="flex items-center gap-2">
                  <CheckCircle className="h-3 w-3 text-success" />
                  Natural Language Queries
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="h-3 w-3 text-success" />
                  Automated Reporting
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="h-3 w-3 text-success" />
                  Predictive Analytics
                </li>
              </ul>
            </div>
          </div>

          <div className="mt-6 p-4 bg-primary/5 rounded-lg">
            <h3 className="font-semibold mb-2 text-primary">Platform Advantage</h3>
            <p className="text-sm text-muted-foreground">
              This platform combines the data processing power of Snowflake with advanced private equity 
              analytics, AI-powered insights, and investment-specific workflows that traditional platforms 
              lack. The result is a comprehensive solution that can replace multiple analyst functions 
              while providing superior data-driven investment decision making.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}