import { useState } from "react";
import Header from "@/components/layout/Header";
import Sidebar from "@/components/layout/Sidebar";
import DataGrid from "@/components/data/DataGrid";
import ChartPanel from "@/components/charts/ChartPanel";
import SQLEditor from "@/components/sql/SQLEditor";
import AIAssistant from "@/components/ai/AIAssistant";
import ImportModal from "@/components/data/ImportModal";
import WarehouseManager from "@/components/warehouse/WarehouseManager";
import { useWarehouses } from "@/hooks/use-warehouse";
import { useDataSources } from "@/hooks/use-data";

export default function Home() {
  const [selectedWarehouse, setSelectedWarehouse] = useState<number | null>(null);
  const [selectedDataSource, setSelectedDataSource] = useState<number | null>(null);
  const [showAIAssistant, setShowAIAssistant] = useState(false);
  const [showImportModal, setShowImportModal] = useState(false);
  const [showSQLEditor, setShowSQLEditor] = useState(false);
  const [showWarehouseManager, setShowWarehouseManager] = useState(false);
  const [rightPanelTab, setRightPanelTab] = useState<'charts' | 'sql' | 'filters'>('charts');

  const { data: warehouses } = useWarehouses();
  const { data: dataSources } = useDataSources();

  // Auto-select first warehouse and data source
  if (warehouses && warehouses.length > 0 && !selectedWarehouse) {
    setSelectedWarehouse(warehouses[0].id);
  }

  if (dataSources && dataSources.length > 0 && !selectedDataSource) {
    setSelectedDataSource(dataSources[0].id);
  }

  return (
    <div className="h-screen flex flex-col bg-gray-50">
      <Header
        selectedWarehouse={selectedWarehouse}
        warehouses={warehouses || []}
        onWarehouseChange={setSelectedWarehouse}
        onToggleAI={() => setShowAIAssistant(!showAIAssistant)}
        onManageWarehouse={() => setShowWarehouseManager(true)}
      />
      
      <div className="flex flex-1 overflow-hidden">
        <Sidebar
          selectedDataSource={selectedDataSource}
          dataSources={dataSources || []}
          onDataSourceChange={setSelectedDataSource}
          onImportData={() => setShowImportModal(true)}
          warehouses={warehouses || []}
          selectedWarehouse={selectedWarehouse}
        />
        
        <main className="flex-1 flex flex-col overflow-hidden">
          {/* Toolbar */}
          <div className="bg-white border-b border-gray-200 px-6 py-3 flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button
                onClick={() => setShowImportModal(true)}
                className="flex items-center space-x-2 bg-primary text-white px-4 py-2 rounded-lg hover:bg-primary/90 transition-colors"
              >
                <i className="fas fa-plus text-sm"></i>
                <span className="text-sm font-medium">Import Data</span>
              </button>
              
              <button
                onClick={() => setShowSQLEditor(true)}
                className="flex items-center space-x-2 border border-gray-300 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-50 transition-colors"
              >
                <i className="fas fa-code text-sm"></i>
                <span className="text-sm font-medium">SQL Editor</span>
              </button>
              
              <button
                onClick={() => setRightPanelTab('charts')}
                className="flex items-center space-x-2 border border-gray-300 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-50 transition-colors"
              >
                <i className="fas fa-chart-pie text-sm"></i>
                <span className="text-sm font-medium">Create Chart</span>
              </button>
            </div>

            <div className="flex items-center space-x-2">
              <button className="p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded">
                <i className="fas fa-undo text-sm"></i>
              </button>
              <button className="p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded">
                <i className="fas fa-redo text-sm"></i>
              </button>
              <div className="w-px h-6 bg-gray-300"></div>
              <button className="flex items-center space-x-2 bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors">
                <i className="fas fa-save text-sm"></i>
                <span className="text-sm font-medium">Save</span>
              </button>
            </div>
          </div>

          {/* Content Area */}
          <div className="flex-1 flex overflow-hidden">
            <DataGrid 
              dataSourceId={selectedDataSource}
              selectedWarehouse={selectedWarehouse}
            />
            
            <div className="w-80 bg-white border-l border-gray-200 flex flex-col">
              {/* Panel Tabs */}
              <div className="border-b border-gray-200">
                <nav className="flex">
                  <button
                    onClick={() => setRightPanelTab('charts')}
                    className={`px-4 py-3 text-sm font-medium ${
                      rightPanelTab === 'charts'
                        ? 'text-primary border-b-2 border-primary bg-primary/5'
                        : 'text-gray-500 hover:text-gray-700'
                    }`}
                  >
                    Charts
                  </button>
                  <button
                    onClick={() => setRightPanelTab('sql')}
                    className={`px-4 py-3 text-sm font-medium ${
                      rightPanelTab === 'sql'
                        ? 'text-primary border-b-2 border-primary bg-primary/5'
                        : 'text-gray-500 hover:text-gray-700'
                    }`}
                  >
                    SQL
                  </button>
                  <button
                    onClick={() => setRightPanelTab('filters')}
                    className={`px-4 py-3 text-sm font-medium ${
                      rightPanelTab === 'filters'
                        ? 'text-primary border-b-2 border-primary bg-primary/5'
                        : 'text-gray-500 hover:text-gray-700'
                    }`}
                  >
                    Filters
                  </button>
                </nav>
              </div>

              {/* Panel Content */}
              <div className="flex-1 overflow-hidden">
                {rightPanelTab === 'charts' && (
                  <ChartPanel 
                    dataSourceId={selectedDataSource}
                    warehouseId={selectedWarehouse}
                  />
                )}
                {rightPanelTab === 'sql' && (
                  <div className="p-4">
                    <p className="text-sm text-gray-500">Use the SQL Editor for advanced queries</p>
                    <button
                      onClick={() => setShowSQLEditor(true)}
                      className="mt-2 w-full bg-primary text-white py-2 px-4 rounded-lg hover:bg-primary/90 transition-colors text-sm font-medium"
                    >
                      Open SQL Editor
                    </button>
                  </div>
                )}
                {rightPanelTab === 'filters' && (
                  <div className="p-4">
                    <p className="text-sm text-gray-500">Filters will be available here</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </main>
      </div>

      {/* Modals */}
      {showAIAssistant && (
        <AIAssistant
          isOpen={showAIAssistant}
          onClose={() => setShowAIAssistant(false)}
          dataSourceId={selectedDataSource}
        />
      )}

      {showImportModal && (
        <ImportModal
          isOpen={showImportModal}
          onClose={() => setShowImportModal(false)}
        />
      )}

      {showSQLEditor && (
        <SQLEditor
          isOpen={showSQLEditor}
          onClose={() => setShowSQLEditor(false)}
          dataSourceId={selectedDataSource}
          warehouseId={selectedWarehouse}
        />
      )}

      {showWarehouseManager && (
        <WarehouseManager
          isOpen={showWarehouseManager}
          onClose={() => setShowWarehouseManager(false)}
        />
      )}
    </div>
  );
}
