import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  TrendingUp, DollarSign, Target, CheckCircle, Star, 
  BarChart3, Brain, Shield, Zap, Users, Award,
  ArrowRight, Download, Play, FileText
} from "lucide-react";

export default function MarketingBrochure() {
  const [selectedPlan, setSelectedPlan] = useState("professional");

  const features = [
    {
      icon: Brain,
      title: "AI-Powered Analysis",
      description: "Advanced machine learning models for investment recommendations and risk assessment",
      highlight: "85% accuracy rate"
    },
    {
      icon: DollarSign,
      title: "DCF Valuation Engine",
      description: "Sophisticated discounted cash flow models with scenario analysis",
      highlight: "$284M+ valuations processed"
    },
    {
      icon: Target,
      title: "Portfolio Management",
      description: "Real-time tracking of IRR, MOIC, DPI, RVPI, and TVPI metrics",
      highlight: "25.2% average IRR"
    },
    {
      icon: BarChart3,
      title: "Market Intelligence",
      description: "Comprehensive sector analysis covering $5T+ in market data",
      highlight: "Real-time insights"
    },
    {
      icon: Shield,
      title: "Risk Management",
      description: "Advanced VaR calculations, stress testing, and ESG analysis",
      highlight: "Enterprise-grade security"
    },
    {
      icon: FileText,
      title: "Document Processing",
      description: "AI extraction from financial statements, 10-Ks, and audit reports",
      highlight: "100MB file support"
    }
  ];

  const competitiveAdvantages = [
    {
      feature: "AI Investment Recommendations",
      dataflow: "✓ Advanced GPT-4o integration",
      snowflake: "✗ Basic analytics only",
      traditional: "✗ Manual analysis"
    },
    {
      feature: "DCF Valuation Models",
      dataflow: "✓ Automated with confidence scoring",
      snowflake: "✗ Requires manual modeling",
      traditional: "✗ Excel-based calculations"
    },
    {
      feature: "Document Intelligence",
      dataflow: "✓ AI-powered extraction & insights",
      snowflake: "✗ Data loading only",
      traditional: "✗ Manual data entry"
    },
    {
      feature: "Portfolio Metrics",
      dataflow: "✓ Real-time IRR, MOIC, DPI, RVPI",
      snowflake: "✗ Basic reporting",
      traditional: "✗ Quarterly updates"
    },
    {
      feature: "Risk Assessment",
      dataflow: "✓ VaR, stress testing, ESG",
      snowflake: "✗ Limited risk tools",
      traditional: "✗ Basic risk measures"
    },
    {
      feature: "Export Formats",
      dataflow: "✓ Excel, PDF, PowerPoint, CSV",
      snowflake: "✗ Limited export options",
      traditional: "✗ Manual report creation"
    }
  ];

  const testimonials = [
    {
      name: "Sarah Chen",
      role: "Managing Partner",
      company: "Venture Capital Fund",
      quote: "DataFlow Analytics has revolutionized our investment process. The AI recommendations have improved our deal success rate by 40%."
    },
    {
      name: "Michael Rodriguez",
      role: "Investment Director", 
      company: "Private Equity Firm",
      quote: "The automated DCF valuations and risk assessments save us 20+ hours per deal while providing deeper insights than traditional tools."
    },
    {
      name: "Jennifer Park",
      role: "Principal",
      company: "Growth Capital Partners",
      quote: "The portfolio management features give us real-time visibility into our investments. The ROI tracking is unmatched in the industry."
    }
  ];

  const pricing = [
    {
      name: "Starter",
      price: "$2,500",
      period: "per month",
      description: "Perfect for small investment teams",
      features: [
        "Up to 5 active investments",
        "Basic DCF valuations", 
        "Standard risk assessment",
        "Email support"
      ],
      popular: false
    },
    {
      name: "Professional", 
      price: "$7,500",
      period: "per month",
      description: "Ideal for mid-market firms",
      features: [
        "Up to 25 active investments",
        "Advanced AI recommendations",
        "Full portfolio analytics",
        "Market intelligence",
        "Priority support"
      ],
      popular: true
    },
    {
      name: "Enterprise",
      price: "Custom",
      period: "pricing",
      description: "For large investment firms",
      features: [
        "Unlimited investments",
        "Custom AI models",
        "White-label options",
        "API access",
        "Dedicated support"
      ],
      popular: false
    }
  ];

  return (
    <div className="space-y-12 p-6">
      
      {/* Hero Section */}
      <div className="text-center space-y-6 py-12 bg-gradient-to-br from-primary/10 via-secondary/5 to-primary/5 rounded-2xl">
        <Badge variant="secondary" className="bg-warning/20 text-warning">
          <Award className="h-3 w-3 mr-1" />
          Industry Leading Analytics Platform
        </Badge>
        <h1 className="text-4xl md:text-6xl font-bold text-primary">
          DataFlow Analytics
        </h1>
        <p className="text-xl md:text-2xl text-muted-foreground max-w-3xl mx-auto">
          Enterprise Business Intelligence & Financial Analytics Platform
        </p>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
          Like Snowflake, but built for financial analysis. Combine enterprise data warehousing 
          with AI-powered financial modeling, investment analysis, and advanced business intelligence.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button size="lg" className="text-lg px-8">
            <Play className="h-5 w-5 mr-2" />
            Watch Demo
          </Button>
          <Button variant="outline" size="lg" className="text-lg px-8">
            <Download className="h-5 w-5 mr-2" />
            Download Brochure
          </Button>
        </div>
      </div>

      {/* Key Features */}
      <section className="space-y-8">
        <div className="text-center">
          <h2 className="text-3xl font-bold text-primary mb-4">Platform Capabilities</h2>
          <p className="text-lg text-muted-foreground">
            Advanced features designed specifically for private equity investment analysis
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <Card key={index} className="relative overflow-hidden">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-primary/10 rounded-lg">
                    <feature.icon className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <CardTitle className="text-lg">{feature.title}</CardTitle>
                    <Badge variant="outline" className="text-xs">
                      {feature.highlight}
                    </Badge>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Competitive Comparison */}
      <section className="space-y-8">
        <div className="text-center">
          <h2 className="text-3xl font-bold text-primary mb-4">Why Choose DataFlow Analytics?</h2>
          <p className="text-lg text-muted-foreground">
            See how we compare to Snowflake Sigma and traditional analytics tools
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr className="border-b-2 border-primary/20">
                <th className="text-left p-4 font-semibold">Feature</th>
                <th className="text-center p-4 font-semibold text-primary bg-primary/5">
                  DataFlow Analytics
                </th>
                <th className="text-center p-4 font-semibold">Snowflake Sigma</th>
                <th className="text-center p-4 font-semibold">Traditional Tools</th>
              </tr>
            </thead>
            <tbody>
              {competitiveAdvantages.map((row, index) => (
                <tr key={index} className="border-b border-muted">
                  <td className="p-4 font-medium">{row.feature}</td>
                  <td className="p-4 text-center bg-primary/5">
                    <span className="text-success font-semibold">{row.dataflow}</span>
                  </td>
                  <td className="p-4 text-center">
                    <span className="text-muted-foreground">{row.snowflake}</span>
                  </td>
                  <td className="p-4 text-center">
                    <span className="text-muted-foreground">{row.traditional}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* ROI Calculator */}
      <section className="space-y-8">
        <Card className="bg-gradient-to-r from-primary/5 to-secondary/5">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl">Return on Investment</CardTitle>
            <CardDescription className="text-lg">
              See the financial impact of switching to DataFlow Analytics
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
              <div className="space-y-2">
                <div className="text-3xl font-bold text-success">$2.4M</div>
                <div className="text-sm text-muted-foreground">Average Annual Savings</div>
                <div className="text-xs">vs. traditional analyst costs</div>
              </div>
              <div className="space-y-2">
                <div className="text-3xl font-bold text-primary">40%</div>
                <div className="text-sm text-muted-foreground">Faster Deal Processing</div>
                <div className="text-xs">Reduced time to investment decision</div>
              </div>
              <div className="space-y-2">
                <div className="text-3xl font-bold text-warning">25%</div>
                <div className="text-sm text-muted-foreground">Higher Success Rate</div>
                <div className="text-xs">AI-recommended investments</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </section>

      {/* Client Testimonials */}
      <section className="space-y-8">
        <div className="text-center">
          <h2 className="text-3xl font-bold text-primary mb-4">What Our Clients Say</h2>
          <p className="text-lg text-muted-foreground">
            Trusted by leading private equity and venture capital firms
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {testimonials.map((testimonial, index) => (
            <Card key={index}>
              <CardContent className="pt-6">
                <div className="flex mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-5 w-5 text-warning fill-current" />
                  ))}
                </div>
                <blockquote className="text-muted-foreground mb-4">
                  "{testimonial.quote}"
                </blockquote>
                <div>
                  <div className="font-semibold">{testimonial.name}</div>
                  <div className="text-sm text-muted-foreground">
                    {testimonial.role}, {testimonial.company}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Pricing Plans */}
      <section className="space-y-8">
        <div className="text-center">
          <h2 className="text-3xl font-bold text-primary mb-4">Investment Plans</h2>
          <p className="text-lg text-muted-foreground">
            Choose the plan that fits your firm's needs
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {pricing.map((plan, index) => (
            <Card 
              key={index} 
              className={`relative ${plan.popular ? 'border-primary shadow-lg scale-105' : ''}`}
            >
              {plan.popular && (
                <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                  <Badge className="bg-primary">Most Popular</Badge>
                </div>
              )}
              <CardHeader className="text-center">
                <CardTitle className="text-xl">{plan.name}</CardTitle>
                <div className="space-y-2">
                  <div className="text-3xl font-bold text-primary">{plan.price}</div>
                  <div className="text-sm text-muted-foreground">{plan.period}</div>
                </div>
                <CardDescription>{plan.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  {plan.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-success flex-shrink-0" />
                      <span className="text-sm">{feature}</span>
                    </li>
                  ))}
                </ul>
                <Button 
                  className={`w-full mt-6 ${plan.popular ? '' : 'variant-outline'}`}
                  variant={plan.popular ? 'default' : 'outline'}
                >
                  {plan.name === 'Enterprise' ? 'Contact Sales' : 'Start Free Trial'}
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Implementation Process */}
      <section className="space-y-8">
        <div className="text-center">
          <h2 className="text-3xl font-bold text-primary mb-4">Implementation Process</h2>
          <p className="text-lg text-muted-foreground">
            Get up and running in just 30 days
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          {[
            { step: 1, title: "Discovery & Setup", description: "Initial consultation and platform configuration", duration: "Week 1" },
            { step: 2, title: "Data Migration", description: "Import existing portfolio and financial data", duration: "Week 2" },
            { step: 3, title: "Training & Onboarding", description: "Team training and workflow optimization", duration: "Week 3" },
            { step: 4, title: "Go Live", description: "Full platform deployment and ongoing support", duration: "Week 4" }
          ].map((phase, index) => (
            <Card key={index}>
              <CardHeader className="text-center">
                <div className="w-12 h-12 bg-primary text-primary-foreground rounded-full flex items-center justify-center text-lg font-bold mx-auto mb-2">
                  {phase.step}
                </div>
                <CardTitle className="text-lg">{phase.title}</CardTitle>
                <Badge variant="outline">{phase.duration}</Badge>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground text-center">
                  {phase.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Call to Action */}
      <section className="text-center space-y-6 py-12 bg-gradient-to-r from-primary/10 to-secondary/10 rounded-2xl">
        <h2 className="text-3xl font-bold text-primary">Ready to Transform Your Investment Process?</h2>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
          Join leading private equity firms using AI-powered analytics to drive superior investment returns.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button size="lg" className="text-lg px-8">
            <Users className="h-5 w-5 mr-2" />
            Schedule Demo
          </Button>
          <Button variant="outline" size="lg" className="text-lg px-8">
            <ArrowRight className="h-5 w-5 mr-2" />
            Start Free Trial
          </Button>
        </div>
        <p className="text-sm text-muted-foreground">
          30-day free trial • No credit card required • Full platform access
        </p>
      </section>
    </div>
  );
}