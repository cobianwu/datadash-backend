import { useState, useRef } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useDataActions } from "@/hooks/use-data";
import { useToast } from "@/hooks/use-toast";

interface ImportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function ImportModal({ isOpen, onClose }: ImportModalProps) {
  const [dragActive, setDragActive] = useState(false);
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const { uploadFile } = useDataActions();
  const { toast } = useToast();

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    const files = Array.from(e.dataTransfer.files);
    setSelectedFiles(files);
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const files = Array.from(e.target.files);
      setSelectedFiles(files);
    }
  };

  const handleUpload = async () => {
    if (selectedFiles.length === 0) {
      toast({
        title: "No files selected",
        description: "Please select at least one file to upload.",
        variant: "destructive",
      });
      return;
    }

    try {
      for (const file of selectedFiles) {
        await uploadFile.mutateAsync(file);
      }
      
      toast({
        title: "Upload successful",
        description: `Successfully imported ${selectedFiles.length} file(s).`,
      });
      
      setSelectedFiles([]);
      onClose();
    } catch (error) {
      toast({
        title: "Upload failed",
        description: error instanceof Error ? error.message : "Failed to upload files",
        variant: "destructive",
      });
    }
  };

  const getSupportedFormats = () => [
    { icon: "fas fa-file-csv", name: "CSV files", ext: ".csv", color: "text-green-500" },
    { icon: "fas fa-file-excel", name: "Excel files", ext: ".xlsx, .xls", color: "text-green-500" },
    { icon: "fas fa-file-code", name: "JSON files", ext: ".json", color: "text-yellow-500" },
    { icon: "fas fa-file", name: "Parquet files", ext: ".parquet", color: "text-blue-500" }
  ];

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Import Data</DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Import Options */}
          <div className="grid grid-cols-2 gap-4">
            <button
              onClick={() => fileInputRef.current?.click()}
              className="p-6 border-2 border-dashed border-gray-300 rounded-lg hover:border-primary hover:bg-primary/5 transition-colors text-center"
            >
              <i className="fas fa-upload text-3xl text-gray-400 mb-3 block"></i>
              <h3 className="font-medium text-gray-900 mb-1">Upload File</h3>
              <p className="text-sm text-gray-500">CSV, Excel, JSON, Parquet</p>
            </button>
            
            <button
              disabled
              className="p-6 border-2 border-dashed border-gray-300 rounded-lg text-center opacity-50"
            >
              <i className="fas fa-database text-3xl text-gray-400 mb-3 block"></i>
              <h3 className="font-medium text-gray-900 mb-1">Connect Database</h3>
              <p className="text-sm text-gray-500">Coming Soon</p>
            </button>
          </div>

          {/* File Upload Area */}
          <div
            className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
              dragActive 
                ? 'border-primary bg-primary/5' 
                : 'border-gray-300 hover:border-gray-400'
            }`}
            onDragEnter={handleDrag}
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
          >
            <i className="fas fa-cloud-upload-alt text-4xl text-gray-400 mb-4 block"></i>
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              {selectedFiles.length > 0 
                ? `${selectedFiles.length} file(s) selected`
                : 'Drag and drop your files here'
              }
            </h3>
            <p className="text-gray-500 mb-4">or click to browse</p>
            <input
              ref={fileInputRef}
              type="file"
              multiple
              accept=".csv,.xlsx,.xls,.json,.parquet"
              onChange={handleFileSelect}
              className="hidden"
            />
            <Button
              onClick={() => fileInputRef.current?.click()}
              variant="outline"
              disabled={uploadFile.isPending}
            >
              {uploadFile.isPending ? 'Uploading...' : 'Browse Files'}
            </Button>
          </div>

          {/* Selected Files */}
          {selectedFiles.length > 0 && (
            <div className="space-y-2">
              <h4 className="font-medium text-gray-900">Selected Files:</h4>
              {selectedFiles.map((file, index) => (
                <div key={index} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                  <div className="flex items-center space-x-2">
                    <i className="fas fa-file text-gray-500"></i>
                    <span className="text-sm">{file.name}</span>
                    <span className="text-xs text-gray-500">
                      ({(file.size / 1024 / 1024).toFixed(2)} MB)
                    </span>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => {
                      setSelectedFiles(files => files.filter((_, i) => i !== index));
                    }}
                  >
                    <i className="fas fa-times text-xs"></i>
                  </Button>
                </div>
              ))}
            </div>
          )}

          {/* Supported Formats */}
          <div className="bg-gray-50 rounded-lg p-4">
            <h4 className="font-medium text-gray-900 mb-2">Supported Formats</h4>
            <div className="grid grid-cols-2 gap-2">
              {getSupportedFormats().map((format, index) => (
                <div key={index} className="flex items-center space-x-2 text-sm">
                  <i className={`${format.icon} ${format.color}`}></i>
                  <span>{format.name} ({format.ext})</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="flex justify-end space-x-3 pt-4 border-t">
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button 
            onClick={handleUpload}
            disabled={selectedFiles.length === 0 || uploadFile.isPending}
          >
            {uploadFile.isPending ? 'Importing...' : 'Import Data'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
