import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { useDataSourceData, useDataActions } from "@/hooks/use-data";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent } from "@/components/ui/card";
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, ScatterChart, Scatter, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import type { ChartConfig } from "@/types";

interface ChartPanelProps {
  dataSourceId: number | null;
  warehouseId: number | null;
}

export default function ChartPanel({ dataSourceId, warehouseId }: ChartPanelProps) {
  const [selectedChartType, setSelectedChartType] = useState<'bar' | 'line' | 'pie' | 'scatter' | 'heatmap' | 'treemap'>('bar');
  const [chartConfig, setChartConfig] = useState<ChartConfig>({
    type: 'bar',
    title: 'Generated Chart',
    xAxis: '',
    yAxis: '',
    groupBy: '',
    colors: ['hsl(207, 90%, 54%)', 'hsl(224, 71%, 63%)', 'hsl(142, 76%, 36%)', 'hsl(38, 92%, 50%)', 'hsl(0, 84.2%, 60.2%)'],
    aggregation: 'SUM'
  });
  const [chartData, setChartData] = useState<any[]>([]);
  const [aiDescription, setAiDescription] = useState('');

  const { data: sourceData } = useDataSourceData(dataSourceId, 1000, 0);
  const { generateChart } = useDataActions();
  const { toast } = useToast();

  const chartTypes = [
    { type: 'bar', icon: 'fas fa-chart-bar', label: 'Bar' },
    { type: 'line', icon: 'fas fa-chart-line', label: 'Line' },
    { type: 'pie', icon: 'fas fa-chart-pie', label: 'Pie' },
    { type: 'scatter', icon: 'fas fa-braille', label: 'Scatter' },
    { type: 'heatmap', icon: 'fas fa-th', label: 'Heatmap' },
    { type: 'treemap', icon: 'fas fa-th-large', label: 'Treemap' }
  ];

  const aggregationOptions = [
    { value: 'SUM', label: 'SUM' },
    { value: 'AVG', label: 'AVG' },
    { value: 'COUNT', label: 'COUNT' },
    { value: 'MAX', label: 'MAX' },
    { value: 'MIN', label: 'MIN' }
  ];

  // Generate sample chart data when configuration changes
  useEffect(() => {
    if (!sourceData || !chartConfig.xAxis || !chartConfig.yAxis) {
      setChartData([]);
      return;
    }

    try {
      const processedData = processDataForChart(sourceData.data, chartConfig);
      setChartData(processedData);
    } catch (error) {
      console.error('Error processing chart data:', error);
      setChartData([]);
    }
  }, [sourceData, chartConfig]);

  const processDataForChart = (data: any[], config: ChartConfig) => {
    if (!data || data.length === 0) return [];

    // Group data by x-axis value
    const groupedData = data.reduce((acc, row) => {
      const xValue = row[config.xAxis];
      const yValue = Number(row[config.yAxis]) || 0;
      const groupValue = config.groupBy ? row[config.groupBy] : 'value';

      if (!acc[xValue]) {
        acc[xValue] = { [config.xAxis]: xValue };
      }

      if (config.groupBy) {
        acc[xValue][groupValue] = (acc[xValue][groupValue] || 0) + yValue;
      } else {
        acc[xValue].value = (acc[xValue].value || 0) + yValue;
      }

      return acc;
    }, {} as any);

    return Object.values(groupedData).slice(0, 20); // Limit to 20 data points for visualization
  };

  const handleChartTypeChange = (type: typeof selectedChartType) => {
    setSelectedChartType(type);
    setChartConfig(prev => ({ ...prev, type }));
  };

  const handleGenerateAIChart = async () => {
    if (!dataSourceId || !aiDescription.trim()) {
      toast({
        title: "Missing information",
        description: "Please enter a chart description and ensure a data source is selected.",
        variant: "destructive",
      });
      return;
    }

    try {
      const result = await generateChart.mutateAsync({
        description: aiDescription,
        dataSourceId
      });

      if (result) {
        setChartConfig(prev => ({
          ...prev,
          type: result.type || 'bar',
          title: result.title || 'AI Generated Chart',
          xAxis: result.xAxis || prev.xAxis,
          yAxis: result.yAxis || prev.yAxis,
          groupBy: result.groupBy || prev.groupBy
        }));
        setSelectedChartType(result.type || 'bar');
        
        toast({
          title: "Chart generated",
          description: "AI has created a chart based on your description.",
        });
      }
    } catch (error) {
      toast({
        title: "Generation failed",
        description: "Failed to generate chart with AI. Please try again.",
        variant: "destructive",
      });
    }
  };

  const renderChart = () => {
    if (!chartData || chartData.length === 0) {
      return (
        <div className="h-48 flex items-center justify-center text-gray-500">
          <div className="text-center">
            <i className="fas fa-chart-bar text-2xl mb-2 block text-gray-300"></i>
            <p className="text-sm">Configure chart to see preview</p>
          </div>
        </div>
      );
    }

    switch (selectedChartType) {
      case 'bar':
        return (
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
              <XAxis dataKey={chartConfig.xAxis} tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} />
              <Tooltip />
              <Bar dataKey="value" fill={chartConfig.colors[0]} />
            </BarChart>
          </ResponsiveContainer>
        );

      case 'line':
        return (
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
              <XAxis dataKey={chartConfig.xAxis} tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} />
              <Tooltip />
              <Line type="monotone" dataKey="value" stroke={chartConfig.colors[0]} strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        );

      case 'pie':
        return (
          <ResponsiveContainer width="100%" height={200}>
            <PieChart>
              <Pie
                data={chartData}
                dataKey="value"
                nameKey={chartConfig.xAxis}
                cx="50%"
                cy="50%"
                outerRadius={70}
                label
              >
                {chartData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={chartConfig.colors[index % chartConfig.colors.length]} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        );

      case 'scatter':
        return (
          <ResponsiveContainer width="100%" height={200}>
            <ScatterChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
              <XAxis dataKey={chartConfig.xAxis} tick={{ fontSize: 12 }} />
              <YAxis dataKey="value" tick={{ fontSize: 12 }} />
              <Tooltip cursor={{ strokeDasharray: '3 3' }} />
              <Scatter dataKey="value" fill={chartConfig.colors[0]} />
            </ScatterChart>
          </ResponsiveContainer>
        );

      default:
        return (
          <div className="h-48 flex items-center justify-center text-gray-500">
            <p className="text-sm">{selectedChartType} chart coming soon</p>
          </div>
        );
    }
  };

  if (!dataSourceId) {
    return (
      <div className="p-4 text-center">
        <i className="fas fa-chart-pie text-3xl text-gray-300 mb-3 block"></i>
        <p className="text-sm text-gray-500">Select a data source to create charts</p>
      </div>
    );
  }

  return (
    <div className="flex-1 p-4 overflow-auto space-y-6">
      {/* AI Chart Generation */}
      <div>
        <h3 className="text-sm font-medium text-gray-900 mb-3">AI Chart Generation</h3>
        <div className="space-y-3">
          <Input
            placeholder="Describe the chart you want to create..."
            value={aiDescription}
            onChange={(e) => setAiDescription(e.target.value)}
            className="text-sm"
          />
          <Button
            onClick={handleGenerateAIChart}
            disabled={generateChart.isPending || !aiDescription.trim()}
            className="w-full bg-secondary hover:bg-primary text-white"
            size="sm"
          >
            <i className="fas fa-magic mr-2"></i>
            {generateChart.isPending ? 'Generating...' : 'Generate with AI'}
          </Button>
        </div>
      </div>

      {/* Chart Type Selector */}
      <div>
        <h3 className="text-sm font-medium text-gray-900 mb-3">Chart Type</h3>
        <div className="grid grid-cols-3 gap-2">
          {chartTypes.map((chart) => (
            <button
              key={chart.type}
              onClick={() => handleChartTypeChange(chart.type as any)}
              className={`chart-type-button ${
                selectedChartType === chart.type ? 'active' : ''
              }`}
            >
              <i className={`${chart.icon} text-lg mb-1 block`}></i>
              <div className="text-xs">{chart.label}</div>
            </button>
          ))}
        </div>
      </div>

      {/* Chart Configuration */}
      <div>
        <h3 className="text-sm font-medium text-gray-900 mb-3">Data Configuration</h3>
        <div className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-gray-700 mb-1">X-Axis</label>
            <Select
              value={chartConfig.xAxis}
              onValueChange={(value) => setChartConfig(prev => ({ ...prev, xAxis: value }))}
            >
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Select column" />
              </SelectTrigger>
              <SelectContent>
                {sourceData?.columns.map((column) => (
                  <SelectItem key={column} value={column}>
                    {column}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <label className="block text-xs font-medium text-gray-700 mb-1">Y-Axis</label>
            <div className="flex space-x-2">
              <Select
                value={chartConfig.aggregation}
                onValueChange={(value) => setChartConfig(prev => ({ ...prev, aggregation: value as any }))}
              >
                <SelectTrigger className="w-20">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {aggregationOptions.map((option) => (
                    <SelectItem key={option.value} value={option.value}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select
                value={chartConfig.yAxis}
                onValueChange={(value) => setChartConfig(prev => ({ ...prev, yAxis: value }))}
              >
                <SelectTrigger className="flex-1">
                  <SelectValue placeholder="Select column" />
                </SelectTrigger>
                <SelectContent>
                  {sourceData?.columns.filter(col => 
                    sourceData.schema[col] === 'NUMBER' || 
                    sourceData.schema[col] === 'INTEGER'
                  ).map((column) => (
                    <SelectItem key={column} value={column}>
                      {column}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-gray-700 mb-1">Group By (Optional)</label>
            <Select
              value={chartConfig.groupBy}
              onValueChange={(value) => setChartConfig(prev => ({ ...prev, groupBy: value }))}
            >
              <SelectTrigger className="w-full">
                <SelectValue placeholder="None" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">None</SelectItem>
                {sourceData?.columns.filter(col => col !== chartConfig.xAxis && col !== chartConfig.yAxis).map((column) => (
                  <SelectItem key={column} value={column}>
                    {column}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <label className="block text-xs font-medium text-gray-700 mb-1">Chart Title</label>
            <Input
              value={chartConfig.title}
              onChange={(e) => setChartConfig(prev => ({ ...prev, title: e.target.value }))}
              placeholder="Enter chart title"
              className="text-sm"
            />
          </div>
        </div>
      </div>

      {/* Chart Preview */}
      <div>
        <h3 className="text-sm font-medium text-gray-900 mb-3">Preview</h3>
        <Card>
          <CardContent className="p-4">
            {chartConfig.title && (
              <h4 className="text-sm font-medium text-center mb-3">{chartConfig.title}</h4>
            )}
            {renderChart()}
          </CardContent>
        </Card>
      </div>

      {/* Chart Actions */}
      <div className="space-y-2">
        <Button
          className="w-full bg-primary text-white hover:bg-primary/90"
          disabled={!chartConfig.xAxis || !chartConfig.yAxis}
        >
          Add to Dashboard
        </Button>
        <Button
          variant="outline"
          className="w-full"
          disabled={!chartConfig.xAxis || !chartConfig.yAxis}
        >
          Export Chart
        </Button>
      </div>
    </div>
  );
}
