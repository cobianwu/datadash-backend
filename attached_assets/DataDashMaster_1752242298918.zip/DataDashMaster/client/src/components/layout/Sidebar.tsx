import { Button } from "@/components/ui/button";
import type { DataSource, Warehouse } from "@/types";

interface SidebarProps {
  selectedDataSource: number | null;
  dataSources: DataSource[];
  onDataSourceChange: (dataSourceId: number) => void;
  onImportData: () => void;
  warehouses: Warehouse[];
  selectedWarehouse: number | null;
}

export default function Sidebar({
  selectedDataSource,
  dataSources,
  onDataSourceChange,
  onImportData,
  warehouses,
  selectedWarehouse
}: SidebarProps) {
  const currentWarehouse = warehouses.find(w => w.id === selectedWarehouse);

  const getFileIcon = (type: string) => {
    switch (type) {
      case 'csv': return 'fas fa-file-csv text-green-500';
      case 'excel': return 'fas fa-file-excel text-green-500';
      case 'json': return 'fas fa-file-code text-yellow-500';
      case 'parquet': return 'fas fa-file text-blue-500';
      default: return 'fas fa-table text-gray-500';
    }
  };

  return (
    <aside className="w-64 bg-white border-r border-gray-200 flex flex-col">
      {/* Navigation */}
      <nav className="flex-1 px-4 py-6">
        <div className="space-y-1">
          <a href="#" className="flex items-center space-x-3 px-3 py-2 bg-primary/10 text-primary rounded-lg font-medium">
            <i className="fas fa-table text-sm"></i>
            <span>Workbooks</span>
          </a>
          <a href="#" className="flex items-center space-x-3 px-3 py-2 text-gray-700 hover:bg-gray-50 rounded-lg">
            <i className="fas fa-chart-bar text-sm"></i>
            <span>Dashboards</span>
          </a>
          <a href="#" className="flex items-center space-x-3 px-3 py-2 text-gray-700 hover:bg-gray-50 rounded-lg">
            <i className="fas fa-database text-sm"></i>
            <span>Data Sources</span>
          </a>
          <button
            onClick={onImportData}
            className="w-full flex items-center space-x-3 px-3 py-2 text-gray-700 hover:bg-gray-50 rounded-lg"
          >
            <i className="fas fa-upload text-sm"></i>
            <span>Import Data</span>
          </button>
        </div>

        {/* Data Sources */}
        <div className="mt-8">
          <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-3">Data Sources</h3>
          <div className="space-y-1">
            {dataSources.length === 0 ? (
              <p className="text-sm text-gray-500 px-3 py-2">No data sources yet</p>
            ) : (
              dataSources.map((source) => (
                <button
                  key={source.id}
                  onClick={() => onDataSourceChange(source.id)}
                  className={`w-full flex items-center space-x-2 px-3 py-2 rounded cursor-pointer text-left ${
                    selectedDataSource === source.id ? 'bg-primary/10 text-primary' : 'hover:bg-gray-50'
                  }`}
                >
                  <i className={`${getFileIcon(source.type)} text-sm`}></i>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm truncate">{source.name}</div>
                    <div className="text-xs text-gray-500">{source.rowCount.toLocaleString()} rows</div>
                  </div>
                  {source.status === 'processing' && (
                    <div className="w-2 h-2 bg-yellow-500 rounded-full animate-pulse"></div>
                  )}
                  {source.status === 'ready' && (
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  )}
                  {source.status === 'error' && (
                    <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                  )}
                </button>
              ))
            )}
          </div>
        </div>
      </nav>

      {/* Warehouse Status */}
      {currentWarehouse && (
        <div className="p-4 border-t border-gray-200">
          <div className="bg-gray-50 rounded-lg p-3">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-medium text-gray-500">Warehouse Status</span>
              <span className={`text-xs ${
                currentWarehouse.status === 'running' ? 'text-green-600' : 'text-gray-600'
              }`}>
                ● {currentWarehouse.status}
              </span>
            </div>
            <div className="text-sm font-medium text-gray-900">
              {currentWarehouse.size} ({currentWarehouse.nodes} nodes)
            </div>
            <div className="text-xs text-gray-500 mt-1">
              {currentWarehouse.creditsPerHour} credits/hour
            </div>
          </div>
        </div>
      )}
    </aside>
  );
}
