import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import type { DataSource, DataResponse, QueryHistory, AIResponse, QueryExecutionResult } from "@/types";

export function useDataSources() {
  return useQuery<DataSource[]>({
    queryKey: ['/api/data-sources'],
  });
}

export function useDataSourceData(dataSourceId: number | null, limit = 100, offset = 0) {
  return useQuery<DataResponse>({
    queryKey: ['/api/data-sources', dataSourceId, 'data', { limit, offset }],
    enabled: !!dataSourceId,
  });
}

export function useQueryHistory() {
  return useQuery<QueryHistory[]>({
    queryKey: ['/api/query-history'],
  });
}

export function useDataActions() {
  const queryClient = useQueryClient();

  const uploadFile = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append('file', file);
      
      const response = await fetch('/api/data-sources/upload', {
        method: 'POST',
        body: formData,
        credentials: 'include',
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Upload failed');
      }
      
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/data-sources'] });
    },
  });

  const executeSQL = useMutation({
    mutationFn: async (params: { 
      query: string; 
      warehouseId: number; 
      dataSourceId: number;
    }) => {
      const response = await apiRequest('POST', '/api/sql/execute', params);
      return response.json() as Promise<QueryExecutionResult>;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/query-history'] });
    },
  });

  const chatWithAI = useMutation({
    mutationFn: async (params: { message: string; context?: any }) => {
      const response = await apiRequest('POST', '/api/ai/chat', params);
      return response.json() as Promise<AIResponse>;
    },
  });

  const generateChart = useMutation({
    mutationFn: async (params: { description: string; dataSourceId: number }) => {
      const response = await apiRequest('POST', '/api/ai/generate-chart', params);
      return response.json();
    },
  });

  const generateSQL = useMutation({
    mutationFn: async (params: { query: string; dataSourceId: number }) => {
      const response = await apiRequest('POST', '/api/ai/generate-sql', params);
      return response.json();
    },
  });

  return {
    uploadFile,
    executeSQL,
    chatWithAI,
    generateChart,
    generateSQL,
  };
}
