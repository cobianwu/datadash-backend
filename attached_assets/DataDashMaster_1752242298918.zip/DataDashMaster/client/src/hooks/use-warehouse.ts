import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import type { Warehouse } from "@/types";

export function useWarehouses() {
  return useQuery<Warehouse[]>({
    queryKey: ['/api/warehouses'],
  });
}

export function useWarehouseActions() {
  const queryClient = useQueryClient();

  const createWarehouse = useMutation({
    mutationFn: async (warehouse: Omit<Warehouse, 'id' | 'createdAt'>) => {
      const response = await apiRequest('POST', '/api/warehouses', warehouse);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/warehouses'] });
    },
  });

  const updateWarehouse = useMutation({
    mutationFn: async ({ id, updates }: { id: number; updates: Partial<Warehouse> }) => {
      const response = await apiRequest('PUT', `/api/warehouses/${id}`, updates);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/warehouses'] });
    },
  });

  return {
    createWarehouse,
    updateWarehouse,
  };
}
