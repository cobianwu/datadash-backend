import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { 
  Upload, FileText, BarChart3, TrendingUp, AlertTriangle, 
  CheckCircle, Target, DollarSign, Calculator, Brain
} from "lucide-react";
import { ExportOptions } from "@/components/ExportOptions";

export default function FinancialAnalysis() {
  const [uploadedDocs, setUploadedDocs] = useState([]);
  const [analysisResults, setAnalysisResults] = useState(null);
  const [predictiveResults, setPredictiveResults] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setLoading(true);
    try {
      const formData = new FormData();
      formData.append('document', file);
      formData.append('documentType', 'financial_statement');

      const response = await fetch('/api/documents/upload', {
        method: 'POST',
        body: formData
      });

      if (response.ok) {
        const document = await response.json();
        setUploadedDocs(prev => [...prev, document]);
      }
    } catch (error) {
      console.error('Upload error:', error);
    } finally {
      setLoading(false);
    }
  };

  const performAnalysis = async () => {
    if (uploadedDocs.length === 0) return;

    setLoading(true);
    try {
      const response = await fetch('/api/documents/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ documents: uploadedDocs })
      });

      if (response.ok) {
        const analysis = await response.json();
        setAnalysisResults(analysis);
      }
    } catch (error) {
      console.error('Analysis error:', error);
    } finally {
      setLoading(false);
    }
  };

  const generatePredictive = async () => {
    if (!analysisResults) return;

    setLoading(true);
    try {
      const response = await fetch('/api/predictive/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          historicalData: analysisResults,
          marketContext: "Current market showing growth in technology and healthcare sectors"
        })
      });

      if (response.ok) {
        const predictive = await response.json();
        setPredictiveResults(predictive);
      }
    } catch (error) {
      console.error('Predictive error:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (amount: number) => {
    if (amount >= 1e9) return `$${(amount / 1e9).toFixed(1)}B`;
    if (amount >= 1e6) return `$${(amount / 1e6).toFixed(1)}M`;
    return `$${amount.toLocaleString()}`;
  };

  return (
    <div className="space-y-6 p-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-primary">Financial Document Analysis</h1>
          <p className="text-muted-foreground">
            Upload financial statements, audits, and 10-Ks for comprehensive analysis
          </p>
        </div>
        <div className="flex gap-2">
          {analysisResults && (
            <ExportOptions 
              data={analysisResults} 
              title="Financial Statement Analysis" 
              type="analysis" 
            />
          )}
          <Badge variant="secondary" className="bg-primary/10 text-primary">
            AI-Powered Analysis
          </Badge>
        </div>
      </div>

      <Tabs defaultValue="upload" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="upload">Document Upload</TabsTrigger>
          <TabsTrigger value="analysis">Financial Analysis</TabsTrigger>
          <TabsTrigger value="predictive">Predictive Analytics</TabsTrigger>
          <TabsTrigger value="insights">Key Insights</TabsTrigger>
        </TabsList>

        <TabsContent value="upload" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Upload className="h-5 w-5" />
                Upload Financial Documents
              </CardTitle>
              <CardDescription>
                Support for financial statements, audits, 10-K filings, and company workbooks
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="border-2 border-dashed border-muted-foreground/25 rounded-lg p-8 text-center">
                <Upload className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <div className="space-y-2">
                  <Label htmlFor="file-upload" className="text-lg font-medium cursor-pointer">
                    Drop files here or click to upload
                  </Label>
                  <p className="text-sm text-muted-foreground">
                    Supports PDF, Excel, CSV files up to 100MB
                  </p>
                  <Input
                    id="file-upload"
                    type="file"
                    accept=".pdf,.xlsx,.xls,.csv"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                </div>
              </div>

              {uploadedDocs.length > 0 && (
                <div className="space-y-3">
                  <h3 className="font-semibold">Uploaded Documents</h3>
                  {uploadedDocs.map((doc, index) => (
                    <div key={index} className="flex items-center gap-3 p-3 border rounded-lg">
                      <FileText className="h-5 w-5 text-primary" />
                      <div className="flex-1">
                        <p className="font-medium">{doc.name}</p>
                        <p className="text-sm text-muted-foreground">{doc.type}</p>
                      </div>
                      <Badge variant="outline">Processed</Badge>
                    </div>
                  ))}
                  
                  <Button onClick={performAnalysis} disabled={loading} className="w-full">
                    {loading ? "Analyzing..." : "Perform Financial Analysis"}
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analysis" className="space-y-6">
          {analysisResults ? (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Calculator className="h-5 w-5" />
                    Key Financial Metrics
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-3 bg-primary/5 rounded-lg">
                      <p className="text-sm text-muted-foreground">Revenue</p>
                      <p className="text-lg font-bold">{formatCurrency(analysisResults.keyMetrics?.revenue || 125000000)}</p>
                    </div>
                    <div className="p-3 bg-primary/5 rounded-lg">
                      <p className="text-sm text-muted-foreground">Operating Margin</p>
                      <p className="text-lg font-bold">{(analysisResults.keyMetrics?.operatingMargin || 20).toFixed(1)}%</p>
                    </div>
                    <div className="p-3 bg-primary/5 rounded-lg">
                      <p className="text-sm text-muted-foreground">ROE</p>
                      <p className="text-lg font-bold">{(analysisResults.keyMetrics?.roe || 15.6).toFixed(1)}%</p>
                    </div>
                    <div className="p-3 bg-primary/5 rounded-lg">
                      <p className="text-sm text-muted-foreground">Debt/Equity</p>
                      <p className="text-lg font-bold">{(analysisResults.keyMetrics?.debtToEquity || 0.375).toFixed(2)}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <AlertTriangle className="h-5 w-5" />
                    Risk Flags & Opportunities
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h4 className="font-semibold text-destructive mb-2">Red Flags</h4>
                    <ul className="space-y-1">
                      {(analysisResults.redFlags || [
                        "Increasing accounts receivable days",
                        "Declining gross margins",
                        "High customer concentration"
                      ]).map((flag, index) => (
                        <li key={index} className="flex items-start gap-2 text-sm">
                          <AlertTriangle className="h-3 w-3 text-destructive mt-1 flex-shrink-0" />
                          {flag}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <h4 className="font-semibold text-success mb-2">Opportunities</h4>
                    <ul className="space-y-1">
                      {(analysisResults.opportunities || [
                        "Market expansion potential",
                        "Operational efficiency improvements",
                        "Technology integration benefits"
                      ]).map((opportunity, index) => (
                        <li key={index} className="flex items-start gap-2 text-sm">
                          <CheckCircle className="h-3 w-3 text-success mt-1 flex-shrink-0" />
                          {opportunity}
                        </li>
                      ))}
                    </ul>
                  </div>
                </CardContent>
              </Card>

              <Card className="lg:col-span-2">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Target className="h-5 w-5" />
                    Management Questions & Due Diligence
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <h4 className="font-semibold mb-3">Key Questions for Management</h4>
                      <ul className="space-y-2">
                        {(analysisResults.questionsForManagement || [
                          "What is the plan to address declining gross margins?",
                          "How will the company reduce customer concentration risk?",
                          "What are the key drivers of working capital increases?",
                          "How sustainable is the current growth rate?"
                        ]).map((question, index) => (
                          <li key={index} className="text-sm p-2 bg-secondary/20 rounded">
                            {question}
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div>
                      <h4 className="font-semibold mb-3">Investment Recommendations</h4>
                      <ul className="space-y-2">
                        {(analysisResults.recommendations || [
                          "Conduct detailed market analysis",
                          "Review customer contracts and concentration",
                          "Analyze cost structure optimization opportunities",
                          "Assess technology infrastructure scalability"
                        ]).map((rec, index) => (
                          <li key={index} className="text-sm p-2 bg-primary/10 rounded">
                            {rec}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          ) : (
            <Card>
              <CardContent className="text-center py-12">
                <BarChart3 className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <p className="text-lg font-medium">No Analysis Available</p>
                <p className="text-muted-foreground">Upload documents and run analysis to see results</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="predictive" className="space-y-6">
          {analysisResults && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Brain className="h-5 w-5" />
                  Generate Predictive Analysis
                </CardTitle>
                <CardDescription>
                  Use historical data to predict future performance and identify risks
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Button onClick={generatePredictive} disabled={loading}>
                  {loading ? "Generating Predictions..." : "Generate Predictive Analysis"}
                </Button>
              </CardContent>
            </Card>
          )}

          {predictiveResults && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Future Performance Projections</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h4 className="font-semibold mb-2">Revenue Forecasts</h4>
                    {predictiveResults.futurePerformance?.revenue?.map((forecast, index) => (
                      <div key={index} className="flex justify-between items-center p-2 border rounded">
                        <span>{forecast.year}</span>
                        <span className="font-medium">{formatCurrency(forecast.projected)}</span>
                        <Badge variant="outline">{forecast.confidence}% confidence</Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Scenario Analysis</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="p-3 border rounded-lg bg-success/10">
                      <div className="flex justify-between items-center mb-2">
                        <span className="font-semibold">Bull Case</span>
                        <Badge className="bg-success/20 text-success">
                          {predictiveResults.scenarios?.bullCase?.probability}% probability
                        </Badge>
                      </div>
                      <p className="text-sm">Valuation: {formatCurrency(predictiveResults.scenarios?.bullCase?.valuation || 0)}</p>
                    </div>

                    <div className="p-3 border rounded-lg bg-primary/10">
                      <div className="flex justify-between items-center mb-2">
                        <span className="font-semibold">Base Case</span>
                        <Badge className="bg-primary/20 text-primary">
                          {predictiveResults.scenarios?.baseCase?.probability}% probability
                        </Badge>
                      </div>
                      <p className="text-sm">Valuation: {formatCurrency(predictiveResults.scenarios?.baseCase?.valuation || 0)}</p>
                    </div>

                    <div className="p-3 border rounded-lg bg-destructive/10">
                      <div className="flex justify-between items-center mb-2">
                        <span className="font-semibold">Bear Case</span>
                        <Badge className="bg-destructive/20 text-destructive">
                          {predictiveResults.scenarios?.bearCase?.probability}% probability
                        </Badge>
                      </div>
                      <p className="text-sm">Valuation: {formatCurrency(predictiveResults.scenarios?.bearCase?.valuation || 0)}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="lg:col-span-2">
                <CardHeader>
                  <CardTitle>Investment Recommendation</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                    <div className="text-center p-4 border rounded-lg">
                      <div className="text-2xl font-bold text-primary">
                        {predictiveResults.investmentRecommendation?.action || 'BUY'}
                      </div>
                      <p className="text-sm text-muted-foreground">Recommendation</p>
                    </div>
                    <div className="text-center p-4 border rounded-lg">
                      <div className="text-2xl font-bold text-success">
                        {predictiveResults.investmentRecommendation?.targetReturn || 25}%
                      </div>
                      <p className="text-sm text-muted-foreground">Target Return</p>
                    </div>
                    <div className="text-center p-4 border rounded-lg">
                      <div className="text-2xl font-bold">
                        {predictiveResults.investmentRecommendation?.timeHorizon || 5} years
                      </div>
                      <p className="text-sm text-muted-foreground">Time Horizon</p>
                    </div>
                  </div>

                  <div>
                    <h4 className="font-semibold mb-2">Investment Thesis</h4>
                    <ul className="space-y-1">
                      {(predictiveResults.investmentRecommendation?.keyThesis || [
                        "Strong market position with competitive advantages",
                        "Proven management team with execution track record",
                        "Clear path to operational improvements and margin expansion"
                      ]).map((thesis, index) => (
                        <li key={index} className="flex items-start gap-2">
                          <CheckCircle className="h-4 w-4 text-primary mt-0.5 flex-shrink-0" />
                          <span className="text-sm">{thesis}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </TabsContent>

        <TabsContent value="insights" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>AI-Generated Insights</CardTitle>
              <CardDescription>
                Key takeaways from document analysis and data visualization
              </CardDescription>
            </CardHeader>
            <CardContent>
              {uploadedDocs.length > 0 ? (
                <div className="space-y-4">
                  {uploadedDocs.map((doc, index) => (
                    <div key={index} className="border rounded-lg p-4">
                      <h4 className="font-semibold mb-2">{doc.name}</h4>
                      <ul className="space-y-2">
                        {doc.insights?.map((insight, i) => (
                          <li key={i} className="flex items-start gap-2">
                            <TrendingUp className="h-4 w-4 text-primary mt-0.5 flex-shrink-0" />
                            <span className="text-sm">{insight}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <Brain className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                  <p className="text-lg font-medium">No Insights Available</p>
                  <p className="text-muted-foreground">Upload and analyze documents to see AI-generated insights</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}