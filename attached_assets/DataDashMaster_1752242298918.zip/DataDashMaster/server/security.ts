import crypto from 'crypto';
import fs from 'fs';
import path from 'path';

// Simple file encryption for uploaded files
const ENCRYPTION_KEY = process.env.ENCRYPTION_KEY || crypto.randomBytes(32);
const ALGORITHM = 'aes-256-gcm';

export class FileEncryption {
  static encryptFile(filePath: string): void {
    try {
      const fileBuffer = fs.readFileSync(filePath);
      const iv = crypto.randomBytes(16);
      const cipher = crypto.createCipheriv(ALGORITHM, ENCRYPTION_KEY, iv);
      
      let encrypted = cipher.update(fileBuffer);
      encrypted = Buffer.concat([encrypted, cipher.final()]);
      
      // For GCM mode, get the authentication tag
      const authTag = cipher.getAuthTag();
      
      // Store IV, auth tag, and encrypted data
      const encryptedData = Buffer.concat([iv, authTag, encrypted]);
      fs.writeFileSync(filePath + '.enc', encryptedData);
      
      // Delete original unencrypted file
      fs.unlinkSync(filePath);
    } catch (error) {
      console.warn('File encryption failed:', error);
    }
  }

  static decryptFile(encryptedPath: string): Buffer {
    try {
      const encryptedData = fs.readFileSync(encryptedPath);
      const iv = encryptedData.slice(0, 16);
      const authTag = encryptedData.slice(16, 32);
      const encrypted = encryptedData.slice(32);
      
      const decipher = crypto.createDecipheriv(ALGORITHM, ENCRYPTION_KEY, iv);
      // Verify auth tag is exactly 16 bytes before setting it
      if (authTag.length !== 16) {
        throw new Error('Invalid authentication tag length');
      }
      decipher.setAuthTag(authTag);
      
      let decrypted = decipher.update(encrypted);
      decrypted = Buffer.concat([decrypted, decipher.final()]);
      
      return decrypted;
    } catch (error) {
      throw new Error('File decryption failed');
    }
  }

  static secureDeleteFile(filePath: string): void {
    try {
      // Overwrite file with random data before deletion
      const stats = fs.statSync(filePath);
      const randomData = crypto.randomBytes(stats.size);
      fs.writeFileSync(filePath, randomData);
      fs.unlinkSync(filePath);
    } catch (error) {
      console.warn('Secure file deletion failed:', error);
    }
  }
}

// Data purging utilities
export class DataPurger {
  static async purgeUserData(userId: number): Promise<void> {
    // Implementation would clear all user data from database
    console.log(`Purging data for user ${userId}`);
    // This would be implemented with actual database calls
  }

  static async scheduleDataPurge(userId: number, days: number): Promise<void> {
    // Implementation would schedule automatic data deletion
    console.log(`Scheduling data purge for user ${userId} in ${days} days`);
  }
}