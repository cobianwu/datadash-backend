export interface SQLParseResult {
  isValid: boolean;
  errors: string[];
  estimatedCost: number;
  affectedRows?: number;
  queryType: 'SELECT' | 'INSERT' | 'UPDATE' | 'DELETE' | 'CREATE' | 'ALTER' | 'DROP';
}

export interface QueryExecutionResult {
  success: boolean;
  data?: any[];
  columns?: string[];
  rowCount: number;
  duration: number;
  creditsUsed: number;
  error?: string;
}

export class SQLParser {
  static validateSQL(query: string): SQLParseResult {
    const trimmedQuery = query.trim().toUpperCase();
    
    // Basic SQL validation
    const sqlKeywords = ['SELECT', 'INSERT', 'UPDATE', 'DELETE', 'CREATE', 'ALTER', 'DROP'];
    const queryType = sqlKeywords.find(keyword => trimmedQuery.startsWith(keyword)) as any || 'SELECT';
    
    const errors: string[] = [];
    
    // Basic syntax checks
    if (!trimmedQuery) {
      errors.push('Query cannot be empty');
    }
    
    if (trimmedQuery.includes('DROP TABLE') || trimmedQuery.includes('DELETE FROM')) {
      errors.push('Destructive operations are not allowed');
    }
    
    // Estimate cost based on query complexity
    let estimatedCost = 0.001; // Base cost
    
    if (trimmedQuery.includes('JOIN')) estimatedCost += 0.002;
    if (trimmedQuery.includes('GROUP BY')) estimatedCost += 0.001;
    if (trimmedQuery.includes('ORDER BY')) estimatedCost += 0.001;
    if (trimmedQuery.includes('WINDOW')) estimatedCost += 0.003;
    
    return {
      isValid: errors.length === 0,
      errors,
      estimatedCost,
      queryType
    };
  }

  static executeSQL(
    query: string, 
    dataSource: any[], 
    warehouseSize: string
  ): QueryExecutionResult {
    const startTime = Date.now();
    
    try {
      // Simulate query execution with in-memory data processing
      const result = this.processQuery(query, dataSource);
      const duration = Date.now() - startTime;
      
      // Calculate credits based on warehouse size and duration
      const sizeMultipliers = {
        'X-Small': 1,
        'Small': 2,
        'Medium': 4,
        'Large': 8,
        'X-Large': 16,
        '2X-Large': 32,
        '3X-Large': 64,
        '4X-Large': 128
      };
      
      const multiplier = sizeMultipliers[warehouseSize as keyof typeof sizeMultipliers] || 1;
      const creditsUsed = (duration / 1000 / 3600) * multiplier; // credits = hours * size
      
      return {
        success: true,
        data: result.data,
        columns: result.columns,
        rowCount: result.data?.length || 0,
        duration,
        creditsUsed: Math.max(0.001, creditsUsed) // Minimum 0.001 credits
      };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Query execution failed',
        rowCount: 0,
        duration: Date.now() - startTime,
        creditsUsed: 0.001
      };
    }
  }

  private static processQuery(query: string, data: any[]): { data: any[], columns: string[] } {
    const upperQuery = query.toUpperCase().trim();
    
    if (!data || data.length === 0) {
      return { data: [], columns: [] };
    }
    
    // Extract columns from first row
    const allColumns = Object.keys(data[0] || {});
    
    // Simple SELECT parsing
    if (upperQuery.startsWith('SELECT')) {
      const selectMatch = query.match(/SELECT\s+(.*?)\s+FROM/i);
      const whereMatch = query.match(/WHERE\s+(.*?)(?:\s+GROUP\s+BY|\s+ORDER\s+BY|\s+LIMIT|$)/i);
      const limitMatch = query.match(/LIMIT\s+(\d+)/i);
      
      let resultData = [...data];
      let resultColumns = allColumns;
      
      // Apply WHERE filter (basic implementation)
      if (whereMatch) {
        const whereClause = whereMatch[1].trim();
        // Simple equality check: COLUMN = 'VALUE'
        const equalityMatch = whereClause.match(/(\w+)\s*=\s*['"]?([^'"]+)['"]?/i);
        if (equalityMatch) {
          const [, column, value] = equalityMatch;
          resultData = resultData.filter(row => 
            String(row[column]).toLowerCase() === value.toLowerCase()
          );
        }
      }
      
      // Apply LIMIT
      if (limitMatch) {
        const limit = parseInt(limitMatch[1]);
        resultData = resultData.slice(0, limit);
      }
      
      // Handle column selection
      if (selectMatch) {
        const selectedCols = selectMatch[1].trim();
        if (selectedCols !== '*') {
          const columns = selectedCols.split(',').map(col => col.trim());
          resultColumns = columns.filter(col => allColumns.includes(col));
          resultData = resultData.map(row => {
            const newRow: any = {};
            resultColumns.forEach(col => {
              newRow[col] = row[col];
            });
            return newRow;
          });
        }
      }
      
      return { data: resultData, columns: resultColumns };
    }
    
    // Default return
    return { data, columns: allColumns };
  }

  static getSQLSuggestions(currentQuery: string, schema: Record<string, string>): string[] {
    const suggestions: string[] = [];
    const query = currentQuery.toLowerCase();
    
    // Column suggestions
    const columns = Object.keys(schema);
    
    if (query.includes('select ') && !query.includes('from')) {
      suggestions.push(...columns);
    }
    
    // Function suggestions
    const functions = [
      'SUM()', 'AVG()', 'COUNT()', 'MAX()', 'MIN()',
      'TYPEOF()', 'PARSE_JSON()', 'OBJECT_CONSTRUCT()',
      'ROW_NUMBER()', 'RANK()', 'LAG()', 'LEAD()'
    ];
    
    if (query.includes('select')) {
      suggestions.push(...functions);
    }
    
    // Keyword suggestions
    const keywords = ['WHERE', 'GROUP BY', 'ORDER BY', 'HAVING', 'LIMIT'];
    suggestions.push(...keywords);
    
    return suggestions.slice(0, 10); // Limit suggestions
  }
}
