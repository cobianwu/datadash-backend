import { AIResponse } from './ai.js';
import OpenAI from 'openai';

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export interface FinancialDocument {
  id: string;
  name: string;
  type: 'audit' | 'financial_statement' | '10k' | 'workbook' | 'other';
  uploadDate: Date;
  content: string;
  extractedData: any;
  insights: string[];
}

export interface FinancialAnalysisResult {
  keyMetrics: {
    revenue: number;
    grossMargin: number;
    operatingMargin: number;
    netMargin: number;
    debtToEquity: number;
    currentRatio: number;
    roe: number;
    roa: number;
  };
  trends: {
    revenueGrowth: number[];
    profitabilityTrend: string;
    leverageTrend: string;
  };
  redFlags: string[];
  opportunities: string[];
  recommendations: string[];
  questionsForManagement: string[];
  valuation: {
    impliedMultiples: {
      evRevenue: number;
      evEbitda: number;
      peRatio: number;
    };
    dcfInputs: {
      terminalGrowthRate: number;
      discountRate: number;
      projectedCashFlows: number[];
    };
  };
}

export interface PredictiveAnalysis {
  futurePerformance: {
    revenue: { year: number; projected: number; confidence: number }[];
    profitability: { year: number; projected: number; confidence: number }[];
    cashFlow: { year: number; projected: number; confidence: number }[];
  };
  riskFactors: {
    factor: string;
    probability: number;
    impact: string;
    mitigation: string;
  }[];
  scenarios: {
    bullCase: { revenue: number; valuation: number; probability: number };
    baseCase: { revenue: number; valuation: number; probability: number };
    bearCase: { revenue: number; valuation: number; probability: number };
  };
  investmentRecommendation: {
    action: 'BUY' | 'HOLD' | 'PASS';
    targetReturn: number;
    timeHorizon: number;
    keyThesis: string[];
  };
}

export class FinancialDocumentProcessor {
  
  static async processFinancialDocument(filePath: string, fileName: string, documentType: string): Promise<FinancialDocument> {
    // Extract text content from document (simplified - would use OCR/PDF parsing in production)
    const content = await this.extractTextContent(filePath, fileName);
    
    // Extract financial data using AI
    const extractedData = await this.extractFinancialData(content, documentType);
    
    // Generate initial insights
    const insights = await this.generateDocumentInsights(content, extractedData);
    
    return {
      id: Date.now().toString(),
      name: fileName,
      type: documentType as any,
      uploadDate: new Date(),
      content,
      extractedData,
      insights
    };
  }

  private static async extractTextContent(filePath: string, fileName: string): Promise<string> {
    // In production, this would use PDF parsing, OCR, or Excel reading libraries
    // For demo, we'll simulate realistic financial document content
    return `Financial Statement Analysis for ${fileName}
    
    Revenue: $125,000,000 (Current Year)
    Revenue: $110,000,000 (Prior Year)
    Revenue: $95,000,000 (Two Years Ago)
    
    Gross Profit: $62,500,000 (50% margin)
    Operating Income: $25,000,000 (20% margin)
    Net Income: $18,750,000 (15% margin)
    
    Total Assets: $200,000,000
    Total Liabilities: $80,000,000
    Shareholders' Equity: $120,000,000
    
    Cash and Cash Equivalents: $25,000,000
    Current Assets: $75,000,000
    Current Liabilities: $35,000,000
    Long-term Debt: $45,000,000
    
    Key Business Metrics:
    - Customer Acquisition Cost: $150
    - Lifetime Value: $2,400
    - Churn Rate: 5% annually
    - Market Share: 12% in core segment
    - R&D Spending: 8% of revenue`;
  }

  private static async extractFinancialData(content: string, documentType: string): Promise<any> {
    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [
          {
            role: "system",
            content: `You are a financial analyst extracting key metrics from ${documentType} documents. Extract financial data and return as JSON with the following structure:
            {
              "revenue": number,
              "grossProfit": number,
              "operatingIncome": number,
              "netIncome": number,
              "totalAssets": number,
              "totalLiabilities": number,
              "equity": number,
              "cash": number,
              "debt": number,
              "currentAssets": number,
              "currentLiabilities": number,
              "historicalRevenue": [numbers],
              "keyMetrics": {additional metrics}
            }`
          },
          {
            role: "user",
            content: content
          }
        ],
        response_format: { type: "json_object" }
      });

      return JSON.parse(response.choices[0].message.content || '{}');
    } catch (error) {
      console.error("Financial data extraction error:", error);
      return {};
    }
  }

  private static async generateDocumentInsights(content: string, extractedData: any): Promise<string[]> {
    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [
          {
            role: "system",
            content: "You are a senior financial analyst. Generate 5-7 key insights from this financial document that would be valuable for private equity due diligence."
          },
          {
            role: "user",
            content: `Document content: ${content}\n\nExtracted data: ${JSON.stringify(extractedData)}`
          }
        ]
      });

      const insights = response.choices[0].message.content || '';
      return insights.split('\n').filter(line => line.trim().length > 0);
    } catch (error) {
      console.error("Insight generation error:", error);
      return ["Error generating insights"];
    }
  }

  static async performFinancialStatementAnalysis(documents: FinancialDocument[]): Promise<FinancialAnalysisResult> {
    try {
      const combinedData = documents.map(doc => doc.extractedData);
      
      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [
          {
            role: "system",
            content: `You are a senior private equity analyst performing comprehensive financial statement analysis. 
            Analyze the provided financial data and return detailed analysis as JSON with this structure:
            {
              "keyMetrics": {
                "revenue": number,
                "grossMargin": number,
                "operatingMargin": number,
                "netMargin": number,
                "debtToEquity": number,
                "currentRatio": number,
                "roe": number,
                "roa": number
              },
              "trends": {
                "revenueGrowth": [numbers],
                "profitabilityTrend": "improving/stable/declining",
                "leverageTrend": "increasing/stable/decreasing"
              },
              "redFlags": [strings],
              "opportunities": [strings],
              "recommendations": [strings],
              "questionsForManagement": [strings],
              "valuation": {
                "impliedMultiples": {
                  "evRevenue": number,
                  "evEbitda": number,
                  "peRatio": number
                },
                "dcfInputs": {
                  "terminalGrowthRate": number,
                  "discountRate": number,
                  "projectedCashFlows": [numbers]
                }
              }
            }`
          },
          {
            role: "user",
            content: `Analyze this financial data: ${JSON.stringify(combinedData)}`
          }
        ],
        response_format: { type: "json_object" }
      });

      return JSON.parse(response.choices[0].message.content || '{}');
    } catch (error) {
      console.error("Financial analysis error:", error);
      throw new Error("Failed to perform financial statement analysis");
    }
  }

  static async generatePredictiveAnalysis(historicalData: any[], marketContext: string): Promise<PredictiveAnalysis> {
    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [
          {
            role: "system",
            content: `You are a quantitative analyst specializing in predictive modeling for private equity investments.
            Based on historical data and market context, generate predictive analysis as JSON:
            {
              "futurePerformance": {
                "revenue": [{"year": number, "projected": number, "confidence": number}],
                "profitability": [{"year": number, "projected": number, "confidence": number}],
                "cashFlow": [{"year": number, "projected": number, "confidence": number}]
              },
              "riskFactors": [{"factor": string, "probability": number, "impact": string, "mitigation": string}],
              "scenarios": {
                "bullCase": {"revenue": number, "valuation": number, "probability": number},
                "baseCase": {"revenue": number, "valuation": number, "probability": number},
                "bearCase": {"revenue": number, "valuation": number, "probability": number}
              },
              "investmentRecommendation": {
                "action": "BUY/HOLD/PASS",
                "targetReturn": number,
                "timeHorizon": number,
                "keyThesis": [strings]
              }
            }`
          },
          {
            role: "user",
            content: `Historical data: ${JSON.stringify(historicalData)}\n\nMarket context: ${marketContext}`
          }
        ],
        response_format: { type: "json_object" }
      });

      return JSON.parse(response.choices[0].message.content || '{}');
    } catch (error) {
      console.error("Predictive analysis error:", error);
      throw new Error("Failed to generate predictive analysis");
    }
  }

  static async generateDataInsights(dataAnalysis: any, chartType: string): Promise<string[]> {
    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [
          {
            role: "system",
            content: "You are a data analyst generating actionable insights from financial data visualizations. Provide 3-5 key insights that support investment decision making."
          },
          {
            role: "user",
            content: `Data analysis: ${JSON.stringify(dataAnalysis)}\nChart type: ${chartType}\nGenerate insights that help understand business performance and investment potential.`
          }
        ]
      });

      const insights = response.choices[0].message.content || '';
      return insights.split('\n').filter(line => line.trim().length > 0).slice(0, 5);
    } catch (error) {
      console.error("Data insights error:", error);
      return ["Error generating insights"];
    }
  }
}