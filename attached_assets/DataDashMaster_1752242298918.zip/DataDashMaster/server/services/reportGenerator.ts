import ExcelJS from 'exceljs';
import fs from 'fs';
import path from 'path';

export interface ReportData {
  title: string;
  summary: string;
  sections: {
    title: string;
    content: any;
    type: 'table' | 'chart' | 'text' | 'metrics';
  }[];
  metadata: {
    generatedDate: Date;
    analyst: string;
    company?: string;
  };
}

export class ReportGenerator {
  
  static async generateExcelReport(reportData: ReportData): Promise<Buffer> {
    const workbook = new ExcelJS.Workbook();
    
    // Set workbook properties
    const generatedDate = new Date(reportData.metadata.generatedDate);
    workbook.creator = reportData.metadata.analyst;
    workbook.lastModifiedBy = reportData.metadata.analyst;
    workbook.created = generatedDate;
    workbook.modified = generatedDate;
    
    // Executive Summary Sheet
    const summarySheet = workbook.addWorksheet('Executive Summary', {
      views: [{ state: 'frozen', ySplit: 1 }]
    });
    
    // Add header styling - neutral professional colors
    summarySheet.getCell('A1').value = reportData.title;
    summarySheet.getCell('A1').font = { size: 16, bold: true, color: { argb: 'FF1e3a8a' } };
    summarySheet.mergeCells('A1:D1');
    
    summarySheet.getCell('A3').value = 'Generated Date:';
    summarySheet.getCell('B3').value = new Date(reportData.metadata.generatedDate).toLocaleDateString();
    summarySheet.getCell('A4').value = 'Analyst:';
    summarySheet.getCell('B4').value = reportData.metadata.analyst;
    
    if (reportData.metadata.company) {
      summarySheet.getCell('A5').value = 'Company:';
      summarySheet.getCell('B5').value = reportData.metadata.company;
    }
    
    summarySheet.getCell('A7').value = 'Executive Summary:';
    summarySheet.getCell('A7').font = { bold: true };
    summarySheet.getCell('A8').value = reportData.summary;
    summarySheet.getCell('A8').alignment = { wrapText: true };
    summarySheet.mergeCells('A8:D12');
    
    // Add data sheets for each section
    reportData.sections.forEach((section, index) => {
      const sheet = workbook.addWorksheet(section.title);
      
      // Add section title
      sheet.getCell('A1').value = section.title;
      sheet.getCell('A1').font = { size: 14, bold: true, color: { argb: 'FF1e3a8a' } };
      
      // Add refresh button using Excel's built-in functionality
      if (section.type === 'table') {
        sheet.getCell('E1').value = 'Last Updated:';
        sheet.getCell('F1').value = new Date();
        sheet.getCell('F1').numFmt = 'mm/dd/yyyy hh:mm';
        
        // Add data source info for potential live connections
        sheet.getCell('E2').value = 'Data Source:';
        sheet.getCell('F2').value = section.title;
      }
      
      if (section.type === 'table' && Array.isArray(section.content)) {
        this.addTableToSheet(sheet, section.content, 3);
      } else if (section.type === 'metrics' && typeof section.content === 'object') {
        this.addMetricsToSheet(sheet, section.content, 3);
      } else {
        sheet.getCell('A3').value = JSON.stringify(section.content, null, 2);
        sheet.getCell('A3').alignment = { wrapText: true };
      }
    });
    
    // Add API Connection Sheet for live data refresh
    const apiSheet = workbook.addWorksheet('Data Connections');
    
    // Add instructions and connection info
    apiSheet.getCell('A1').value = 'Live Data Connections';
    apiSheet.getCell('A1').font = { size: 14, bold: true };
    apiSheet.mergeCells('A1:C1');
    
    apiSheet.getCell('A3').value = 'To refresh data, use these API endpoints:';
    apiSheet.getCell('A3').font = { bold: true };
    
    // Add API endpoints for data refresh
    const baseUrl = process.env.REPLIT_URL || 'http://localhost:5000';
    apiSheet.getCell('A5').value = 'Query Data:';
    apiSheet.getCell('B5').value = `${baseUrl}/api/query`;
    apiSheet.getCell('A6').value = 'AI Analysis:';
    apiSheet.getCell('B6').value = `${baseUrl}/api/ai/analyze`;
    apiSheet.getCell('A7').value = 'Financial Analysis:';
    apiSheet.getCell('B7').value = `${baseUrl}/api/financial/analyze`;
    
    // Add refresh instructions
    apiSheet.getCell('A9').value = 'Refresh Instructions:';
    apiSheet.getCell('A9').font = { bold: true };
    apiSheet.getCell('A10').value = '1. Select data range you want to refresh';
    apiSheet.getCell('A11').value = '2. Go to Data > Connections > Refresh All';
    apiSheet.getCell('A12').value = '3. Or use VBA macro: RefreshAllData()';
    
    // Add VBA macro for data refresh
    apiSheet.getCell('A14').value = 'VBA Refresh Macro:';
    apiSheet.getCell('A14').font = { bold: true };
    const vbaMacro = `Sub RefreshAllData()
    ' Refresh all data connections
    Application.CalculateFullRebuild
    ThisWorkbook.RefreshAll
    MsgBox "Data refreshed successfully!"
End Sub`;
    apiSheet.getCell('A15').value = vbaMacro;
    apiSheet.getCell('A15').alignment = { wrapText: true };
    apiSheet.mergeCells('A15:D25');
    
    // Add data connection formulas in hidden columns
    apiSheet.getColumn('F').hidden = true;
    apiSheet.getColumn('G').hidden = true;
    apiSheet.getCell('F1').value = '=WEBSERVICE("' + baseUrl + '/api/health")';
    apiSheet.getCell('G1').value = 'Connection Status';

    // Auto-fit columns
    workbook.worksheets.forEach(worksheet => {
      worksheet.columns.forEach(column => {
        if (column.eachCell) {
          let maxLength = 0;
          column.eachCell((cell) => {
            const cellValue = cell.value ? cell.value.toString() : '';
            if (cellValue.length > maxLength) {
              maxLength = cellValue.length;
            }
          });
          column.width = Math.min(maxLength + 2, 50);
        }
      });
    });
    
    return await workbook.xlsx.writeBuffer() as Buffer;
  }
  
  private static addTableToSheet(sheet: any, data: any[], startRow: number) {
    if (data.length === 0) return;
    
    const headers = Object.keys(data[0]);
    
    // Add headers
    headers.forEach((header, colIndex) => {
      const cell = sheet.getCell(startRow, colIndex + 1);
      cell.value = header;
      cell.font = { bold: true };
      cell.fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: 'FFe0f2fe' }
      };
    });
    
    // Add data rows
    data.forEach((row, rowIndex) => {
      headers.forEach((header, colIndex) => {
        const cell = sheet.getCell(startRow + 1 + rowIndex, colIndex + 1);
        cell.value = row[header];
        
        // Format numbers and percentages
        if (typeof row[header] === 'number') {
          if (header.toLowerCase().includes('percentage') || header.toLowerCase().includes('margin')) {
            cell.numFmt = '0.00%';
          } else if (header.toLowerCase().includes('amount') || header.toLowerCase().includes('value')) {
            cell.numFmt = '"$"#,##0.00';
          } else {
            cell.numFmt = '#,##0.00';
          }
        }
      });
    });
    
    // Add borders
    const totalRows = data.length + 1;
    const totalCols = headers.length;
    for (let row = startRow; row <= startRow + totalRows; row++) {
      for (let col = 1; col <= totalCols; col++) {
        const cell = sheet.getCell(row, col);
        cell.border = {
          top: { style: 'thin' },
          left: { style: 'thin' },
          bottom: { style: 'thin' },
          right: { style: 'thin' }
        };
      }
    }
  }
  
  private static addMetricsToSheet(sheet: any, metrics: any, startRow: number) {
    let currentRow = startRow;
    
    Object.entries(metrics).forEach(([key, value]) => {
      sheet.getCell(currentRow, 1).value = key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase());
      sheet.getCell(currentRow, 1).font = { bold: true };
      
      if (typeof value === 'object' && value !== null) {
        Object.entries(value).forEach(([subKey, subValue]) => {
          currentRow++;
          sheet.getCell(currentRow, 2).value = subKey.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase());
          sheet.getCell(currentRow, 3).value = subValue;
          
          // Format numbers
          if (typeof subValue === 'number') {
            const cell = sheet.getCell(currentRow, 3);
            if (subKey.toLowerCase().includes('percentage') || subKey.toLowerCase().includes('margin')) {
              cell.numFmt = '0.00%';
            } else if (subKey.toLowerCase().includes('value') || subKey.toLowerCase().includes('amount')) {
              cell.numFmt = '"$"#,##0.00';
            } else {
              cell.numFmt = '#,##0.00';
            }
          }
        });
      } else {
        sheet.getCell(currentRow, 2).value = value;
        
        if (typeof value === 'number') {
          const cell = sheet.getCell(currentRow, 2);
          if (key.toLowerCase().includes('percentage') || key.toLowerCase().includes('margin')) {
            cell.numFmt = '0.00%';
          } else if (key.toLowerCase().includes('value') || key.toLowerCase().includes('amount')) {
            cell.numFmt = '"$"#,##0.00';
          } else {
            cell.numFmt = '#,##0.00';
          }
        }
      }
      
      currentRow += 2;
    });
  }
  
  static async generatePowerPointReport(reportData: ReportData): Promise<Buffer> {
    // For now, return a structured JSON that can be converted to PPTX on the client side
    // In production, you would use a library like node-pptx or officegen
    const pptxData = {
      slides: [
        {
          title: reportData.title,
          subtitle: `Generated on ${reportData.metadata.generatedDate.toLocaleDateString()}`,
          content: reportData.summary,
          type: 'title'
        },
        ...reportData.sections.map(section => ({
          title: section.title,
          content: section.content,
          type: section.type
        }))
      ]
    };
    
    return Buffer.from(JSON.stringify(pptxData, null, 2));
  }
  
  static async generatePDFReport(reportData: ReportData): Promise<Buffer> {
    // Generate HTML content for PDF conversion
    const htmlContent = this.generateHTMLReport(reportData);
    
    // For now, return HTML as buffer - in production you would use puppeteer or similar
    return Buffer.from(htmlContent);
  }

  static async generateCSVReport(reportData: ReportData): Promise<Buffer> {
    let csvContent = `"${reportData.title}"\n`;
    csvContent += `"Generated Date","${new Date(reportData.metadata.generatedDate).toLocaleDateString()}"\n`;
    csvContent += `"Analyst","${reportData.metadata.analyst}"\n`;
    if (reportData.metadata.company) {
      csvContent += `"Company","${reportData.metadata.company}"\n`;
    }
    csvContent += `\n"Executive Summary"\n"${reportData.summary.replace(/"/g, '""')}"\n\n`;

    reportData.sections.forEach((section, index) => {
      csvContent += `"${section.title}"\n`;
      
      if (section.type === 'table' && Array.isArray(section.content) && section.content.length > 0) {
        const headers = Object.keys(section.content[0]);
        csvContent += `"${headers.join('","')}"\n`;
        
        section.content.forEach(row => {
          const values = headers.map(header => {
            const value = row[header];
            if (typeof value === 'string') {
              return value.replace(/"/g, '""');
            }
            return value || '';
          });
          csvContent += `"${values.join('","')}"\n`;
        });
      } else if (section.type === 'metrics' && typeof section.content === 'object') {
        csvContent += `"Metric","Value"\n`;
        Object.entries(section.content).forEach(([key, value]) => {
          if (typeof value === 'object' && value !== null) {
            Object.entries(value).forEach(([subKey, subValue]) => {
              csvContent += `"${key} - ${subKey}","${subValue}"\n`;
            });
          } else {
            csvContent += `"${key}","${value}"\n`;
          }
        });
      } else {
        csvContent += `"Content","${JSON.stringify(section.content).replace(/"/g, '""')}"\n`;
      }
      
      csvContent += '\n';
    });

    return Buffer.from(csvContent, 'utf8');
  }
  
  private static generateHTMLReport(reportData: ReportData): string {
    const currentDate = new Date(reportData.metadata.generatedDate).toLocaleDateString();
    
    return `
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>${reportData.title}</title>
        <style>
            body { 
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
                margin: 40px; 
                line-height: 1.6; 
                color: #333;
            }
            .header { 
                border-bottom: 3px solid #1e3a8a; 
                padding-bottom: 20px; 
                margin-bottom: 30px; 
            }
            .title { 
                color: #1e3a8a; 
                font-size: 28px; 
                font-weight: bold; 
                margin: 0;
            }
            .subtitle { 
                color: #666; 
                font-size: 16px; 
                margin: 10px 0 0 0; 
            }
            .section { 
                margin: 30px 0; 
                page-break-inside: avoid; 
            }
            .section-title { 
                color: #1e3a8a; 
                font-size: 20px; 
                font-weight: bold; 
                border-left: 4px solid #3b82f6; 
                padding-left: 15px; 
                margin-bottom: 15px; 
            }
            .metrics-grid { 
                display: grid; 
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); 
                gap: 15px; 
                margin: 20px 0; 
            }
            .metric-card { 
                background: #f8fafc; 
                border: 1px solid #e2e8f0; 
                border-radius: 8px; 
                padding: 15px; 
                text-align: center; 
            }
            .metric-value { 
                font-size: 24px; 
                font-weight: bold; 
                color: #1e3a8a; 
            }
            .metric-label { 
                font-size: 14px; 
                color: #666; 
                margin-top: 5px; 
            }
            table { 
                width: 100%; 
                border-collapse: collapse; 
                margin: 20px 0; 
            }
            th, td { 
                border: 1px solid #ddd; 
                padding: 12px; 
                text-align: left; 
            }
            th { 
                background-color: #1e3a8a; 
                color: white; 
                font-weight: bold; 
            }
            tr:nth-child(even) { 
                background-color: #f8fafc; 
            }
            .summary { 
                background: #f0f9ff; 
                border-left: 4px solid #3b82f6; 
                padding: 20px; 
                margin: 20px 0; 
                border-radius: 0 8px 8px 0; 
            }
            .footer { 
                margin-top: 40px; 
                padding-top: 20px; 
                border-top: 1px solid #ddd; 
                text-align: center; 
                color: #666; 
                font-size: 12px; 
            }
        </style>
    </head>
    <body>
        <div class="header">
            <h1 class="title">${reportData.title}</h1>
            <p class="subtitle">Generated on ${currentDate} by ${reportData.metadata.analyst}</p>
            ${reportData.metadata.company ? `<p class="subtitle">Company: ${reportData.metadata.company}</p>` : ''}
        </div>
        
        <div class="summary">
            <h2>Executive Summary</h2>
            <p>${reportData.summary}</p>
        </div>
        
        ${reportData.sections.map(section => `
            <div class="section">
                <h2 class="section-title">${section.title}</h2>
                ${this.renderSectionContent(section)}
            </div>
        `).join('')}
        
        <div class="footer">
            <p>Generated by DataFlow Analytics - Advanced Private Equity Platform</p>
        </div>
    </body>
    </html>`;
  }
  
  private static renderSectionContent(section: any): string {
    if (section.type === 'metrics' && typeof section.content === 'object') {
      return `
        <div class="metrics-grid">
          ${Object.entries(section.content).map(([key, value]) => `
            <div class="metric-card">
              <div class="metric-value">${typeof value === 'number' ? value.toLocaleString() : value}</div>
              <div class="metric-label">${key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())}</div>
            </div>
          `).join('')}
        </div>
      `;
    } else if (section.type === 'table' && Array.isArray(section.content) && section.content.length > 0) {
      const headers = Object.keys(section.content[0]);
      return `
        <table>
          <thead>
            <tr>
              ${headers.map(header => `<th>${header}</th>`).join('')}
            </tr>
          </thead>
          <tbody>
            ${section.content.map(row => `
              <tr>
                ${headers.map(header => `<td>${row[header] || ''}</td>`).join('')}
              </tr>
            `).join('')}
          </tbody>
        </table>
      `;
    } else {
      return `<p>${typeof section.content === 'string' ? section.content : JSON.stringify(section.content, null, 2)}</p>`;
    }
  }
}