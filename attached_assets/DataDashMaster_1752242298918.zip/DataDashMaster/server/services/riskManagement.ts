import OpenAI from "openai";

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export interface RiskProfile {
  creditRisk: number;
  marketRisk: number;
  operationalRisk: number;
  liquidityRisk: number;
  concentrationRisk: number;
  overallRiskScore: number;
}

export interface StressTestResult {
  scenario: string;
  probabilityOfOccurrence: number;
  portfolioImpact: number;
  mitigationStrategies: string[];
  timeToRecover: number;
}

export interface ESGAnalysis {
  environmentalScore: number;
  socialScore: number;
  governanceScore: number;
  overallESGScore: number;
  sustainabilityRisks: string[];
  improvementAreas: string[];
}

export interface ComplianceReport {
  regulatoryCompliance: {
    status: 'COMPLIANT' | 'NON_COMPLIANT' | 'UNDER_REVIEW';
    findings: string[];
    requiredActions: string[];
  };
  auditTrail: {
    lastAudit: Date;
    nextAudit: Date;
    findings: string[];
  };
  riskMitigationPlan: string[];
}

export class RiskManagementEngine {
  
  static async assessRiskProfile(financialData: any, marketData: any): Promise<RiskProfile> {
    try {
      const prompt = `
        Assess comprehensive risk profile for this investment:
        Financial Data: ${JSON.stringify(financialData)}
        Market Data: ${JSON.stringify(marketData)}
        
        Provide risk assessment in JSON format (scores 0-100, higher = more risk):
        {
          "creditRisk": score,
          "marketRisk": score,
          "operationalRisk": score,
          "liquidityRisk": score,
          "concentrationRisk": score,
          "overallRiskScore": weighted_average,
          "riskFactors": ["factor1", "factor2"],
          "mitigationRecommendations": ["recommendation1", "recommendation2"]
        }
      `;

      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [{ role: "user", content: prompt }],
        response_format: { type: "json_object" },
      });

      const analysis = JSON.parse(response.choices[0].message.content);
      
      return {
        creditRisk: analysis.creditRisk,
        marketRisk: analysis.marketRisk,
        operationalRisk: analysis.operationalRisk,
        liquidityRisk: analysis.liquidityRisk,
        concentrationRisk: analysis.concentrationRisk,
        overallRiskScore: analysis.overallRiskScore
      };
    } catch (error) {
      throw new Error("Failed to assess risk profile: " + error.message);
    }
  }

  static async performStressTesting(portfolioData: any, scenarios: string[]): Promise<StressTestResult[]> {
    try {
      const results: StressTestResult[] = [];
      
      for (const scenario of scenarios) {
        const prompt = `
          Perform stress test analysis for scenario: "${scenario}"
          Portfolio Data: ${JSON.stringify(portfolioData)}
          
          Provide stress test results in JSON format:
          {
            "scenario": "${scenario}",
            "probabilityOfOccurrence": percentage,
            "portfolioImpact": percentage_loss,
            "mitigationStrategies": ["strategy1", "strategy2"],
            "timeToRecover": months,
            "affectedAssets": ["asset1", "asset2"],
            "recommendations": ["rec1", "rec2"]
          }
        `;

        const response = await openai.chat.completions.create({
          model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
          messages: [{ role: "user", content: prompt }],
          response_format: { type: "json_object" },
        });

        const analysis = JSON.parse(response.choices[0].message.content);
        results.push({
          scenario: analysis.scenario,
          probabilityOfOccurrence: analysis.probabilityOfOccurrence,
          portfolioImpact: analysis.portfolioImpact,
          mitigationStrategies: analysis.mitigationStrategies,
          timeToRecover: analysis.timeToRecover
        });
      }
      
      return results;
    } catch (error) {
      throw new Error("Failed to perform stress testing: " + error.message);
    }
  }

  static async analyzeESGFactors(companyData: any): Promise<ESGAnalysis> {
    try {
      const prompt = `
        Analyze ESG (Environmental, Social, Governance) factors for this investment:
        Company Data: ${JSON.stringify(companyData)}
        
        Provide ESG analysis in JSON format (scores 0-100, higher = better):
        {
          "environmentalScore": score,
          "socialScore": score,
          "governanceScore": score,
          "overallESGScore": weighted_average,
          "sustainabilityRisks": ["risk1", "risk2"],
          "improvementAreas": ["area1", "area2"],
          "complianceStatus": "status",
          "benchmarkComparison": "vs industry average"
        }
      `;

      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [{ role: "user", content: prompt }],
        response_format: { type: "json_object" },
      });

      const analysis = JSON.parse(response.choices[0].message.content);
      
      return {
        environmentalScore: analysis.environmentalScore,
        socialScore: analysis.socialScore,
        governanceScore: analysis.governanceScore,
        overallESGScore: analysis.overallESGScore,
        sustainabilityRisks: analysis.sustainabilityRisks,
        improvementAreas: analysis.improvementAreas
      };
    } catch (error) {
      throw new Error("Failed to analyze ESG factors: " + error.message);
    }
  }

  static async generateComplianceReport(investmentData: any, regulations: string[]): Promise<ComplianceReport> {
    try {
      const prompt = `
        Generate compliance report for this investment:
        Investment Data: ${JSON.stringify(investmentData)}
        Applicable Regulations: ${regulations.join(', ')}
        
        Provide compliance analysis in JSON format:
        {
          "regulatoryCompliance": {
            "status": "COMPLIANT|NON_COMPLIANT|UNDER_REVIEW",
            "findings": ["finding1", "finding2"],
            "requiredActions": ["action1", "action2"]
          },
          "auditTrail": {
            "lastAudit": "YYYY-MM-DD",
            "nextAudit": "YYYY-MM-DD",
            "findings": ["finding1", "finding2"]
          },
          "riskMitigationPlan": ["plan1", "plan2"],
          "recommendedControls": ["control1", "control2"]
        }
      `;

      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [{ role: "user", content: prompt }],
        response_format: { type: "json_object" },
      });

      const analysis = JSON.parse(response.choices[0].message.content);
      
      return {
        regulatoryCompliance: {
          status: analysis.regulatoryCompliance.status,
          findings: analysis.regulatoryCompliance.findings,
          requiredActions: analysis.regulatoryCompliance.requiredActions
        },
        auditTrail: {
          lastAudit: new Date(analysis.auditTrail.lastAudit),
          nextAudit: new Date(analysis.auditTrail.nextAudit),
          findings: analysis.auditTrail.findings
        },
        riskMitigationPlan: analysis.riskMitigationPlan
      };
    } catch (error) {
      throw new Error("Failed to generate compliance report: " + error.message);
    }
  }

  static async monitorPortfolioRisk(portfolioData: any[]): Promise<any> {
    try {
      // Calculate Value at Risk (VaR)
      const returns = portfolioData.map(asset => asset.return || 0);
      const volatility = this.calculateVolatility(returns);
      const var95 = this.calculateVaR(returns, 0.95);
      const var99 = this.calculateVaR(returns, 0.99);
      
      const prompt = `
        Monitor portfolio risk metrics:
        Portfolio Data: ${JSON.stringify(portfolioData)}
        Volatility: ${volatility}
        VaR 95%: ${var95}
        VaR 99%: ${var99}
        
        Provide risk monitoring report in JSON format:
        {
          "riskMetrics": {
            "volatility": ${volatility},
            "var95": ${var95},
            "var99": ${var99},
            "sharpeRatio": ratio,
            "maxDrawdown": percentage
          },
          "alerts": ["alert1", "alert2"],
          "recommendations": ["rec1", "rec2"],
          "riskTrend": "INCREASING|STABLE|DECREASING"
        }
      `;

      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [{ role: "user", content: prompt }],
        response_format: { type: "json_object" },
      });

      return JSON.parse(response.choices[0].message.content);
    } catch (error) {
      throw new Error("Failed to monitor portfolio risk: " + error.message);
    }
  }

  private static calculateVolatility(returns: number[]): number {
    const mean = returns.reduce((sum, r) => sum + r, 0) / returns.length;
    const variance = returns.reduce((sum, r) => sum + Math.pow(r - mean, 2), 0) / returns.length;
    return Math.sqrt(variance);
  }

  private static calculateVaR(returns: number[], confidence: number): number {
    const sorted = returns.sort((a, b) => a - b);
    const index = Math.floor((1 - confidence) * sorted.length);
    return sorted[index];
  }
}