// Security and feature configuration
export const CONFIG = {
  // Toggle AI features on/off
  SECURITY_MODE: process.env.SECURITY_MODE === 'true' || false, // Default to full AI
  
  // OpenAI configuration  
  OPENAI_ENABLED: process.env.OPENAI_ENABLED === 'true' || true,
  
  // File encryption
  ENCRYPT_FILES: process.env.ENCRYPT_FILES === 'true' || true,
  
  // Data retention
  AUTO_PURGE_DAYS: parseInt(process.env.AUTO_PURGE_DAYS || '30'),
  
  // Feature flags
  FEATURES: {
    AI_DOCUMENT_ANALYSIS: process.env.AI_DOCUMENT_ANALYSIS === 'true' || true,
    AI_SQL_GENERATION: process.env.AI_SQL_GENERATION === 'true' || true,
    AI_CHART_GENERATION: process.env.AI_CHART_GENERATION === 'true' || true,
    PREDICTIVE_ANALYTICS: process.env.PREDICTIVE_ANALYTICS === 'true' || true,
  }
};

// Quick toggle functions
export function enableFullAI() {
  process.env.SECURITY_MODE = 'false';
  process.env.OPENAI_ENABLED = 'true';
  process.env.AI_DOCUMENT_ANALYSIS = 'true';
  process.env.AI_SQL_GENERATION = 'true';
  process.env.AI_CHART_GENERATION = 'true';
  process.env.PREDICTIVE_ANALYTICS = 'true';
  console.log('🤖 Full AI capabilities enabled');
}

export function enableSecureMode() {
  process.env.SECURITY_MODE = 'true';
  process.env.OPENAI_ENABLED = 'false';
  process.env.AI_DOCUMENT_ANALYSIS = 'false';
  process.env.AI_SQL_GENERATION = 'false';
  process.env.AI_CHART_GENERATION = 'false';
  process.env.PREDICTIVE_ANALYTICS = 'false';
  console.log('🔒 Secure mode enabled - no external data sharing');
}