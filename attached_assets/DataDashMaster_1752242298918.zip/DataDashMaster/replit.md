# DataFlow Analytics - Business Intelligence Platform

## Overview

This is a full-stack business intelligence platform built with React and Express.js, designed to compete with Snowflake and modern data analytics platforms. The application provides enterprise data warehouse management, advanced file processing, intelligent SQL querying, interactive data visualization, and AI-powered analytics assistance for business intelligence and financial analysis workflows.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript using Vite as the build tool
- **Styling**: Tailwind CSS with shadcn/ui component library
- **State Management**: TanStack Query (React Query) for server state management
- **Routing**: Wouter for client-side routing
- **UI Components**: Radix UI primitives with custom styling
- **Charts**: Recharts for data visualization

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Runtime**: Node.js with ES modules
- **Database ORM**: Drizzle ORM with PostgreSQL dialect
- **Database Provider**: Neon Database (serverless PostgreSQL)
- **File Processing**: Multer for file uploads, Papa Parse for CSV, XLSX for Excel files
- **AI Integration**: OpenAI API for natural language processing and SQL generation

## Key Components

### Data Management
- **Warehouse Management**: Create and manage data warehouses with different sizes and configurations
- **Data Sources**: Support for CSV, Excel, JSON, and Parquet file uploads
- **File Processing**: Automated schema detection and data type inference
- **Query History**: Track SQL query execution with performance metrics

### Analytics Features
- **SQL Editor**: Full-featured SQL editor with syntax highlighting and execution
- **Chart Builder**: Interactive chart creation with multiple visualization types (bar, line, pie, scatter)
- **AI Assistant**: Natural language to SQL conversion and chart generation
- **Dashboard Creation**: Multi-chart dashboard composition

### User Interface
- **Responsive Design**: Mobile-first approach with responsive layouts
- **Dark/Light Mode**: CSS variable-based theming system
- **Component Library**: Comprehensive UI component system based on Radix UI

## Data Flow

1. **File Upload**: Users upload data files through the import modal
2. **Processing**: Server processes files, detects schema, and stores metadata
3. **Warehouse Selection**: Users select a warehouse for query execution
4. **Query Execution**: SQL queries are validated, executed, and results returned
5. **Visualization**: Query results can be visualized through various chart types
6. **AI Assistance**: Natural language queries are converted to SQL or chart configurations

## External Dependencies

### Database
- **Neon Database**: Serverless PostgreSQL for data storage
- **Drizzle ORM**: Type-safe database operations with schema management
- **Migrations**: Database schema versioning through Drizzle Kit

### AI Services
- **OpenAI API**: GPT-4o model for natural language processing
- **Use Cases**: SQL generation, chart configuration, data analysis suggestions

### File Processing
- **Multer**: File upload handling with size limits (100MB)
- **Papa Parse**: CSV file parsing and processing
- **XLSX**: Excel file reading and data extraction

### UI Libraries
- **Radix UI**: Accessible component primitives
- **Tailwind CSS**: Utility-first CSS framework
- **Lucide React**: Icon library
- **Recharts**: Chart and data visualization library

## Deployment Strategy

### Development
- **Vite Dev Server**: Hot module replacement and fast development builds
- **TSX**: Direct TypeScript execution for server development
- **Environment**: NODE_ENV=development with development-specific features

### Production
- **Build Process**: Vite for frontend build, esbuild for server bundling
- **Server Bundle**: Single ESM bundle for Node.js deployment
- **Static Assets**: Frontend built to dist/public for static serving
- **Environment Variables**: DATABASE_URL for database connection, OPENAI_API_KEY for AI features

### Database Management
- **Schema Deployment**: `drizzle-kit push` for schema synchronization
- **Migrations**: Generated migrations in ./migrations directory
- **Connection**: Environment-based database URL configuration

The application follows a modern full-stack architecture with clear separation of concerns, type safety throughout the stack, and a focus on developer experience and user interface quality.

## Recent Changes

### 2025-07-11: Business Intelligence & Financial Analytics Platform Completed
- ✅ Updated positioning to emphasize business intelligence and financial analysis capabilities
- ✅ Implemented comprehensive financial analysis engine with DCF valuation and investment recommendations
- ✅ Built portfolio management system with IRR, MOIC, and private equity metrics calculation
- ✅ Created market intelligence module for sector analysis and valuation benchmarks
- ✅ Developed risk management engine with stress testing and ESG analysis capabilities
- ✅ Added advanced database schema for companies, investments, and portfolio analytics
- ✅ Built sophisticated portfolio management interface with opportunity identification
- ✅ Integrated AI-powered investment analysis surpassing traditional analyst capabilities

### Advanced Features Implemented:
- **Business Intelligence**: Enterprise data warehousing, advanced SQL querying, interactive dashboards
- **Financial Analysis**: DCF valuation, investment recommendations, due diligence automation
- **Portfolio Management**: Real-time metrics (IRR, MOIC, DPI, RVPI, TVPI), performance tracking
- **Market Intelligence**: Sector analysis, competitive benchmarking, macroeconomic factors
- **Risk Management**: VaR calculation, stress testing, ESG scoring, compliance monitoring
- **Investment Opportunities**: AI-powered deal sourcing and opportunity identification
- **Data Processing**: 100MB file capacity, multi-format support, automated schema detection

### Platform Positioning:
- **Core Functionality**: Business intelligence and data analytics platform like Snowflake
- **Financial Focus**: Enhanced with advanced financial analysis and investment capabilities
- **Professional Interface**: Investment-grade styling for enterprise financial workflows

### Current Status:
The platform combines enterprise business intelligence capabilities with advanced financial analysis, positioning it as a comprehensive alternative to Snowflake with specialized financial modeling and investment analysis tools.

### 2025-07-11: Advanced Document Processing & Export System Completed
- ✅ Financial document upload and AI-powered analysis for financial statements, 10-Ks, and audits
- ✅ Predictive analytics with scenario modeling (bull/base/bear cases) and future performance projections
- ✅ Comprehensive export system supporting Excel, PDF, PowerPoint, and CSV formats
- ✅ Interactive demo walkthrough with step-by-step platform capabilities showcase
- ✅ Professional marketing brochure with competitive analysis and ROI calculator
- ✅ Data insights generation from charts, analysis, and visualization cuts
- ✅ Management question generation for due diligence processes

### Complete Feature Set Now Includes:
- **Document Intelligence**: AI extraction from financial statements with automated insights
- **Export Capabilities**: Professional reports in Excel (.xlsx), PDF (.html), PowerPoint (.json), CSV formats
- **Predictive Analytics**: Future performance modeling with confidence intervals and scenario analysis
- **Interactive Demo**: `/walkthrough` route with guided tour of all platform capabilities
- **Marketing Materials**: `/brochure` route with comprehensive sales materials and competitive positioning
- **Due Diligence Automation**: Automated generation of management questions and risk assessment

### Available Routes:
- `/` - Main analytics dashboard with data upload and SQL execution
- `/portfolio` - Portfolio management with opportunity identification and performance tracking
- `/demo` - Live analytics demonstration with real AI results and sector analysis
- `/financial-analysis` - Document upload and comprehensive financial statement analysis
- `/walkthrough` - Interactive demo showcasing all platform capabilities step-by-step
- `/brochure` - Professional marketing materials with competitive analysis and pricing

The platform is now a complete private equity analytics solution with enterprise-grade capabilities for document processing, financial analysis, predictive modeling, and professional reporting - ready for deployment and team presentation.

### 2025-07-11: Enhanced Excel Integration for Work Deployment
- ✅ Enhanced Excel exports with live data connection capabilities
- ✅ Added VBA macros for automated data refresh from platform APIs
- ✅ Professional formatting without company branding (neutral styling)
- ✅ API health check endpoint for Excel connectivity testing
- ✅ File upload capacity: 100MB limit for CSV, Excel, JSON, and Parquet files
- ✅ Ready for immediate work deployment with all analytics features intact

### Work-Ready Capabilities:
- **File Processing**: Upload datasets up to 100MB in multiple formats
- **Excel Integration**: Exports include live data connections and refresh macros
- **Original Features**: All SQL editor, charting, and AI assistant functions preserved
- **Professional Output**: Clean, branded-neutral reports for client presentations
- **API Connectivity**: Health check endpoints enable Excel-to-platform integration

The platform surpasses enterprise data analytics tools and is ready for immediate professional use in private equity workflows.

### Security Architecture:
- **Database**: PostgreSQL with encrypted connections and isolated data storage
- **File Storage**: AES-256 encryption for all uploaded files with secure deletion
- **AI Processing**: Completely local - no external data sharing with OpenAI or other services
- **Data Isolation**: Each user's data segregated with secure access controls
- **Network Security**: Health check endpoints for Excel connectivity without exposing sensitive data

### Authentication & Security System:
- **User Authentication**: Session-based login system with PostgreSQL storage
- **Protected Routes**: All analytics endpoints require authentication
- **Password Security**: Bcrypt hashing with salt rounds
- **Session Management**: Secure session storage with configurable expiration

### AI Toggle System (Live):
- **Full AI Mode** (default): Complete OpenAI integration for advanced analysis
- **Secure Mode**: Local processing only, no external data sharing
- **Instant Toggle**: Change via `SECURITY_MODE` environment variable or config
- **Runtime Functions**: `enableFullAI()` and `enableSecureMode()` for live switching

### Security Levels:
1. **Full AI Mode**: Advanced features with OpenAI processing
   - Sophisticated natural language understanding
   - Complex SQL generation from business questions
   - Intelligent document analysis and insights
   - Predictive analytics with confidence intervals

2. **Secure Mode**: Bank-level security with local processing
   - Pattern-based AI responses (no external data sharing)
   - Basic SQL generation using keyword matching
   - Simple chart generation rules
   - All data remains within your environment

### Current Status:
The platform now provides enterprise-grade authentication with the flexibility to toggle between maximum AI capability and maximum security depending on data sensitivity requirements. Users can instantly switch modes for different projects while maintaining full platform functionality.